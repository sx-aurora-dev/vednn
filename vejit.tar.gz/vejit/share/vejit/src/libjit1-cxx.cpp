/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
#ifndef ASMFMTREMOVE
#define ASMFMTREMOVE 0
#endif
#include "asmfmt.hpp"
#include "throw.hpp"
//#include "codegenasm.hpp"
#include "stringutil.hpp"
#include "jitpage.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
//#include <stdexcept>
#include <algorithm> // max
//#include <cstdlib>
//#include <cassert>
#include <array>
//#include <cstdio> // FILE, ftell

using namespace std;

#if ASMFMTREMOVE < 2
string fname_bin( string const& fname_S ){
    auto len = fname_S.size();
    if( len >= 2 && fname_S.substr(len-2) != ".S" ){
        throw runtime_error(" assembler filename " + fname_S + " should end in .S");
    }
    return string{fname_S.substr(0,len-2) + ".bin"};
}

size_t asm2bin( string const& fname_S, int const verbose/*=1*/ ){
    if(verbose>1) cout<<" Running asm2bin from " __FILE__<<endl;
    string const fbin = fname_bin( fname_S );
    string mk_cmd("make -f bin.mk " + fbin);
    if(verbose==0) mk_cmd.insert(0,"VERBOSE=0 ");
    if(verbose>1) cout << "cmd: " << mk_cmd << endl;
    int status = system( mk_cmd.c_str() );

    if( status == 0 ){
        if(verbose) cout << "     asm2bin(" << fname_S << ") DONE" << endl;
    }else{
        if(verbose){cout<<" Ohoh: make command returned status "<<status<<endl; cout.flush();}
        throw runtime_error("asm2bin( \"" + fname_S + "\" ) failed, status=" + to_string(status));
    }
    // We return the filesize in bytes, so we know how big a jit page we need
    FILE* f_bin = fopen(fbin.c_str(),"rb");
    long f_bin_bytes = 0L;
    if( f_bin==NULL ){
        throw runtime_error("Could not open " + fbin + " (from " + fname_S + ") for reading");
    }else{
        fseek(f_bin,0,SEEK_END);
        f_bin_bytes = ftell(f_bin);
    }
    if( f_bin_bytes == 0L ){
        throw runtime_error(fbin + " (from " + fname_S + ") had zero bytes");
    }
    if(verbose) cout<<" ftell says "<<f_bin_bytes<<" bytes in file "<<fbin<<endl;
    fclose(f_bin);
    return f_bin_bytes;
}

ExecutablePage::ExecutablePage( std::string const& fbin )
: page({nullptr,0,verbosity}) // verbosity is a static const member, see asmfmt_fwd.hpp
{
    auto len = fbin.size();
    if( len >= 4 && fbin.substr(len-4) != ".bin" ){
        throw runtime_error(" binary blob filename " + fbin + " should end in .bin");
    }
    string basename{fbin.substr(0,len-4)};

    JitPage *p = const_cast<JitPage*>(&this->page);
    bin2jitpage(basename.c_str(), p, verbosity);
    if( p->mem == nullptr ){
        throw runtime_error(" Problems getting code page for " + fbin);
    }
    jitpage_readexec(p); // ignore errors here.
}
ExecutablePage::~ExecutablePage(){
    int status = jitpage_free(const_cast<JitPage*>(&this->page));
    if(status){
        // destructors really ought not to throw
        //throw runtime_error(" Problems releasing ExecutablePage");
        fprintf(stderr," Problems releasing ExecutablePage");
        abort();
    }
}
#endif //ASMFMTREMOVE < 2

#if ASMFMTREMOVE < 1
char const* const    AsmFmtCols::ws =" \t\r"; // NOT including '\n'
char const* const    AsmFmtCols::indent = "    ";
int const            AsmFmtCols::inwidth = 4;
int const            AsmFmtCols::opwidth = 12;
//std::streampos const AsmFmtCols::argwidth = 24;
int const            AsmFmtCols::argwidth = 44;

static inline void throw_if_written( AsmFmtCols const* asmfmt, string const& cannot ){
    /* NOP */
}

AsmFmtCols::AsmFmtCols()
    : a(new ostringstream()),
    //, stack_undefs{std::string("")}, stack_defs{std::string("")}
    stack_undefs(), stack_defs(),
    parent(nullptr), _allow_alias(true)
{
    (*a) << left;
    a->fill(' ');
}
AsmFmtCols::~AsmFmtCols(){
    //std::cout<<"~AsmFmtCols,"<<stack_undefs.size()<<"undefs "; std::cout.flush();
    if( !a->str().empty() ){
        cout<<" Warning: unused AsmFmtCols code:\n"<<a->str()<<endl;
    }
    if( stack_undefs.size() ){
        cout<<" Warning: un-popped stack_undefs!"<<endl;
        for(auto const&u: stack_undefs){
            cout<<"Stack item:\n"<<u<<endl;
        }
    }
    delete a;    a = nullptr;
}
std::vector<std::string>::size_type AsmFmtCols::pop_scope(){
    auto sz = stack_undefs.size();
    if(sz) {
        assert( a != nullptr );
        (*a) << stack_undefs.back(); // #undef lines, no endl here
        --sz;
        stack_undefs.resize(sz);
        stack_defs.resize(sz);
    }
    return sz;
}
void AsmFmtCols::pop_scopes(){
    while(stack_undefs.size()){
        this->pop_scope();
    }
}
AsmFmtCols& AsmFmtCols::raw(string const& anything){
    throw_if_written(this,__FUNCTION__);
    (*a) << anything << endl;
    return *this;
}
AsmFmtCols& AsmFmtCols::lcom(string const& comment){
    throw_if_written(this,__FUNCTION__);
    (*a) << indent << "// " << comment << endl;
    return *this;
}
AsmFmtCols& AsmFmtCols::com(string const& comment){
    throw_if_written(this,__FUNCTION__);
    (*a) << setw(inwidth+opwidth+3) << right << "// " << left << comment << endl;
    return *this;
}
AsmFmtCols& AsmFmtCols::rcom(string const& comment){
    throw_if_written(this,__FUNCTION__);
    (*a) << setw(inwidth+opwidth+argwidth+3) << right << "// " << left << comment << endl;
    return *this;
}
AsmFmtCols& AsmFmtCols::lab(string const& label, std::string const& comment/*=""*/){
    throw_if_written(this,__FUNCTION__);
    (*a) << label << ':';
    if(!comment.empty()) (*a) << " # " << comment;
    (*a) << endl;
    return *this;
}
AsmFmtCols& AsmFmtCols::ins(){
    throw_if_written(this,__FUNCTION__);
    (*a) << endl;
    return *this;
}
AsmFmtCols::AsmLine AsmFmtCols::parts(std::string const& instruction){
    // made this a STATIC function
    //throw_if_written(this,__FUNCTION__);
    int const v=0;
    AsmLine ret;
    if(v)cout<<"parts.."<<instruction<<endl;
    auto inst = reduce(trim(instruction)); // again?
    auto opbeg = inst.find_first_not_of(" \t\r\n",0);
    if( opbeg == string::npos ){
        if(v)cout<<"DONE"<<endl;
        return ret;
    }
    if(v)cout<<"     .."<<inst<<endl;
    //
    // TODO: comment "//...\n"
    auto opend = inst.find_first_of(" \t\r#\n;",opbeg); // white or comment or statement-end
    auto opend2 = inst.find("//", opbeg); // another type of possible ending
    opend = min(opend,opend2);

    if(v)cout<<" op"<<opbeg<<":"<<opend;
    if( opend == string::npos ){
        ret.op = inst.substr(opbeg);
        if(v)cout<<" inst="<<inst<<" ["<<opbeg<<",npos] ret.op="<<ret.op<<" DONE"<<endl;
    }else{
        ret.op = inst.substr(opbeg, opend-opbeg);
        //if(v)cout<<" op<"<<ret.op<<">";
        if(v)cout<<" inst="<<inst<<" ["<<opbeg<<",opend) ret.op="<<ret.op<<" DONE"<<endl;
        auto iargbeg = inst.find_first_not_of(ws,opend);
        if (iargbeg != string::npos){
            auto iargend = inst.find_last_not_of(ws);
            if(v)cout<<" args"<<iargbeg<<":"<<iargend;
            ret.args = inst.substr(iargbeg, iargend-iargbeg+1);
            if(v)cout<<"<"<<ret.args<<">";
            // currently ret.args is "everything else",
            // new: ret.args needs some massaging:
            //      after ';' --> remain,
            //  and after '#' (before ';' if any) --> comment
            // Suppose comments are not allowed to contain semicolons
            iargend = string::npos;
            auto isemicolon = ret.args.find_first_of(";\n",0);
            if( isemicolon != string::npos ){
                iargend = isemicolon;
                auto iback = ret.args.find_last_not_of(ws);
                ret.remain = ret.args.substr( isemicolon+1, iback-isemicolon );
                if(v) cout<<" remain"<<isemicolon+1<<":"<<iback<<" "<<ret.remain<<endl;
            }
            auto icomment = ret.args.find_first_of("#",0);
            auto icomment2 = ret.args.find("//",0); // length of comment mark is 2, not 1
            icomment = min(icomment,icomment2);
            if( icomment != string::npos && icomment < isemicolon ){
                // side effect is that we FORGET the comment type (we generate only '#' comments for now XXX)
                iargend = icomment;
                ret.comment = ret.args.substr( icomment+(icomment==icomment2? 2: 1), isemicolon-icomment-1 );
                if(v) cout<<" comment"<<icomment+1<<":"<<isemicolon-1<<" "<<ret.comment<<endl;
            }
            // chop any comment or multi-line asm
            if( iargend != string::npos ){
                ret.args = ret.args.substr(0,iargend);
                if(v) cout<<" final ret.args "<<0<<":"<<iargend<<" "<<ret.args<<endl;
                // chop ws again
                iargend = ret.args.find_last_not_of(ws);
                if( iargend != string::npos ){
                    ret.args = ret.args.substr(0,iargend+1);
                }
            }
        }
    }
    if(v) cout<<" final ret.label   <"<<ret.label<<">"<<endl;
    if(v) cout<<" final ret.op      <"<<ret.op<<">"<<endl;
    if(v) cout<<" final ret.args    <"<<ret.args<<">"<<endl;
    if(v) cout<<" final ret.comment <"<<ret.comment<<">"<<endl;
    if(v) cout<<" final ret.remain  <"<<ret.remain<<">"<<endl;
    if(v)cout<<" DONE"<<endl;
    return ret;
}
AsmFmtCols& AsmFmtCols::ins(string const& instruction){
    throw_if_written(this,__FUNCTION__);
    // for multiline, we need a bit more than just 'parts(instruction)'
    std::string remain = instruction;
    //cout<<" remain = "<<remain<<endl;
    while( remain.size() ){
        auto const p = parts(remain);
        if(p.op.size() == 0){
            ins();
        }else{
            (*a) << left << indent;
            if(p.args.empty()){
                if( p.comment.empty() ){
                    (*a) << p.op << endl;
                }else{
                    (*a) << setw(opwidth-1) << p.op << " "
                        << setw(argwidth) << "";
                }
            }else{
                (*a) << setw(opwidth-1) << p.op << " ";
                if( p.comment.empty() )
                    (*a) << p.args <<endl;
                else
                    (*a) << setw(argwidth-1) << p.args << " ";
            }
            if( p.comment.size() )
                (*a) << "# " << p.comment << endl;
        }
        remain = p.remain;
        //cout<<" iterate: remain = "<<remain<<endl;
    }
    return *this;
}
AsmFmtCols& AsmFmtCols::ins(string const& instruction, string const& asmcomment){
    throw_if_written(this,__FUNCTION__);
    if(asmcomment.empty() || asmcomment.find_first_not_of(ws) == string::npos){
        ins(instruction);
        return *this;
    }
    bool did_asmcomment = false;
    std::string remain = instruction;
    std::string comment;
    while( remain.size() ){
        auto const p = parts(remain);
        comment = p.comment;
        if( p.remain.empty() && p.comment.empty() ){
            comment = asmcomment;
            did_asmcomment = true;
            // if final instruction comes with a comment, then
            // push asmcomment to a separate line (as an rcom)
        }
        if(p.op.empty()){
            assert( p.args.empty() );
            if( p.comment.empty() )
                ins(); // blank line
            else
                (*a) << setw(inwidth+opwidth+argwidth) << "";
        }else{
            (*a) << left << indent;
            if(p.args.empty()){
                if( comment.empty() )
                    (*a) << p.op << endl;
                else
                    (*a) << setw(opwidth+argwidth-1) << p.op << " ";
            }else{
                (*a) << setw(opwidth-1) << p.op << " ";
                if( comment.empty() )
                    (*a) << p.args <<endl;
                else
                    (*a) << setw(argwidth-1) << p.args << " ";
            }
        }
        if( comment.size() ){
            (*a) << "# " << comment << endl;
        }
        remain = p.remain;
        //cout<<" iterate: remain = "<<remain<<endl;
    }
    if( !did_asmcomment )
        rcom(asmcomment);
#if 0
    // tellp also seemed buggy on Aurora
    //auto const sz0 = a->tellp();
    ins(instruction, false/*endline*/);
    cout<<"<continuing>"; cout.flush();
    (*a) << "<COMM>";
    //auto const sz1 = a->tellp();
    //auto const commcol = 4 + opwidth + argwidth;
    //if(sz1 < sz0 + commcol) (*a) << setw(commcol-(sz1-sz0)); // reposition comment?
    (*a) << "# " << asmcomment << endl;
#endif
    return *this;
}
string AsmFmtCols::fmt_def(std::string const& symbol, std::string const& subst, std::string const& name){
    std::ostringstream define;
    define << "#define " << setw(10) << symbol << ' ' << subst;
    //         ---8 ---
    if( name.size() == 0 ){
        define << "\n";
    }else{
        auto const col = 8 + std::max(symbol.size(),10UL) + 1 + subst.size();
        auto const wnt = inwidth + opwidth + argwidth - 9;
        if(col < wnt){
            define << setw(wnt - col) << "";
        }
        define << "/* " << name << " */\n";
    }
    return define.str();
}
void AsmFmtCols::StringPairs::push_trimmed(std::string name, std::string subst){
    push_back( std::make_pair(
                trim(name,  std::string(" \n\t\0",4)),
                trim(subst, std::string(" \n\t\0",4))
                ));
}
/** adds to 'global' scope, creating if nec. */
AsmFmtCols& AsmFmtCols::def(std::string const& symbol, std::string const& subst, std::string name){
    std::string sub = trim(subst, string(" \n\t\0",4));
    assert( stack_defs.size() == stack_undefs.size() );
    std::string namd = name;
    if( stack_undefs.empty() ){
        stack_defs.push_back(StringPairs());
        stack_undefs.push_back("");
        namd.append(" { GLOBAL SCOPE");
    }
    std::string define = fmt_def(symbol, sub, namd);
    (*a) << define;
    stack_undefs[0].append(fmt_undef(symbol,name));
    stack_defs  [0].push_trimmed(symbol, subst);
    return *this;
}
string AsmFmtCols::fmt_undef(std::string const& symbol,std::string const& name){
    string macroname = trim(symbol);
    auto end = macroname.find_first_of(" \n\t(");
    macroname = macroname.substr(0,end);
    ostringstream undef;
    if(name.empty()){
        undef << "#undef  " << macroname << "\n";
    }else{
        auto const wnt = inwidth + opwidth + argwidth - 9;
        undef << "#undef  " << left << setw(wnt-8) << macroname << "/* " << name << " */\n";
    }
    return undef.str();
}
AsmFmtCols& AsmFmtCols::undef(std::string const& symbol,std::string const& name){
    cerr<<" Warning: AsmFmtCols::undef("<<symbol<<","<<name<<") is deprecated"<<endl;
    (*a) << fmt_undef(symbol, name);
    // XXX remove from stack_[un]defs[0]
    return *this;
}
std::vector<std::pair<std::string,std::string>> AsmFmtCols::def_macs() const {
    vector<pair<string,string>> ret;
    if(parent)
        ret = parent->def_macs();
    for(auto const& vmac: stack_defs){
        for(auto const& d: vmac){       // d ~ vector<symbol,subst>
            ret.push_back(d);
        }
    }
    return ret;
}
std::string AsmFmtCols::mac_lookup(std::string macname) const {
    std::string ret;
    if(parent){
        ret=parent->mac_lookup(macname);
        if(!ret.empty())
            return ret;
    }
    for(auto const& vmac: stack_defs){
        for(auto const &d: vmac){   // d ~ vector<symbol,subst>
            //cout<<" mac_lookup for "<<macname<<" d=("<<d.first<<","<<d.second<<")"<<endl;
            if(d.first==macname){
                ret = d.second;
                return ret;
            }
        }
    }
    return ret;
}
std::vector<string> AsmFmtCols::def_words_starting(std::string with) const {
    std::vector<string> ret;
    if(parent)
        ret = parent->def_words_starting(with);
    size_t const with_sz = with.size();
    for(auto const& vmac: stack_defs){
        for(auto const& d: vmac){                // d ~ vector<symbol,subst>
            std::string const& s = d.second;
            if(s.compare(0,with_sz, with) == 0){
                ret.push_back(s);
            }
        }
    }
    //cout<<" found "<<ret.size()<<" substitution-first-words beginning with "<<with<<endl;
    return ret;
}
vector<pair<string,string>> AsmFmtCols::def_macs_starting(std::string with) const {
    vector<pair<string,string>> ret;
    if(parent)
        ret = parent->def_macs_starting(with);
    size_t with_sz = with.size();
    for(auto const& vmac: stack_defs){
        for(auto const& d: vmac){                // d ~ vector<symbol,subst>
            std::string const& s = d.second;
            if(s.compare(0,with_sz, with) == 0){
                //ret.push_back(static_cast<const pair<string,string>&>(d));
                ret.push_back(d);
            }
        }
    }
    //cout<<" found "<<ret.size()<<" substitution-first-words beginning with "<<with<<endl;
    return ret;
}
std::string AsmFmtCols::defs2undefs( StringPairs const& macs, std::string block_name ){
    AsmFmtCols undefs;
    {
        std::string comment;
        std::string end_comment = "} END ";
        end_comment.append(block_name);
        auto const mend = macs.crend();
        auto       mdef = macs.crbegin();
        for( ; mdef != mend; ){
            auto macro = mdef->first;   // the macro name (and args!?)
            ++mdef;
            if( mdef == mend ){
                comment = end_comment;
            }
            (*undefs.a)<<fmt_undef(macro,comment);
        }
        if(comment.empty()){
            rcom(end_comment);
        }
    }
    return undefs.flush(); // equiv str() + clear
}
std::string uncomment_asm( std::string asmcode )
{
    // for multiline, we need a bit more than just 'parts(instruction)'
    std::string remain = asmcode;
    //cout<<" remain = "<<remain<<endl;
    std::ostringstream oss;
    while( remain.size() ){
        auto const p = AsmFmtCols::parts(remain);
        if(p.op.size() == 0){
            oss<<endl; /* reproduce blank lines*/
        }else{
            // ignore p.comment
            if(p.args.empty()){
                oss << p.op << endl;
            }else{
                oss << p.op << ' ' << p.args <<endl;
            }
        }
        remain = p.remain;
        //cout<<" iterate: remain = "<<remain<<endl;
    }
    return oss.str();
}
AsmFmtVe& AsmFmtVe::set_vector_length(uint64_t const vl){
    if(vl > 256) THROW("VE vector length must in [0,256]");
    std::string sN = jitdec(vl);
    if(vl > 127){
        AsmScope block;
        ve_propose_reg("tmp",block,*this,SCALAR_TMP);
        cout<<" --> block.size="<<block.size();
        if(!block.empty()) scope(block);
        ins("lea tmp, "+sN+"; lvl tmp");
        if(!block.empty()) pop_scope();
    }else{
        ins("lvl "+sN);
    }
    return *this;
}
/** always 1-op if vlen is known to be in a register. */
AsmFmtVe& AsmFmtVe::set_vector_length(std::string vlen){
    if(vlen.compare(0,2,"%s")==0){
        ins("lvl "+vlen);
        return *this;
    }
    // also ok to pass a string constant.
    std::istringstream iss(vlen);
    uint64_t vl64;
    iss>>vl64;
    if(iss.fail()) THROW("vlen must start with %s or be an integer [0,"<<MVL<<"]");
    if(vl64 > MVL) THROW("vlen "<<vl64<<" out of range [0,"<<MVL<<"]");
    return set_vector_length(vl64);
}

std::string ve_load64_opt0(std::string s, uint64_t v){
    uint32_t const vlo = uint32_t(v);
    uint32_t const vhi = uint32_t(uint32_t(v>>32) + ((int32_t)v<0? 1: 0));
    std::ostringstream oss;
    bool const is31bit = ( (v&(uint64_t)0x000000007fffFFFFULL) == v );
    char const * comment=" sign-extended ";
    if( is31bit                                 // 31-bit v>=0 is OK for lea
            || ( (int)vlo<0 && (int)vhi==-1 ))  // if v<0 sign-extended int32_t, also happy
    {
        if( is31bit ) comment=" ";
        oss <<"\tlea    "<<s<<", "<<jithex(vlo)<<"\n";
    }else{
        oss <<"\tlea    "<<s<<", "<<jithex(vlo)<<"\n"
            <<"\tand     "<<s<<", "<<s<<", (32)0\n"
            <<"\tlea.sl "<<s<<", "<<jithex(vhi)<<"(,"<<s<<")";
        comment=" ve_load64_opt0 ";
    }
    oss<<" #"<<comment<<s<<" = "<<jithex(v);
    return oss.str();
}
std::string ve_signum64(std::string out, std::string in){
    ostringstream oss;
    oss<<"sra.l "<<out<<","<<in<<",63";
    return oss.str();
}
std::string ve_abs64(std::string out, std::string in){
   ostringstream oss;
   /*
     Found a 2-operation program:
     sub   r1,0,rx
     max   r2,r1,rx
     Expr: max((0 - x), x)

     Found a 2-operation program:
     sub   r1,0,rx
     cmovgt r2,r1,r1,rx
     Expr: cmovgt((0 - x), (0 - x), x)

     Found a 2-operation program:
     sub   r1,0,rx
     cmovlt r2,rx,r1,r1
     Expr: cmovlt(x, (0 - x), (0 - x))
    */
    //oss<<"subs.l "<<out<<",0/*I*/,"<<in;
    //oss<<"; maxs.l "<<out<<","<<out<<","<<in;
    oss<<"sub "<<out<<",0,"<<in
        <<"; cmovgt "<<out<<","<<out<<","<<in; // VE operation is: Sx = (Sy>0? Sx: Sz)
    return oss.str();
}
void ve_set_base_pointer( AsmFmtCols & a, std::string bp/*="%s34"*/, std::string name/*="foo"*/ ){
    a.def("STR0(...)", "#__VA_ARGS__")
        .def("STR(...)",  "STR0(__VA_ARGS__)")
        .def("CAT(X,Y)", "X##Y")
        .def("FN",name)             // func name (characters)
        .def("FNS", "\""+name+"\"") // quoted-string func name
        .def("L(X)", "CAT("+name+"_,X)")
        .def("BP",bp,            "base pointer register")
        ;
        // macros for relocatable branching
    a.def("REL(YOURLABEL)", "L(YOURLABEL)-L(BASE)(,BP)", "relocatable address of 'here' data")
        ;
        // The following is needed if you use branches
    a.ins("sic   BP","%s1 is *_BASE, used as base ptr")
        .lab("L(BASE)")     // this label is reserved
        .rcom("Now a relative jump looks like:")
        .rcom("   ins(\"b.l REL(JumpAddr)\")")
        .rcom("   lab(\"L(JumpAddr)\")")
        ;
}
/** VE lea logic */
static void opLoadreg_lea(OpLoadregStrings& ret, uint64_t const parm){
    uint32_t const hi = ((parm >> 32) & 0xffffFFFF); // unsigned shift-right
    uint32_t const lo = (uint32_t)parm;              // 32 lsbs (trunc)
    bool is31bit = ( (parm&(uint64_t)0x000000007fffFFFF) == parm );
    //bool is32bit = ( (parm&(int64_t) 0x00000000ffffFFFF) == parm );
    bool hiOnes  = ( (int)hi == -1 );
    if(is31bit){
        //KASE(1,"lea 31-bit",parm == (parm&0x3fffFFFF));
        ret.lea="lea OUT, "+(lo<=1000000? jitdec(lo): jithex(lo))
            +"# load: 31-bit";
    }else if((int)lo < 0 && hiOnes){
        assert( (int64_t)parm < 0 ); assert((int)lo < 0);
        //KASE(2,"lea 32-bit -ve",parm == (uint64_t)(int64_t)(int32_t)lo);
        ret.lea="lea OUT, "+((int64_t)parm >= -100000? jitdec((int32_t)lo): jithex(lo))
            +"# load: sext(32-bit)";
    }else if(lo==0){
        //KASE(3,"lea.sl hi only",lo == 0);
        ret.lea="lea.sl OUT, "+jithex(hi)+"# load: hi-only";
    }
    //
    // 2-instruction lea is always possible (TODO mixed instruction types)
    //
    //uint64_t tmplo = (int64_t)(int32_t)lo;
    // lea.sl OUT, <hi or hi+1> (,TMP)
    //        -ve lo will fill hi with ones i.e. -1
    //        so we add hi+1 to MSBs to restore desired sums
    uint64_t dd = ((int32_t)lo>=0? hi: hi+1);
    //uint64_t tmp2 = tmphi << 32;    // (sext(D,64)<<32)
    //uint64_t out = tmp2 + tmplo;     // lea.sl lea_out, tmphi(,lea_out);
    //assert( parm == out );
    // Changed:  do not use a T0 tmp register
    string comment("# ");
    comment += (dd!=hi?"Xld ":" ld ")+jithex(parm);
    //ret.lea2="lea OUT, "+jithex(lo)+comment; // VE expr size error?
    ret.lea2 = "lea OUT, ";
    ret.lea2 += jithex(lo);
    ret.lea2 += comment;
    ret.lea2 += " ; lea.sl OUT, "+jithex(dd)+"(,OUT)";
}
static void opLoadreg_log(OpLoadregStrings& ret, uint64_t const parm){
    /** VE bit ops logic */
    uint64_t const lo7 = (parm & 0x7f);              // 7 lsbs (trunc)
    int64_t  const sext7 = (int64_t)(lo7<<57) >> 57; // 7 lsbs (trunc, sign-extend)
    // simple cases: I or M zero
    bool isI = (int64_t)parm >= -64 && (int64_t)parm <= 63; // I : 7-bit immediate
    bool isM = isMval(parm); // M : (m)B 0<=m<=63 B=0|1 "m high B's followed by not-B's"
    if(isI){
        //KASE(4,"or OUT,"+jitdec(sext7)+",(0)1", parm==sext7);
        ret.log="or OUT, "+jitdec(sext7)+",(0)1 # load: small I";
    }else if(isM){
        //KASE(5,"or OUT,0,"+jitimm(parm), isMval(parm));
        ret.log="or OUT, 0,"+jitimm(parm)+"# load: (M){0|1}";
    }
    //if(isMval(parm&~0x3f)){...}
    // KASE 6 subsumed by KASE 9 (equivalent I, M)
    else if(isMval(parm|0x3f)){
        assert( isMval(parm^sext7) ); // more general, but this is more readable
        uint64_t const ival = (~parm &0x3f);
        uint64_t const mval = parm|0x3f;
        //KASE(7,"xor OUT, ~parm&0x3f "+jithex(ival)+", parm|0x3f "+jitimm(mval),
        //        parm == (ival ^ mval) && isIval(ival) && isMval(mval));
        ret.log="xor OUT, ";
        ret.log += jithex(ival);
        ret.log += ",";
        ret.log += jitimm(mval);
        ret.log += "# load: xor(I,M)";
    }else if(isMval(parm^sext7) ){ // xor rules don't depend on sign of lo7
        // if A = B^C, then B = A^C and C = B^A (Generally true)
        //int64_t const ival = sext7;
        uint64_t const mval = parm^sext7;
        //KASE(9,"xor OUT, "+jithex(ival)+","+jitimm(mval),
        //        parm == (ival ^ mval) && isIval(ival) && isMval(mval));
        ret.log="xor OUT, ";
        ret.log += jitdec(sext7);
        ret.log += ",";
        ret.log += jitimm(mval);
        ret.log += "# load: xor(I,M)";
    }
    if(!ret.log.empty()) ret.log.append(" --> "+jithex(parm));
}
/** Find possible 64-bit VE scalar register load instructions.
 * \return instruction string[s] to load a 64-bit scalar VE register.
 * You can supply such strings into AsmFmtCols for nice formatting.
 * Within the returned strings, \c OUT is the output register.
 * no temp register is used. */
OpLoadregStrings opLoadregStrings( uint64_t const parm )
{
    OpLoadregStrings ret;
    opLoadreg_lea(ret, parm); // get lea and lea2 strings
    opLoadreg_log(ret, parm); // get or/xor (logical) loads

    { // shift left
        // search for an unsigned right-shift that can regenerate parm
        int oksr=0;
        for(int sr=1; sr<64; ++sr){
            if( parm == (parm>>sr<<sr) && isMval(parm>>sr) ){
                oksr=sr; // use smallest shift
                break;
            }
        }
        if(oksr){
            uint64_t mval = parm >> oksr;
            //KASE(19,"sll OUT,"+jitimm(mval)+","<<jitdec(oksr),
            //        parm == (mval << oksr) && isMval(mval));
            ret.shl="sll OUT, "+jitimm(mval)+","+jitdec(oksr);
        }
    }
    { // arithmetic ops (+,-)
        if(ret.ari.empty()) for( int64_t ival = 0; ret.ari.empty() && ival<=63; ++ival ){
            // P = I + M <===> M == P - I
            uint64_t const mval = parm - (uint64_t)ival;
            if( isMval(mval) ){
                //KASE(20,"addu.l OUT,"+jitdec(ival)+", "+jitimm(mval),
                //        parm == ival + mval && isIval(ival) && isMval(mval));
                ret.ari="addu.l OUT, ";
                ret.ari += jitdec(ival);
                ret.ari += ",";
                ret.ari += jitimm(parm-ival);
                ret.ari += "# load: add(I,M)";
                break;
            }
        }
        if(ret.ari.empty()) for( int64_t ival = -1; ret.ari.empty() && ival>=-64; --ival ){
            uint64_t const mval = parm - (uint64_t)ival;
            if( isMval(mval) ){
                //KASE(21,"addu.l OUT,"+jitdec(ival)+","+jitimm(mval),
                //        parm == ival + mval && isIval(ival) && isMval(mval));
                ret.ari="addu.l OUT, ";
                ret.ari += jitdec(ival);
                ret.ari += ",";
                ret.ari += jitimm(parm-ival);
                ret.ari += "# load: add(I,M)";
                break;
            }
        }
        // Q; Is it correct that SUB (unsigned subtract) still
        //    sign-extends the 7-bit Immediate in "Sy" field?
        if(ret.ari.empty()) for( int64_t ival = 0; ret.ari.empty() && ival<=63; ++ival ){
            // P = I - M <==> M = I - P
            uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
            if( isMval(mval) ){
                //uint64_t out = (uint64_t)ival - (uint64_t)mval;
                //KASE(22,"subu.l OUT,"+jitdec(ival)+","+jitimm(mval),
                //        parm == out  && isIval(ival) && isMval(mval));
                ret.ari="subu.l OUT, ";
                ret.ari += jitdec(ival);
                ret.ari += ",";
                ret.ari += jitimm(mval);
                ret.ari += "# load: subu(I,M)";
                break;
            }
        }
        if(ret.ari.empty()) for( int64_t ival = -1; ret.ari.empty() && ival>=-64; --ival ){
            uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
            if( isMval(mval) ){
                //uint64_t out = (uint64_t)ival - (uint64_t)mval;
                //KASE(23,"subu.l OUT, "+jitdec(ival)+","+jitimm(mval),
                //        parm == out  && isIval(ival) && isMval(mval));
                ret.ari="subu.l OUT, ";
                ret.ari += jitdec(ival);
                ret.ari += ",";
                ret.ari += jitimm(mval);
                ret.ari += "# load: subu(I,M)";
                break;
            }
        }
        if(!ret.ari.empty()) ret.ari.append(" --> "+jithex(parm));
    }
    return ret;
}

std::string choose(OpLoadregStrings const& ops, void* /*context=nullptr*/)
{
    enum Optype { SHL, LEA, LOG, ARI, LEA2 };
    static std::array<Optype, 5> const pref = {SHL, LEA, LOG, ARI, LEA2};
    string code;
    for(auto const optype: pref){
        code = (optype==LEA? ops.lea
                :optype==LOG? ops.log
                :optype==SHL? ops.shl
                :optype==ARI? ops.ari
                : ops.lea2);
        if( !code.empty() ){
            break;
        }
    }
    return code;
}
std::string ve_load64(std::string s, uint64_t v){
    return multiReplace("OUT", s,
            choose(opLoadregStrings(v)));
}

/** This is the lowest-level worker routine. */
void ve_propose_reg( std::string variable, AsmScope& block, AsmFmtCols const& a,
        std::string prefix,
        std::vector<std::pair<int,int>> const search_order){
    if(a.allow_alias()){
        // 1. is \c variable already defined? Can we alias it based on name?
        size_t const prefix_sz = prefix.size();
        // vps ~ vector pair strings
        auto vps = a.def_macs(); // all known macros
        cout<<" ("<<vps.size()<<" known macs)";
        for(auto const& ps: vps){
            cout<<" "<<ps.first;
            if(ps.first == variable){
                cout<<" macro name MATCH! ("<<ps.first<<","<<ps.second<<")";
                cout<<" ? compat with "<<prefix<<" sz "<<prefix_sz<<"]?";
                if(0 == ps.second.compare(0,prefix_sz,prefix)){
                    cout<<" Compatible alias found: "<<ps.first
                        <<" already defined as "<<ps.second<<endl;
                    return;
                }
            }
        }
        cout<<"\n("<<variable<<" is new)";
    }
    // 2. amongst all existing registers (macro definition strings)
    //    beginning with prefix, select a new one by adding numeric
    //    suffix using search_order {pair[lo,hi]} inclusive ranges.
    auto vs = a.def_words_starting(prefix); // anything already within scope*s*?
    for(auto const& pre: block){ // for things we ARE GOING TO allocate
        // would this be a macro redefine?
        vs.push_back( pre.second );
    }
    std::string register_name = free_pfx(vs,prefix,search_order);
    if(register_name.empty()) THROW("Out of registers");
    block.push_back({variable,register_name});
}

// VE note: %s12 : "Outer register, used for pointing start addr of called fn"
//          %s13 : "Used to pass id of function to dynamic linker"
//          are both not preserved in C ABI
static std::vector<std::pair<int,int>> const scalar_order_fwd{{0,7},{34,63},{12,13},{18,33}};
static std::vector<std::pair<int,int>> const scalar_order_bwd{{63,34},{7,0},{13,12},{33,18}};
static std::vector<std::pair<int,int>> const vector_order_fwd{{0,63}};
static std::vector<std::pair<int,int>> const vector_order_bwd{{63,0}};

void ve_propose_reg( std::string variable, AsmScope& block, AsmFmtCols const& a, RegSearch const how ){
    std::vector<std::pair<int,int>> const* order = nullptr;
    char const* pfx = nullptr;
    switch(how){
      case(SCALAR)    : pfx="%s"; order=&scalar_order_fwd; break;
      case(SCALAR_TMP): pfx="%s"; order=&scalar_order_bwd; break;
      case(VECTOR)    : pfx="%v"; order=&vector_order_fwd; break;
      case(VECTOR_TMP): pfx="%v"; order=&vector_order_bwd; break;
    }
    assert( order != nullptr );
    ve_propose_reg( variable, block, a, pfx, *order );
}
#endif //CODEREMOVE < 1

// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
#include "vechash.hpp"
#include "codegenasm.hpp" // really?
#include "stringutil.hpp"
#include "asmfmt.hpp"
#include "cblock.hpp"
#include <list>
#include <utility>
#include <string>
#include <sstream>

#include <iostream>
using namespace std;

namespace scramble64 {
    uint64_t const r1 = 7664345821815920749ULL;
    uint64_t const r2 = 1181783497276652981ULL;
    uint64_t const r3 = 3202034522624059733ULL;
}

static std::vector<std::pair<int,int>> const vechash_scalar_order{{40,63},{39,34},{7,0},{33,18},{12,13}};
static std::vector<std::pair<int,int>> const vechash_vector_order{{40,63},{39,0}};

/** custom register assignment order, hopefully distinctive from ve_propose_reg defaults */
static void vechash_scalar(std::string variable, AsmScope& block, AsmFmtCols const& a){
    ve_propose_reg(variable,block,a,"%s",vechash_vector_order);
}
static void vechash_vector(std::string variable, AsmScope& block, AsmFmtCols const& a){
    ve_propose_reg(variable,block,a,"%v",vechash_vector_order);
}

/** Note: assume that current vl is max we'll every see, for purposes
 * of initializes vs={0,1,2,...vl} */
void VecHash::kern_asm_begin( AsmFmtCols &a, char const* client_vs/*=nullptr*/,
        uint32_t const seed/*=0*/ ){
    if(0){
        cout<<" VecHash::kern_asm_begin"<<endl;
        auto vs = a.def_words_starting("%s");
        auto vv = a.def_words_starting("%v");
        cout<<" parent scalars = {";for(auto s:vs) cout<<" "<<s; cout<<" }"<<endl;
        std::string free_scalar_register = free_pfx( vs, "%s", {{0,7},{63,34}} );
        cout<<" I suggest free_scalar_register = "<<free_scalar_register<<endl;
        cout<<" parent vectors = {";for(auto s:vv) cout<<" "<<s; cout<<" }"<<endl;
    }
    AsmScope block = {}; //{"hashval","%s40"},
    vechash_scalar("rnd64a",block,a);   // const (may move up)
    vechash_scalar("rnd64b",block,a);   // const (can also be colocated)
    vechash_scalar("vh_j",  block,a);   // state (cannot migrate up)
    vechash_vector("vh_x",  block,a);   // state (cannot migrate up)
    if(client_vs) block.push_back({"vh_vs",client_vs});
    else          vechash_vector ("vh_vs",block,a);
    a.scope(block,"VecHash::kern_asm registers");
    // const regs
    if(!client_vs){
        // vh_vs really should be 0..MVL-1, for most safety.
        a.ins("lvl rnd64a; lea rnd64b,256; svl rnd64b; vseq vh_vs; lvl rnd64a"
                ,"vh_vs=0,1,..,MVL-1");
    }
    a.ins(ve_load64("rnd64a", scramble64::r1));
    a.ins(ve_load64("rnd64b", scramble64::r2));
    // state (R/W regs)
    a.ins(ve_load64("vh_j", (uint64_t)seed<<32));
    a.ins("vbrd vh_x,0");
    a.com("VecHash : init done");
}
void VecHash::kern_asm( AsmFmtCols &a,
        std::string va, std::string vl, std::string hash ){
    a.lcom("VecHash : kernel begins",
            "  in: "+va+", "+vl,
            "  inout: "+hash+" (scalar reg)",
            "  state: vh_j",
            "  const: rnd64a, rnd64b, vh_vs",
            "  scratch: vh_r, vh_vx, vh_vy, vh_vz"
          );
    // TODO: resolve any conflicts of scope regs with ANY 
    AsmScope const block = {{"vh_r","%s63"}
        ,{"vh_vx","%v63"},{"vh_vy","%v62"}//,{"vh_vz","%v63"}
    };
    a.scope(block,"vechash2::kern_asm");
    a.ins("vaddu.l  vh_vy, vh_j, vh_vs");
    a.ins("vmulu.l  vh_vy, rnd64a, vh_vz",           "scramble64::r1 * (j+vs[])");
    a.ins("vmulu.l  vh_vx, rnd64b, /**/"+va,         "scramble64::r2 * "+va+"[]");
    a.ins("vaddu.l  vh_vx, vh_vx, vh_vz",           "sum");
    a.ins("vrxor    vh_vy, vh_vx");
    a.ins("lvs      vh_r, vh_vy(0)",                "r = xor-reduction(vx)");
    a.ins("addu.l   vh_j, vh_j, vl",                "state j += vl");
    a.com("output: modified hash value "+hash);
    a.ins("xor      /**/"+hash+", "+hash+", vh_r",  hash+" ^= r");
    a.pop_scope();
    a.lcom("VecHash : kernel done");
}
void VecHash::kern_asm_end( AsmFmtCols &a ){
    a.pop_scope();
}

/** init registers for VecHash2 assembler kernel.
 * Current vector length \b MUST be the maximum vector length of this hash_combiner.
 * \p seed an optional seed value.
 * \note if client has {0,...,vl} available this could be passed (saving register vs[])
 *
 * TODO: look at all scopes of parent 'a' to allocate non-conflicting state regs
 */
void VecHash2::kern_asm_begin( AsmFmtCols &ro_regs, AsmFmtCols &state,
        char const* client_vs/*=nullptr*/, uint32_t const seed/*=0*/ )
{
    // read-only register constants (move up as far as possible)
    AsmScope block; // empty
    {
        // vechash has no subroutines, so try for a distinct group of regs
        // const
        vechash_scalar("rnd64a",block,state);   // const (may move up)
        vechash_scalar("rnd64b",block,state);   // const (can also be colocated)
        vechash_scalar("rnd64c",block,state);   // const (can also be colocated)
        if(client_vs) block.push_back({"vh_vs",client_vs}); // ideally 0,1,...,MVL-1
        else          vechash_vector ("vh_vs",block,state);
        ro_regs.scope(block,"const: vechash2");
        if(!client_vs){
            ro_regs.ins("svl rnd64a#rnd* as tmp regs..; lea rnd64b,256; lvl rnd64b; vseq vh_vs; svl rnd64a"
                    ,"..vh_vs=0,1,..,MVL-1");
        }
        ro_regs.ins(ve_load64("rnd64a", scramble64::r1),"scramble64::r1");
        ro_regs.ins(ve_load64("rnd64b", scramble64::r2),"scramble64::r2");
        ro_regs.ins(ve_load64("rnd64c", scramble64::r3),"scramble64::r3");
    }
    block.clear();
    // state register init
    {
        vechash_scalar("vh2_j",  block,state);  // state (cannot migrate up)
        // TBD: vechash_vector("vh_x",  block,state);   // state (cannot migrate up)
        state.scope(block,"state: vechash2");
        // const
        // Note: our persistent context registers are now published
        //       within the client's scope stack ...
        //       we pop_scope them during kern_asm_end
        // state
        state.ins(ve_load64("vh2_j", (uint64_t)seed<<32),"j=(u64)seed<<32");
        // TBD: vector state
        //state.ins("vbrdl vh_x,0","vechash2 state init DONE");
    }
}
// XXX multiple usages clash on redefinition of rnd64a etc.
// XXX recast with 'outer' and 'inner' blocks so rnd64a,b,c defined only once.
// XXX    or      'const' and 'state' blocks
// ? "search prev code for string" operation ?
void VecHash2::kern_C_begin( cprog::Cblock &outer
        , cprog::Cblock &inner
        , cprog::Cblock &defines
        , char const* client_vs/*=nullptr*/
        , uint32_t const seed/*=0*/ )
{
    ostringstream oss;
    auto& cc=(outer.getName()=="first"? outer: outer["..*/body/../first"]);
    auto& init  = inner["..*/first"];
    auto& state = defines["last"]["vechash"];
    cout<<"kern_C_begin("<<outer.fullpath()<<","
        <<defines.fullpath()<<",...) using "
        <<"\n\tcc@"<<cc.fullpath()<<"\n\tinit@"<<init.fullpath()
        <<"\n\tstate@"<<state.fullpath()<<endl;

    if(!cc.find("VecHash2_rnd")){
        cc["VecHash2_rnd"]
            >>OSSFMT("uint64_t const rnd64a = "<<scramble64::r1<<"ULL;")
            >>OSSFMT("uint64_t const rnd64b = "<<scramble64::r2<<"ULL;")
            >>OSSFMT("uint64_t const rnd64c = "<<scramble64::r3<<"ULL;")
            //>>OSSFMT(left<<setw(40)<<"uint64_t vh2_j;"<<" // vh2 state")
            ;
    }

    if(!init.find("VecHash2_state")){
        auto instr=OSSFMT("uint64_t vh2_j = "<<jithex((uint64_t)seed<<32)<<"ULL;");
        init["VecHash2_state"]
            >>OSSFMT(left<<setw(40)<<instr<<" // vh2 state")
            >>"uint64_t vh2_hash = 0;";
    }

    if(client_vs){ // client has a vseq=0..MVL ?
        defines.define("vh_vs",client_vs);
    }else{
        if(!cc.find("VecHash2_seq")){
            cc["VecHash2_seq"]
                >>OSSFMT("__vr const vh_vs = _vel_vseq_v(256); // vh2 vseq");
        }
    }
}
void VecHash2::kern_C( cprog::Cblock &parent,
        std::string va, std::string vb, std::string vl, std::string hash)
{
    ostringstream oss;
    CBLOCK_SCOPE(vh,"",parent.getRoot(),parent);
    vh  >>"// vechash2 : kernel begins"
        >>OSSFMT("//  in: 2 u64 vectors "<<va<<", "<<vb<<", VL="<<vl)
        >>OSSFMT("//  inout: "<<hash<<" (scalar reg)")
        >>OSSFMT("//  state: vh2_j")
        >>OSSFMT("//  const: rnd64a, rnd64b, rnd64c, vh_vs")
        >>OSSFMT("//  scratch: vh2_r, vh2_vx, vh2_vy, vh2_vz")
        ;
    vh  >>OSSFMT("__vr vh2_vx = _ve_vmulul_vsv(rnd64b,"<<va<<");")
        >>"__vr vh2_vy = _ve_vaddul_vsv(vh2_j,vh_vs); // init state j"
        >>OSSFMT("__vr vh2_vz = _ve_vmulul_vsv(rnd64b,"<<vb<<");")
        >>"vh2_vy = _ve_vmulul_vsv(rnd64a,vh2_vy);"
        >>"vh2_vx = _ve_vaddul_vvv(vh2_vx,vh2_vz);"
        >>"vh2_vz = _ve_vaddul_vvv(vh2_vx,vh2_vy);    // vz ~ sum of xyz scrambles"
        >>"vh2_vx = _ve_vsuml_vv(vh2_vz);             // vrxor missing"
        >>"uint64_t vh2_r = _ve_lvs_svs_u64(vh2_vx,0);"
        //>>OSSFMT(hash<<" = "<<hash<<" ^ vh2_r")
        >>OSSFMT("vh2_hash = vh2_hash ^ vh2_r")
        >>OSSFMT("vh2_j += "<<vl)
        ;
}
std::pair<std::string,std::string> VecHash2::kern_C_macro(std::string macname)
{
    std::string mac,def;
    ostringstream oss;
    mac=OSSFMT(macname<<"(VA,VB,VL,HASH)");
    oss <<"do{ \\\n"
        //"    asm(\"# vechash2 BEGIN\"); \\\n"
        "    /* vechash2 : kernel begins */ \\\n"
        "    /*  in: 2 u64 vectors VA, VB, common VL */ \\\n"
        "    /*  inout: HASH (scalar reg) */ \\\n"
        "    /*  state: vh2_j (scalar) */ \\\n"
        "    /*  const: rnd64a, rnd64b, rnd64c, vh_vs */ \\\n"
        "    /*  scratch vectors: vh2_vx, vh2_vy, vh2_vz */ \\\n"
        "    /*  scratch scalars: vh2_r */ \\\n"
        "    __vr vh2_vx = _ve_vmulul_vsv(rnd64b,VA); \\\n"
        "    __vr vh2_vy = _ve_vaddul_vsv(vh2_j,vh_vs); /* init state j */ \\\n"
        "    __vr vh2_vz = _ve_vmulul_vsv(rnd64b,VB); \\\n"
        "    vh2_vy = _ve_vmulul_vsv(rnd64a,vh2_vy); \\\n"
        "    vh2_vx = _ve_vaddul_vvv(vh2_vx,vh2_vz); \\\n"
        "    vh2_vz = _ve_vaddul_vvv(vh2_vx,vh2_vy);    /* vz~sum xyz */ \\\n"
        "    /*vh2_vx = _ve_vrxor_vv(vh2_vz);*/         /* missing op */ \\\n"
        "    vh2_vx = _ve_vsuml_vv(vh2_vz);             /* ..instead */ \\\n"
        "    uint64_t vh2_r = _ve_lvs_svs_u64(vh2_vx,0); \\\n"
        "    vh2_j += VL; \\\n"
        "    HASH = HASH ^ vh2_r; \\\n"
        //"    asm(\"# vechash2 END\"); \\\n"
        "}while(0)"
        ;
    def = oss.str();
    //return make_pair(mac,def);
    return {mac,def};
}
void VecHash2::kern_C_end( cprog::Cblock &cb ){
}
/** input strings are registers.
 * \c va, \c vb (vectors) of length \c vl (scalar) are to be mixed in
 * with our current hash context. The resulting hash value is placed into
 * \c hash (scalar). Client gives us one \c tmp reg (which will hold the
 * xor-reduction value upon exit). */
void VecHash2::kern_asm( AsmFmtCols &a,
        std::string va, std::string vb, std::string vl, std::string hash,
        std::string tmp ){
    a.lcom("vechash2 : kernel begins",
            "  in: "+va+", "+vb+", "+vl,
            "  inout: "+hash+" (scalar reg)",
            "  state: vh2_j",
            "  const: rnd64a, rnd64b, rnd64c, vh_vs",
            "  scratch: vh2_r, vh2_vx, vh2_vy, vh2_vz"
          );
    AsmScope block; // empty
    //ve_propose_reg("vh2_r" ,block,a,SCALAR_TMP);
    ve_propose_reg("vh2_r" ,block,a,SCALAR_TMP);
    ve_propose_reg("vh2_vx",block,a,VECTOR_TMP);
    ve_propose_reg("vh2_vy",block,a,VECTOR_TMP);
    ve_propose_reg("vh2_vz",block,a,VECTOR_TMP);
    a.scope(block,string{"vechash2::kern_asm"});
    // a[], b[] --> vector hash for a,b at sequence position j
    a.ins("vmulu.l  vh2_vx, rnd64b, /**/"+va,       "scramble64::r2 * "+va+"[]");
    a.ins("vaddu.l  vh2_vy, vh2_j, vh_vs",          "init for state j");
    a.ins("vmulu.l  vh2_vz, rnd64c, /**/"+vb,       "scramble64::r3 * "+vb+"[]");
    a.ins("vmulu.l  vh2_vy, rnd64a, vh2_vy",        "scramble64::r1 * (j+vs[])");
    a.ins("vaddu.l  vh2_vx, vh2_vx, vh2_vz");
    a.ins("vaddu.l  vh2_vz, vh2_vx, vh2_vy",        "vz ~ sum xyz scrambles");
    //
    // ---------------- BEWARE -------------------
    //
    // I had a tough bug to crack once, here.
    // LVL = "Load Vector Length"  <-- use this to set the vector length
    // SVL = "Save Vector Length"  ( **not** "Set" )
    //
    // In gdb, you can double-check vl with "info reg vl"
    //
    // vector hash --> scalar hash (xor-reduce)
    a.ins("vrxor    vh2_vx, vh2_vz",                "vy[0] = vz[0]^vz[1]^...");
    a.ins("lvs      vh2_r, vh2_vx(0)",              "r = xor-reduction(vx)");
    a.ins("addu.l   vh2_j, "+vl+", vh2_j",          "state j += vl (seq pos)");
    a.com("output: modified hash value "+hash);
    a.ins("xor      /**/"+hash+", "+hash+", vh2_r", hash+" ^= r");
    a.pop_scope();
    a.lcom("vechash2 : kernel done");
}
void VecHash2::kern_asm_end( AsmFmtCols &a ){
    a.pop_scope();
}
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
#include "cblock.hpp"
#include "stringutil.hpp"

// cblock.hpp can give large compilation times for nc++ inlining... so
// make this file non-empty to help speed compilation

namespace cprog{

std::string ve_pragma_unroll(int64_t const N){
    std::string ret(""); // return empty if N<0
    if(N==0) return "#pragma nounroll\n";
    else if(N>0){
        std::ostringstream oss;
        ret = OSSFMT("#pragma unroll("<<N<<")\n");
    }
    return ret;
}

Cblock& Cblock::append(std::string codeline){
    if( !codeline.empty() ){
#if 0 // trial...
        // to technically allow building up a single statement, we only
        // stick in new line if the last line of _code contains a ';'
        if( !_code.empty() ){
            size_t lastline=_code.find_last_of('\n');
            if( lastline == std::string::npos ) lastline=0; else ++lastline;
            if(_code.find_first_of(";",lastline) != std::string::npos)
                _code.append("\n");
        }
#endif
        _code.append(codeline);
    }
    return *this;
}
Cblock& Cblock::operator>>(std::string codeline){
    return append("\n").append(codeline);
}

Cblock& Cblock::append(Cblock &cb){
    int const __attribute__((unused)) v=0;
    CBLOCK_DBG(v,3," append! "<<std::endl);
    assert(_parent != nullptr );
    CBLOCK_DBG(v,10," this@"<<_parent->_name<<"/"<<_name<<" append");
    CBLOCK_DBG(v,10," (cb@"<<cb._name<<")\n");
    cb._parent = this;

    auto last_spot = _sub.end();
    if( !_sub.empty() && _sub.back()->getName()=="last")
        --last_spot;
    _sub.insert(last_spot, &cb);

    CBLOCK_DBG(v,10," this@"<<_parent->_name<<"/"<<_name<<"{");
    if(v>=5){ for(auto s: _sub) std::cout<<" "<<s->_name; std::cout<<std::endl; }
    CBLOCK_DBG(v,10,"}"<<std::endl);
    return cb; // new behaviour
}
std::string Cblock::fullpath() const {
    int const __attribute__((unused)) v=0;
    CBLOCK_DBG(v,1," fullpath!"<<std::endl;);
    std::string out;
    out.reserve(256);
    int ncomp=0; // number of path components
    for(Cblock const * cb=this; cb!=nullptr; cb  = cb->_parent){
        CBLOCK_DBG(v,1," fp:"<<cb->_name<<" parent:"<<(cb->_parent? cb->_parent->_name: "NULL"));
        if( cb->isRoot() ){
            CBLOCK_DBG(v,1," isRoot");
            out.insert(0,"/");
            break;
        }else{
            CBLOCK_DBG(v,1," notRoot");
            CBLOCK_DBG(v,1," _name["<<_name<<"]"<<std::endl);
            size_t const cbsz = cb->_name.size();
            out.insert(0,cb->_name.c_str(),cbsz+1); // include terminal null
            out.replace(cbsz,1,1,'/');
            CBLOCK_DBG(v,1," _name["<<cbsz<<"] --> out="<<out);
        }
        CBLOCK_DBG(v,1,std::endl);
        ++ncomp;
    }
    CBLOCK_DBG(v,1," fullpath DONE, out="<<out<<" ncomp = "<<ncomp<<std::endl);
    if(ncomp>0) out.resize(out.size()-1U);
    CBLOCK_DBG(v,1," fullpath DONE, out="<<out<<std::endl);
    return out;
}
Cblock& Cblock::unlink() {
    int const __attribute__((unused)) v=0;
    if(this == &(_root->root))
        THROW("unlink of "<<fullpath()<<" failed, is it root?");
    if(_parent != this && _parent != nullptr){
        //CBLOCK_DBG(v,1," unlink cblock "<<(void*)this<<" _parent "<<(void*)_parent<<std::endl);
        CBLOCK_DBG(v,1," unlink cblock "<<fullpath()<<std::endl);
        for(auto s=_parent->_sub.begin(); s!=_parent->_sub.end(); ++s){
            CBLOCK_DBG(v,2," unlink psub "<<(*s)->_name<<"? ");
            if(*s == this){
                CBLOCK_DBG(v,2," YES!");
                _parent->_sub.erase(s); // all _sub iters (including s) INVALID
                _parent = nullptr;
                CBLOCK_DBG(v,2," _name unlinked"<<std::endl);
                break;
            }
        }
    }
    return *this;
}
/** find/create subblock.
 * If p is a component (not a path), then
 *   \return subblock with name \c p (create subblock if nec, no throw)
 * Otherwise throw if \c p.empty() or use \c at(p) fails to find a path.
 * */
Cblock& Cblock::operator[](std::string p){
    //if(p.empty()) THROW("Cblock[""] oops - empty string!");
    assert(!p.empty());
    // Be careful to not create sub-block with names containing wildcard strings
    if(p.find("/") != std::string::npos){       // PATH! revert to full-path search
        return this->at(p);                     //       throw if not found
    }
    //                                          Possible single-component path!
    if( p.substr(0,1) == "."){ // . and .. might actual be OK paths
        if( p == "." || p == "..")
            return this->at(p); //usually such blocks already exist, so we can return them
        else
            THROW("Avoid sub-block names like "<<p<<" beginning with '.'");
    }
    if( p.substr(0,1) == "*" ) // '*' should never begin a single component name
        THROW("'*' wildcard needs a '/'?  Avoid sub-blocks names like "<<p<<" beginning with '*'");
    // single-component path, possible valid name,
    for(auto s: _sub) if(s && s->_name==p) return *s;   // found ?
    //                                                  CREATE if not found in _sub[]
    CBLOCK_DBG(_root->v,2,"// new sub-block "<<_name<<"/"<<p<<" "<<_name<<".sub.size()="<<_sub.size()<<"\n");
    //_sub.push_back(new Cblock(this,p));
    //return *_sub.back();
    //  new: special "last" _sub will stay last.
    return this->append(*new Cblock(this,p));
}

Cblock * Cblock::find_immediate_sub(std::string p) const {
    assert( p.find("/") == std::string::npos );
    if(p.empty()) return nullptr;
    for(Cblock const* s: _sub) if(s && s->_name==p) return const_cast<Cblock*>(s);
    return nullptr;
}
Cblock * Cblock::find_recurse_sub(std::string p) const {
    assert( p.find("/") == std::string::npos );
    if(p.empty()) return nullptr;
    for(Cblock const* s: _sub){                          // s is Cblock const*
        if(s && s->_name==p) return const_cast<Cblock*>(s);
        Cblock *submatch = s->find_recurse_sub(p);
        if(submatch)                            // find first match?
            return const_cast<Cblock*>(submatch);
    }
    return nullptr;
}
/** search \em siblings, i.e. parent Cblock and its subblocks that are not \c this */
Cblock * Cblock::find_recurse_parent(std::string p) const {
    assert( p.find("/") == std::string::npos );
    //if(isRoot()) return *this;
    if(p.empty()) return nullptr;
    if(_parent==nullptr) return nullptr;
    if(_parent->_name == p) return _parent;
    for(Cblock const* s: _parent->_sub){
        if(s == this) continue;        // skip our subtree (maybe we already looked there)
        if(s && s->_name==p) return const_cast<Cblock*>(s);
        if(s->find_recurse_sub(p) != s) return const_cast<Cblock*>(s);
    }
    return nullptr;
}

/// \group Cblock helpers
//@{ helpers
/** provide an \c unlink'ed extern "C" block.
 * - You \b should \c .after(abspath) this to the desired location.
 *   - If you don't, it ends up at \c after("/"), perhaps \em not where you want it.
 * - User is expected to \c append or \c operator&lt;&lt; to \em \/\*\*\/name/body
 *   to get expected behaviour.
 * \return Cblk [name] with \c _sub blocks name/beg, name/body, name_end.
 */
Cblock& mk_extern_c(Cunit& cunit, std::string name){
#if 0
    Cblock& block = *(new Cblock(&cunit,name));
    block["beg"]<<"\n"
        "#ifdef __cplusplus\n"
        "extern \"C\" {\n"
        "#endif //C++\n";
    block["body"]; // empty
    block["end"]<<"\n"
        "#ifdef __cplusplus\n"
        "}//extern \"C\"\n"
        "#endif //C++\n";
    // Signal that we are not accessible within the DAG of cunit yet.
    // We need an 'after' to postion us within an existing 'root'.
    // We want to signal attempts to use unrooted Cblocks in questionable manner.
    //return block.unrooted();
    //
    // OR, explicitly root it at top-level
    cunit.root.append(block);
    return block;
#else // OK, let's just root it right away
    // want to append a new root block (even if name is dup)
    // This is not so bad, because client can take ref to "this one",
    // or can immediately '.after' it to another tree position.
    Cblock& block = cunit.root.append(*(new Cblock(&cunit,name)));
    block["beg"]<<"\n"
        "#ifdef __cplusplus\n"
        "extern \"C\" {\n"
        "#endif //C++\n";
    block["body"]; // empty
    block["end"]<<"\n"
        "#ifdef __cplusplus\n"
        "}//extern \"C\"\n"
        "#endif //C++\n";
    return block["body"];
#endif
}
/** [beg]:"\#if cond" + [body] + [end]:"\#endif // cond".
 * This has a "body" sub-block, like a scope, but no extra indenting.
 * No support for \em removing the indent so '#' lines end up in col 1.
 * (Could special-case this within "write" of the _code lines, I guess)
 */
Cblock& mk_cpp_if(Cunit& cunit, std::string name, std::string cond){
    Cblock& block = *(new Cblock(&cunit,name));
    block["beg"]<<"\n#if "<<cond;
    block["body"]; // empty
    block["end"]<<"#endif // "<<cond;
    return block;
}
/** [beg]~"\#if cond" + [body] + [else]~"\#else" + [end]~"\#endif". */
Cblock& mk_cpp_ifelse(Cunit& cunit, std::string name, std::string cond){
    Cblock& block = *(new Cblock(&cunit,name));
    block["beg"]<<"\n#if "<<cond;
    block["body"]; // empty
    block["else"]<<"\n#else // !( "<<cond<<"\n";
    block["end"]<<"#endif // "<<cond;
    return block;
}
/** create a name/{beg,body,end} triple, with subblock named "body" properly indented.
 * - \e body is always created empty.
 * - \e beg indents and \e end unindents
 * \return pointer to \e name/body node.
 * to insert a pre-"end" code, do \c return_value["../cleanup"]
 *
 * - For 'C' \c beg could, for example, be an "if(...){" clause.
 * - For 'asm', \c beg and \c end could be [verbatim] comment strings.
 * - default \c beg and \c end selected according to _root->flavor
 * - after mk_scope, usually want to position the code \e before or \e after
 *   some existing Cblock.
 * - in 'C' code , \c beg might be "if(cond)" or "else", etc.
 */
Cblock& mk_scope(Cunit& cunit, std::string name, std::string beg /*=""*/, std::string end /*=""*/){
    Cblock& block = *(new Cblock(&cunit,name));
    if(cunit.flavor!="asm"){
        if(cunit.flavor!="C"){
            std::cout<<" Warning: unknown Cblock flavor \""<<cunit.flavor
                <<"\". Assuming \"C\""<<std::endl;
        }
        block["beg"]<<beg<<"{ // "<<name<<PostIndent(+cunit.shiftwidth);
        block["first"];
        block["body"]; // empty
        if(!end.empty()) block["end"]<<end<<" ";
        block["end"]<<"} //"<<name<<PreIndent(-cunit.shiftwidth);
    }else{ // "asm"}
        block["beg"]<<"// BLOCK "<<name<<PostIndent(+cunit.shiftwidth);
        block["first"];
        if(!beg.empty()) block["beg"]<<beg<<"\n";
        block["body"];    // empty
        //block["cleanup"]; // empty
        if(!end.empty()) block["end"]<<end<<"\n";
        block["end"]<<"// END "<<name<<PreIndent(-cunit.shiftwidth);
    }
    return block;
}
//@} helpers

/** relative find of \em first Cblock matching 'p'.
 * - Suppose STAR = "*", DOUBLESTAR = "**"
 * 0. \c p with .. to mean "parent-of"
 * 1. \c p is a fullpath of form "/rootname/sub1/sub2/.../subN"
 * 2. \c p has single-path  wildcard "/rootname/STAR/foo"
 * 3. \c p with one-or-more wildcard "/DOUBLESTAR/foo"
 * 4. \c p relative path, immediate _sub[] match "./foo"
 * 5. \c p relative sub-path "./[DOUBLE]STAR/foo"
 * 6. \c p relative search sub-path:
 *    a. downwards (sub-path)
 *    b. up 1, then all sub-paths (repeat until full search is done
 * find NEVER creates a block.
 */
Cblock* Cblock::find(std::string p) const {
    assert(_root != nullptr);
    int const __attribute__((unused)) v = _root->v;
    CBLOCK_DBG(v,3,std::string(8,'=')<<" Cblock "<<fullpath()<<" find(\""<<p<<"\")");
    if(p.empty()){
        CBLOCK_DBG(v,3," empty => not found\n");
        return nullptr;
    }
    auto const firstslash = p.find("/");
    if(firstslash == std::string::npos){
        CBLOCK_DBG(v,3," no firstslash => find_immediate_sub\n");
        if(p==_name || p==".") return const_cast<Cblock*>(this);
        if(p==".."){
            if(_parent) return _parent;
            else return nullptr;
        }
        return find_immediate_sub(p);
    }
    std::string remain;
    auto const nextnonslash = p.find_first_not_of("/",firstslash+1);
    if( nextnonslash != std::string::npos ){
        remain = p.substr(nextnonslash);
    }
    if(firstslash == 0){ // shunt the search immediately to root.
        CBLOCK_DBG(v,3," starts-with-slash");
        // all "/<remain>" cases
        Cblock const& root = _root->root;
        if( remain.empty() ){
            CBLOCK_DBG(v,3," remain.empty(), return root");
            return &_root->root;
        }
        if( root._name == p ){
            CBLOCK_DBG(v,3," matches root name\n");
            return &_root->root;
        }
        CBLOCK_DBG(v,3," root.find(\""<<remain<<"\")\n");
        return root.find(remain);
    }
    auto comp1 = p.substr(0,firstslash);
    if(remain.empty()){ // terminal [/]\+ not significant
        return this->find(comp1);
    }
    CBLOCK_DBG(v,3,"find@<"<<comp1<<">/<"<<remain<<">\n");
    if( comp1 == "." ){                               // "./remain"
        CBLOCK_DBG(v,3," ./<remain>\n");
        return this->find(remain);
    }else if( comp1 == ".." ){                        // "../remain"
        if(_parent /*&& _parent != this*/){ // "/.." is same as root (like FS)
            CBLOCK_DBG(v,3," ../<remain>\n");
            return _parent->find(remain);
        }else{
            CBLOCK_DBG(v,3," .. no parent\n");
            return nullptr;
        }
    }else if(comp1 == "*" || comp1 == "**"){          // "*/remain"
        if( comp1 == "**" ){ // ** is allowed to match with this (no subdirs)
            Cblock * thismatch = this->find(remain);
            if( thismatch ){
                CBLOCK_DBG(v,3," ** no-subdir match\n");
                return thismatch;
            }
        }
        for(Cblock const* s: _sub){
            Cblock* subfind = s->find(remain);
            if(subfind){                // found 'remain' in s
                CBLOCK_DBG(v,3," * subfind \n");
                return subfind;
            }
            if(comp1 == "**"){
                CBLOCK_DBG(v,3,"\n** subfind ");
                Cblock* deeper = s->find(p); // repeat "**/remain" search, depthwise
                if(deeper){
                    CBLOCK_DBG(v,3," ** deeper match\n");
                    return deeper;
                }
            }
        }
        return nullptr; // */remain not found
    }else if(comp1 == "..*"){
        // This is recursive _parent search, never looking underneath this
        if( !_parent || _parent==this || isRoot() ){
            CBLOCK_DBG(v,1," no parent for Cblock "<<_name<<"\n");
            //THROW("Not possible to continue upward parent search");
            return nullptr;
        }
        if( _parent->_name == remain ){
            CBLOCK_DBG(v,1," FOUND exact match of parent "<<_parent->_name<<" with remain\n");
            return _parent;
        }
        Cblock * parentfind = _parent->find(remain);
        if(parentfind){
            CBLOCK_DBG(v,1," FOUND match of parent "<<_parent->_name<<" with remain at "<<parentfind->fullpath()<<"\n");
            return parentfind;
        }
        CBLOCK_DBG(v,1," search parent subtree\n");
        for(Cblock const* s: _parent->_sub){
            if( s == this ) continue; // search parent sub-tree EXCEPT for this
            CBLOCK_DBG(v,1,"\nssss sibling-find **/"<<remain<<" under sibling "<<s->fullpath()<<"\n");
            Cblock* sibfind = s->find("**/"+remain);   // force sub-tree search
            if(sibfind){
                CBLOCK_DBG(v,1,"\nssss found "<<remain<<" at "<<sibfind->fullpath()<<"\n");
                return sibfind;
            }
            CBLOCK_DBG(v,1,"\nssss did not find "<<remain<<"\n");
        }
        // repeat the SAME p="**/remain" search skipping the parent's sub-tree.
        return _parent->find(p);
    }else{                                            // "comp1/remain"
        for(Cblock const* s: _sub){
            if(s->_name == comp1){
                CBLOCK_DBG(v,3," sub");
                return s->find(remain);
            }
        }
        CBLOCK_DBG(v,3," no match for comp1=<"<<comp1<<">\n");
        return nullptr;
#if 0
        Cblock const* sub = find_immediate_sub(comp1);
        if(sub == this) return this; // comp1 not matched
        std::cout<<" sub["<<sub._name<<"].find(\""<<remain<<"\")"<<std::endl;
        if(remain.empty()) return sub; // comp1 was the last path component
        auto subfind = sub.find(remain);
        if( &subfind == &sub ) return this; // remain did not match
        return subfind;                     // return subfind Cblock
#endif
    }
}
/** where '#define' for this->define would appear. */
Cblock& Cblock::goto_defines() const {
    Cblock *a;
    {
        Cblock const* body = (getName()=="body"? this: find("..*/body)"));
        if(!body) body=this;                  // prospective "scope"
        a = body->find("..");                 // what encloses the "scope"?
        if(!a) a = const_cast<Cblock*>(this); // else "right here"
    }
    return *a;
}

/** common code */
static void emit_define(Cblock& a, Cblock& z, std::string name, std::string subst){
    a>>"#define "<<name<<" "<<subst; // multiline backslash support?
    z>>"#undef "<<name.substr(0,name.find('('));
}
/** attach to nearest-enclosing scope in a reasonable way. */
Cblock& Cblock::define(std::string name, std::string subst){
    // sanity checks on name?
    Cblock& a = goto_defines();
    Cblock& z = a["last"]["undefs"]; // try extra hard for undef to be 'last'
    emit_define(a,z,name,subst);
    return *this;
}

/** attach to nearest-enclosing scope in a reasonable way. */
Cblock& Cblock::define_here(std::string name, std::string subst){
    // sanity checks on name?
    Cblock& a = *this;
    Cblock& z = a["last"]["undefs"];
    emit_define(a,z,name,subst);
    return *this;
}

/** debug printout: see the DAG, not the actual code snippets */
std::ostream& Cblock::dump(std::ostream& os, int const ind/*=0*/)
{
    if(ind > 2000){
        THROW("Cblock dump depth really huge.  Maybe it is not a DAG.");
    }
    //int const v = _root->v+2;
    std::string in("\n&&& "+std::string(ind,' '));
    os<<in<<fullpath()<<(_premanip? " premanip": "");
    if(_code.size()) os<<" CODE["<<_code.size()<<"]";
    if(_sub.size()) os<<" SUB["<<_sub.size()<<"]";
    if(!_type.empty()) os<<" "<<_type;
    os<<(_postmanip? "postmanip": "");
    for(auto s: _sub) s->dump(os,ind+1); // it's easy to generate **very** deep trees
    return os;
}
std::ostream& Cblock::write(std::ostream& os, bool chkWrite)
{
    if(chkWrite && !canWrite()){
        if(_root->v >= 1){
            std::cout<<" SKIP-WRITE! "; std::cout.flush();
        }
        return os;
    }
    std::string& in = _root->indent;
    // very-verbose mode blocks commented with fullpath
    if(_root->v >= 2 || _code.size()==0){
        if(_root->v >= 2 && _code.size()) os<<in<<"//\n";
        if(_root->v >= 1){
            os<<in<<"// Cblock : "<<this->fullpath()<<" : "<<_type;
            if(_code.empty()) os<<" (empty)";
            os<<"\n";
        }
    }
    if(_premanip) os << *_premanip;
    if(!_code.empty()){
        //std::cout<<" prefix_lines with code=<"<<_code<<">\n";
        prefix_lines(os,_code,in) << "\n";
    }
    if(_root->v >= 3 ) os<<"// _sub.size() = "<<_sub.size()<<"\n";
    for(auto s: _sub){
        if(_root->v >= 3 ) os<<in<<"// ........ sub "<<_parent->_name<<"/"<<_name<<"/"<<s->_name<<std::endl;
        s->write(os,chkWrite);
    }
    if(_postmanip) os << *_postmanip;
    // if( _next ) _next->write(os);
    if(chkWrite) ++_nwrites;
    return os;
}
std::string Cblock::str(){
    std::ostringstream oss;
    _root->indent.clear();
    this->write( oss, false/*chkWrite*/ );
    return oss.str();
}
Cblock& Cblock::clear(){
    _code="";
    for(auto s: _sub) delete(s);
    _sub.clear();
    _type="";
    if(_premanip){ delete(_premanip); _premanip=nullptr;}
    if(_postmanip){ delete(_postmanip); _postmanip=nullptr;}
    return *this;
}

}//cprog::


#ifdef MAIN_CBLOCK
using namespace cprog;
using namespace std;

#define MUST_THROW(CODE) do{ \
    int threw = 0; \
    try{ \
        CODE; \
    }catch(...){ \
        threw = 1; \
    } \
    if( threw == 0 ){ \
        std::cout<<"Error: following code should have thrown:\n" \
        << #CODE << std::endl; \
        THROW("Stopping now"); \
    } \
}while(0)

/** This uses simple paths only, and demonstrates how output
 * order can be controlled.
 * - Simple Pre/Post-Indent "manipulator" demo.
 * - Notice that begin/middle/end constructs are awkward.
 */
void test_cblock_basic(){
    Cunit pr("program");
    pr.v = 3;
    pr["comments"]>>"// Cunit output from "<<__FILE__;
    // Very important to use 'auto&' instead of plain 'auto'
    pr["includes"];
    auto& macros = pr["macros"];
    auto& extern_c = pr["extern_C"];
    extern_c["beg"]
        <<"\n#ifdef __cplusplus"    // can appen w/ embedded newlines
        "\nextern \"C\" {"
        >>"#endif //C++";           // Note: >> auto-supplies initial newline
    pr["extern_C"]["end"]
        >>"ifdef __cplusplus"
        >>"extern \"C\""
        >>"endif //C++";
    //auto& functions = (pr["functions"].after(extern_c["beg"]));
    auto& functions = extern_c["beg"]["functions"]; // simpler equiv
    // '\:' --> '\\:'
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    pr["includes"]<<"#include <stdio.h>";
    macros<<"#define MSG \"hello\"";    // easy to add to previously defined code blocks
    macros>>CSTR(#define MSG2 "hello"); // Note: CSTR to auto-escape embeded '"'
    auto& foo = functions["foo"];
    // Klunky beg/middle/end w/ manipulator to adjust write context
    foo["beg"]<<"int foo() {"<<PostIndent(+2);
    foo["mid"]<<"return 7;";
    foo["end"]<<"}"<<PreIndent(-2);
    functions["bar"]<<"int bar(){ return 43; }\n";

    // output order can be adjusted with after: (subtree move)
    functions["foo"].after(functions["bar"]);

    //main.after("extern_C/open");
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_cblock_path(){
    Cunit pr("program");
    pr.v = 3;
    Cblock& root = pr.root;
    assert( root.find("") == nullptr );
    assert( root.find("asdfalsdkjfalsdkfj") == nullptr );
    assert( root.find("/") == &root );
    assert( root.find("/..") == &root );
    assert( root.find("/../") == &root );
    assert( root.find(".") == &root );
    assert( root.find("..") == &root );
    assert( root.find("./") == &root );
    assert( root.find("../") == &root );
    assert( root.find("./asdf") == nullptr );
    assert( root.find("../asdf") == nullptr );
    assert( root.find("*/asdf") == nullptr );
    assert( root.find("*/open") == nullptr );
    // creates "/includes", no var because never refered to later
    pr["includes"]<<"#include <stdio.h>";
    assert( root.find("includes") != nullptr );
    assert( root.find("includes")->getName() == "includes" );
    assert( root.find("includes") == &pr["includes"] );
    assert( root.find("/includes") != nullptr );
    assert( root.find("./includes") != nullptr );
    assert( root.find("../includes") != nullptr ); // because .. of root is root again
    assert( root.find("open") == nullptr );
    // Very important to use 'auto&' instead of plain 'auto'
    auto& macros = pr["macros"];
    auto& extern_c = pr["extern_C"];
    assert( extern_c.find("../open") == nullptr );
    assert( extern_c.find("./includes") == nullptr );
    assert( extern_c.find("../includes") != nullptr );
    assert( extern_c.find("/../includes") != nullptr );
    assert( extern_c.find("extern_C") != nullptr );
    extern_c["open"]<<
        "\n#ifdef __cplusplus\n"
        "extern \"C\" {\n"
        "#endif //C++\n";
    assert( extern_c.find("../open") == nullptr );
    assert( extern_c.find("./includes") == nullptr );
    assert( extern_c.find("../includes") != nullptr );
    assert( root.find("open") == nullptr );
    assert( extern_c.find("open") != nullptr );
    assert( extern_c.find("./open") != nullptr );
    assert( extern_c.find("./open//") != nullptr );
    assert( root.find("*/open") != nullptr );
    assert( root.find("**/open") != nullptr );
    assert( root.find("extern_C/open") != nullptr );
    pr["extern_C"]["close"] // or as multiple strings
        >>"#ifdef __cplusplus\n"
        <<"}//extern \"C\"\n"
        <<"#endif //C++\n\n";
    //auto& functions = (pr["functions"].after(extern_c["open"]));
    auto& functions = extern_c["open"]["functions"]; // simpler equiv
    // '\:' --> '\\:'
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    pr["includes"]<<"#include <stdio.h>";
    macros<<"#define MSG \"hello\"";
    auto& foo = functions["foo"];
    // Klunky beg/middle/end w/ manipulator to adjust write context
    foo["beg"]<<"int foo() {"<<PostIndent(+2);
    foo["mid"]<<"return 7;";
    foo["end"]<<"}"<<PreIndent(-2);
    functions["bar"]<<"int bar(){ return 43; }\n";

    // output order can be adjusted with after:
    functions["foo"].after(functions["bar"]);
    assert( root.find("*/foo") == nullptr );
    assert( root.find("**/foo") != nullptr );
    assert( root.find("/extern_C/open/functions/bar/foo/mid/") != nullptr );
    assert( root.find("extern_C/open/functions/bar/foo/mid/") != nullptr ); 
    assert( root.find("program/extern_C/open/functions/bar/foo/mid/") == nullptr ); 
    assert( functions.find("..*/open") != nullptr );
    cout<<"\n\n"<<endl; cout.flush();
    assert( foo.find("..*/bar/") != nullptr ); // find in recursive "parent/sibling tree"
    assert( foo.find("..*/bar") != nullptr ); // find in recursive "parent/sibling tree"
    assert( foo.find("..*/foo/") != nullptr ); // find in recursive "parent/sibling tree"
    assert( foo.find("..*/foo") != nullptr ); // find in recursive "parent/sibling tree"
    assert( foo.find("..*/foo/") == &foo ); // find in recursive "parent/sibling tree"
    assert( foo.find("..*/foo") == &foo ); // find in recursive "parent/sibling tree"

    // Cblock::operator[p] was extended.
    // ORIGINAL behaviour for non-path p [no /] is to create the component
    // if it is not an immediate subblock.
    // NEW behaviour allows p to be a path,
    // and throws if p.empty() or p is a nonexistent path.
    try{
        std::cout<<"\n\n Cblock::at(p) tests"<<std::endl;
        assert( root.at(".").getName() == "program" );
        assert( root.at("..").getName() == "program" );
        assert( root.at("/macros").getName() == "macros" );
        assert( root.at("./macros").getName() == "macros" );
        assert( root.at("macros").getName() == "macros" );
        assert( root.at("*/open").getName() == "open" );
        assert( root.at("**/foo").getName() == "foo" );
        assert( root.at("*/../macros").getName() == "macros" );
    }catch(...){
        cout<<" Caught something\n";
        throw;
    }
    std::cout<<"\n\n Cblock::at(p) THROW tests"<<std::endl;
    MUST_THROW(root["*"]); // Paranoia about bugs wrt wildcards
    MUST_THROW(root[".illegal"]);
    MUST_THROW(root[".illegal"]);
    MUST_THROW(root.at("*"));
    MUST_THROW(root.at("*illegal"));
    MUST_THROW(root.at(".illegal"));

    MUST_THROW(root.at("asdfqewrasdf"));
    MUST_THROW(root.at("macrossss"));
    MUST_THROW(root.at("*/foo"));
    MUST_THROW(root.at("**/asdlkfj"));
    MUST_THROW(root.at("/extern_c/open")); // should be capital C
    MUST_THROW(root.at("never_seen_path"));

    try{
        std::cout<<"\n\n Cblock::operator[](p) tests"<<std::endl;
        assert( root["."].getName() == "program" );
        assert( root[".."].getName() == "program" );
        assert( root["/macros"].getName() == "macros" );
        assert( root["./macros"].getName() == "macros" );
        assert( root["macros"].getName() == "macros" );
        assert( root["*/../macros"].getName() == "macros" );
        assert( root["*/open"].getName() == "open" );
        assert( root["*/open"].fullpath() == "/extern_C/open" );
        assert( root["**/open"].getName() == "open" );
        // 1-component ==> create if never seen ...
        assert( root["never_seen_path"].getName() == "never_seen_path" );
    }catch(...){
        cout<<" Caught something\n";
        throw;
    }
    std::cout<<"\n\n Cblock::operator[](p) THROW tests"<<std::endl;
    MUST_THROW(root["./newsub"]); // cf. root["newsub"] which never fails
    MUST_THROW(root["*/foo"]);
    MUST_THROW(root["**/asdlkfj"]);
    MUST_THROW(root["/extern_c/open"]); // should be capital C

    //main.after("extern_C/open");
    pr.v = 2;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_cblock_short(){
    Cunit pr("program");
    pr.v = 10;
    pr["comments"]>>"// Cunit output from "<<__FILE__;
    // Very important to use 'auto&' instead of plain 'auto'
    pr["includes"]>>"#include <stdio.h>";
    pr["macros"]>>"#define MSG \"hello\"";
    //mk_extern_c(pr,"extern_C").after(pr["macros"]);
    //  new function: after can accept an absolute path
    // OLD: mk_extern_c(pr,"extern_C").after("/macros");
    mk_extern_c(pr,"extern_C");  // new subnode "now" (after macros), returns /extern_C/body
    // FULL extern_C tree is at /extern_C/body/.."
    // now let's continue making thing at root level (NOT within extern_C)

    // creates "functions", appends foo/decl foo/body foo/end
    auto& foo_body = mk_func(pr,"foo","int foo()").after(pr["functions"])["body"];
    // for complex items, foo_body will itself get subdivided!

    // append(string) to _code is really only useful for simple stuff.
    // complex cases should name all sections/blocks ...
    foo_body["entry"]<<"int ret=-1;";   // foo/body/entry (anchored)

    // OK, this seems a reasonable idiom .. if00 --> path "/**/foo/body/if00/body"
    auto& if00 = mk_scope(pr,"if00","if(!defined(__cplusplus))").after(foo_body)["body"]; {
        if00<<"ret = 1;";
    }
    // with macros, a bit more readable, else00 --> Cblock path "/**/foo/body/else00/body"
    CBLOCK_SCOPE(else00,"else",pr,foo_body) {
        else00<<"ret = 2;";
    }
    CBLOCK_SCOPE(for00,"for(int i=0;i<10;++i)",pr,foo_body) {
        for00<<"ret = (ret^magic); //just to demo"
            >>"ret += i*magic2;\t// how to 'randomize' ret a bit";
        // oh, I wanted a magic const to be hoisted up into "entry" code...
        foo_body["entry"]>>"int const magic=0x12345678;";
        // or do an 'upward search' for a previously created code block (or stub)
        //for00.up["entry"]>>"int const magic2=0x23456789;";
        for00["..*/entry"]>>"int const magic2=0x23456789;";
    }
    //foo_body["exit"]<<"printf(\"%s\\nGoodbye\",MSG);\nreturn ret;";
    foo_body["exit"]<<CSTR(printf("%s\nGoodbye",MSG);\nreturn ret;);

    // short functions can be ... very short
    //mk_func(pr,"bar","int bar()").after(pr["functions"])["body"]<<"return 7";
#if 1-1
    // can we do Pre(Indent(-2)) for _pre.push_front(...) ?
    // or Pre-Manip, Pre+Manip for _pre.push_front/back <----
#endif
    // output order can be adjusted with after:
    cout<<pr.tree()<<endl;
    pr["functions"].after("/**/extern_C/body"); // The "/**" is just for show
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    //main.after("extern_C/open");
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}

void test_cblock_short2(){
    Cunit pr("program");
    pr.v = 0;
    // Very important to use 'auto&' instead of plain 'auto'
    pr["comments"]>>"// Cunit output from "<<__FILE__;
    pr["includes"]>>"#include <iostream>";
    pr["macros"]>>"define MSG \"hello\"";
    mk_extern_c(pr,"extern_C");         // OLD! NO GOOD! .after("/macros");
    // a somewhat more complicated function...
    auto& foo_body = mk_func(pr,"foo","int randomizer()").after(pr["functions"])["body"];
    foo_body["entry"]<<"int ret=-1;";   // foo/body/entry (anchored)
    int opt_level = 0; // my JIT decision making procedure

    CBLOCK_SCOPE(if00,"if(__FILE__[0]=='b')",pr,foo_body) {
        if00<<"ret = 1;";
    }
    CBLOCK_SCOPE(else00,"else",pr,foo_body) {
        else00<<"ret = 2;";
    }
    foo_body["preloop"]<<"// I have selected JIT randomization method "<<asDec(opt_level);
    CBLOCK_SCOPE(for00,"for(int i=0; i<10; ++i)",pr,foo_body) {
        CBLOCK_SCOPE(for01,"for(int j=i;i<10;++j)",pr,for00) {
            // Scenario: I have many JIT possibilities, but I decide to
            // use the following code ....
            if(opt_level==0) { // Oh, maybe I want my original JIT version ...
                for01<<"ret = (ret^magic); //just to demo"
                    // original version ...
                    >>"ret += (i*23+j)*magic2;\t// how to 'randomize' ret a bit";

                // I JIT realize this optimization uses some
                // undefined const values into foo/body/entry
                // ... NO PROBLEM ... Let's add to that code snippet
                foo_body["entry"]>>"int const magic=0x12345678;";   // exact destn known
                for01["..*/entry"]>>"int const magic2=rand();";     // alt "up-search-near" method
                // oh, I JIT realize I need yet another C header
                pr["includes"]>>"#include <stdlib.h>";
            }else if(opt_level==1){
                for01<<"ret = ret + i + j"; // this JIT is faster (but maybe not so random)
            }else{
                // OTHER JIT impls of foo are not shown, but may need entirely different
                //                 sets of code and patches to upward blocks of pr
            }
        }//j-loop
    }//i-loop
    foo_body["exit"]<<CSTR(printf("%s\nGoodbye",MSG);\nreturn ret;);
    pr["functions"].after("/**/extern_C/body"); // allow generous search (it is not directly under root)
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_cblock_dump(){
    Cunit pr("program");
    pr.v = 0;
    // overall structure, also demo new ','-operator (auto-supplies an initial newline)
    pr["comments"]>>"// Cunit output from "<<__func__;
    pr["includes"]>>"#include <assert.h>";
    pr["macros"];
    auto& cfuncs = mk_extern_c(pr,"extern_C")["body"]; // many mk_FOO have a "body" section
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // now fill in a function
    pr.v = 10;
    pr["/"].dump(cout);
    cout<<"\nHmmmm.  Let's look at dump to see how one instruction worked\n\n"<<endl;
    auto& macs = mk_func(pr,"macs","int macs(int i)")
        .after(cfuncs)["body"]
        <<"assert(i>=0);";
    pr["/"].dump(cout);
    macs>>"return 75/i;";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}

/** based on a very short (slow) direct_default3.c */
string cjitConvolutionForward00( int const verbosity=0 /*struct param const* const p*/ )
{
    Cunit pr("program");
    pr["includes"]<<Endl<<CSTR(#include "vednn.h")
        <<Endl<<CSTR(#include "veintrin.h")
        <<"\n#include <stdio.h>"
        <<"\n#include <stdlib.h>"
        <<"\n#include <assert.h>"
        ;
    pr["macros"]<<"\n#define VLEN (256)"
        ;
    auto & fns = mk_extern_c(pr,"extern_C");
    std::string fn_declare;
    {
        std::string funcname("cjitConvFwd00");
        std::ostringstream oss;
        oss<<"void "<<funcname<<"("
            <<"\n        const vednnTensorParam_t * restrict      pParamIn,"
            <<"\n        const void * restrict                    pDataIn,"
            <<"\n        const vednnFilterParam_t * restrict      pParamKernel,"
            <<"\n        const void * restrict                    pDataKernel,"
            <<"\n        const vednnConvolutionParam_t * restrict pParamConv,"
            <<"\n        const vednnTensorParam_t * restrict      pParamOut,"
            <<"\n        void * restrict                          pDataOut"
            <<"\n        )";
        fn_declare = oss.str();
    }
    auto& fn = mk_func(pr,"fn",fn_declare).after(fns)["body"];

    // get the vars here first.
    const int64_t batch          = 52;
    const int64_t group          = 2;
    const int64_t inChannel      = 100;
    const int64_t inHeight       = 27;
    const int64_t inWidth        = 27;
    const int64_t outChannel     = 100;
    const int64_t outHeight      = 27;
    const int64_t outWidth       = 27;
    const int64_t kernHeight     = 3;
    const int64_t kernWidth      = 3;
    const int64_t strideHeight   = 1;
    const int64_t strideWidth    = 1;
    const int64_t padHeight      = 1;
    const int64_t padWidth       = 1;
    const int64_t dilationHeight = 1; // mkl-dnn value plus one
    const int64_t dilationWidth  = 1;
    assert( outWidth > 0 );

    const int64_t inChannelGroup  = inChannel  / group;   // equal to pDataKernel->inChannel
    const int64_t outChannelGroup = outChannel / group;   // equal to pDataKernel->outChannel

    const int64_t inHW = inHeight * inWidth;
    const int64_t kernHW = kernHeight * kernWidth;
    const int64_t outHW = outHeight * outWidth;

    // then emit them as constant cjit values (or #define them)
//#define CONST1(var) >>("int64_t const " #var " = "+asDec(var))
// #define is better, because is is definitely usable with 'C' compiler
#define CONST1(var) >>("#define " #var " "+asDec(var))
    //auto& fn_const =
    fn["const"]
        CONST1(batch            )
        CONST1(group            )
        CONST1(inChannel        )
        CONST1(inHeight         )
        CONST1(inWidth          )
        CONST1(outChannel       )
        CONST1(outHeight        )
        CONST1(outWidth         )
        CONST1(kernHeight       )
        CONST1(kernWidth        )
        CONST1(strideHeight     )
        CONST1(strideWidth      )
        CONST1(padHeight        )
        CONST1(padWidth         )
        CONST1(dilationHeight   )
        CONST1(dilationWidth    )

        CONST1(inChannelGroup   )
        CONST1(outChannelGroup  )

        CONST1(inHW             )
        CONST1(kernHW           )
        CONST1(outHW            )
        ;
#if 0
    const float * restrict pIn     = pDataIn;
    const float * restrict pKernel = pDataKernel;
    //float * restrict const pOut    = pDataOut;
    float * restrict pOut    = pDataOut;
#endif
    auto& fn_ptrs = fn["ptrs"];
    fn_ptrs>>"float const * restrict pIn  = pDataIn;"
        >>"float const * restrict pKernel = pDataKernel;"
        >>"float * restrict pOut = pDataOut;"
        ;

    //auto& fn_vec_init =
    fn["vec_init"]
        >>"_ve_lvl(VLEN);"
        >>"const __vr vzeros = _ve_vbrdu_vs_f32(0.0f); // lower 32-bits are zero bits, so same as _ve_pvbrd_vs_i64(0UL)"
        >>"const __vr vrseq = _ve_vseq_v();"
        >>"const int64_t sw_x_VLEN = strideWidth * VLEN;"
        >>"int64_t const vl_x_init = outWidth /*- x0=0*/ < VLEN ? outWidth /*- x0=0*/ : VLEN ;"
        >>"int64_t vl = vl_x_init;"
        >>"_ve_lvl(vl);"
        >>"__vr const vrj_init = _ve_vaddsl_vsv(-padWidth,  _ve_vmulsl_vsv(strideWidth, vrseq));"
        ;

    CBLOCK_SCOPE(loop_n,"for(int64_t n=0; n<batch; ++n)",pr,fn);
    CBLOCK_SCOPE(loop_g,"for(int64_t g=0; g<group; ++g)",pr,loop_n); // OK sub-tree
    loop_g
        >>"const int64_t outGroupOffset  = g * outChannelGroup * outHW;"
        >>"const int64_t inGroupOffset   = g * inChannelGroup * inHW;"
        >>"const int64_t kernGroupOffset = g * outChannelGroup * inChannelGroup * kernHW;"
        >>"const float *pIn_0 = pIn + inGroupOffset + (n * inChannel + 0) * inHW;"
        ;
    CBLOCK_SCOPE(loop_k,"for(int64_t k=0 ; k<outChannelGroup; ++k)",pr,loop_g);
    loop_k
        >>"int64_t outIndex = outGroupOffset + (n * outChannel + k) * outHW;"
        >>"const float * restrict pKern_gk = pKernel + kernGroupOffset"
        >>"                                + (k * inChannelGroup + 0) * kernHW;"
        >>"//int64_t kIndex_0 = kernGroupOffset + (k * inChannelGroup + 0) * kernHW;"
        ;
    CBLOCK_SCOPE(loop_y,"for(int64_t y=0 ; y<outHeight; ++y)",pr,loop_k);
    loop_y
        >>"const int64_t i = y * strideHeight - padHeight;"
        >>""
        >>"int64_t kh_end=0;"
        >>"const int64_t kh_tmp = dilationHeight-i-1;"
        >>"const int64_t kh_beg= (i>=0? 0: kh_tmp / dilationHeight);"
        >>"if (i < inHeight){"
        >>"  kh_end = (inHeight + kh_tmp) / dilationHeight;"
        >>"  if (kh_end >= kernHeight) kh_end = kernHeight;"
        >>"}"
        >>""
        >>"int64_t vl = vl_x_init;"
        >>"_ve_lvl(vl);"
        >>"__vr vrj = vrj_init;"
          ;
    CBLOCK_SCOPE(loop_x0,"for(int64_t x0=0 ; x0<outWidth; x0+=VLEN)",pr,loop_y);
    loop_x0
            >>"const int64_t vl = outWidth - x0 < VLEN ? outWidth - x0: VLEN;"
            >>"_ve_lvl(vl);"
            >>"__vr vrsum = vzeros;"
            ;
    CBLOCK_SCOPE(loop_r,"for (int64_t r = kh_beg; r < kh_end; ++r)",pr,loop_x0);
    //loop_r>>"vrw = vrj";
    CBLOCK_SCOPE(loop_s,"for (int64_t s = 0; s < kernWidth; s++)",pr,loop_r);
    loop_s.def("LOOP_S_FOO","LOOP_S_BAR"); // demo the scoped #define function (NEW)
    loop_s[".."]>>"vrw = vrj"; // current pos loop_r/body/loop_s CODE, **before** loop_s/beg opens the loop
    loop_s["last"]             // into loop_s/body/last, just before loop_s/end exits the loop
        >>"vrw = _ve_vaddsl_vsv(dilationWidth,  vrw) ; // <--- vector induced"
        ;
    loop_s[".."]["last"]>>"//loop_s has just exited!";
    loop_s
        >>"__vm256 vm2 = _ve_vfmkl_mcv(VECC_GE, vrw);        // condition(0 <= w)"
        >>"__vm256 vm3 = _ve_vfmkl_mcv(VECC_IG, _ve_vcmpsl_vsv(inWidth,vrw));  // condition(w < inWidth)"
        >>"__vm256 vm23  = _ve_andm_mmm(vm2, vm3);"
        ;
    CBLOCK_SCOPE(loop_c,"for (int64_t c = 0; c < inChannelGroup; ++c)",pr,loop_s);
    loop_c
        >>"const float *pIn = pIn_0 + c*inHW + (i+r*dilationHeight)*inWidth"
        >>"                 + x0*strideWidth-padWidth + s*dilationWidth;"
        >>"const float *pKerValue = pKern_gk + c*kernHW + r*kernWidth +s;"
        >>"__vr vrin = _ve_vldu_vss(4*strideWidth,pIn) ;"
        >>"vrin = _ve_vmrg_vvvm(vzeros, vrin, vm23) ;"
        >>"vrsum = _ve_vfmads_vvsv(vrsum, *pKerValue, vrin) ;"
        ;
    //loop_s["induce vrw"]// BEFORE the '}' of loops_s (embedded blanks OK, but harder to read
    //    >>"vrw = _ve_vaddsl_vsv(dilationWidth,  vrw) ; // <--- vector induced"
    //    ;
    // loop_r path: .../loop_x0/body/loop_r/body
    //loop_r[".."] // too early (add to loop_x0/body; before loop_r even begins)
    //loop_r["../.."] // same as above
    //loop_r["end"] // too early, before "}//loop_r", creates path loop_x0/body/loop_r/body/end
    //loop_r["../end"]      // OK, adds to /**loop_x0/body/loop_r/end
    //loop_r[".."]["done"]  // OK, adds to append-tree /**/loop_x0/body/loop_r/done
    loop_x0["induce+store"]       // OK, adds to /**/loop_x0/body/induce+store
        >>"_ve_vstu_vss(vrsum, 4, pOut) ;"
        >>"vrj = _ve_vaddsl_vsv(sw_x_VLEN,vrj); // induce to avoid full recalc"
        >>"pOut += vl; // visible speedup cf. outIndex+=vl"
        ;
    fn["exit"]>>"return VEDNN_SUCCESS;" ;


    pr["end"]>>"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // debug: 'str()' should bypass the write-counting thing and always work
    auto const sz0 = pr.str().size();
    cout<<" pr.str().size() = "<<sz0;
    assert( sz0 > 0 );
    auto const sz1 = pr.str().size();
    cout<<" pr.str().size() = "<<sz1;
    assert( sz1 == sz0 );
    // For demo program, dump the full tree...
    cout<<string(80,'-')<< pr.tree() <<string(80,'-')<<endl;
    cout<<string(80,'-')<< pr.str() <<string(80,'-')<<endl;

    pr.v = verbosity;
    return pr.str();
}

#if 0 // original function, for comparison...
vednnConvolutionForward_direct_default3(
    const vednnTensorParam_t * restrict   pParamIn,
    const void * restrict       pDataIn,
    const vednnFilterParam_t * restrict   pParamKernel,
    const void * restrict       pDataKernel,
    const vednnConvolutionParam_t * restrict   pParamConv,
    const vednnTensorParam_t * restrict   pParamOut,
    void * restrict         pDataOut
)
{
  const int64_t batch      = pParamIn->batch;
  const int64_t inChannel  = pParamIn->channel;
  const int64_t inWidth    = pParamIn->width;
  const int64_t inHeight   = pParamIn->height;
  const int64_t outChannel = pParamOut->channel;
  const int64_t outWidth   = pParamOut->width;
  const int64_t outHeight  = pParamOut->height;
  const int64_t kernWidth  = pParamKernel->width;
  const int64_t kernHeight = pParamKernel->height;
  assert( outWidth > 0 );

  const int64_t group          = pParamConv->group;
  const int64_t strideWidth    = pParamConv->strideWidth;;
  const int64_t strideHeight   = pParamConv->strideHeight;
  const int64_t padWidth       = pParamConv->padWidth;
  const int64_t padHeight      = pParamConv->padHeight;
  const int64_t dilationWidth  = pParamConv->dilationWidth;
  const int64_t dilationHeight = pParamConv->dilationHeight;

  const int64_t inChannelGroup  = inChannel  / group;   // equal to pDataKernel->inChannel
  const int64_t outChannelGroup = outChannel / group;   // equal to pDataKernel->outChannel

  const float * restrict pIn     = pDataIn;
  const float * restrict pKernel = pDataKernel;
  //float * restrict const pOut    = pDataOut;
  float * restrict pOut    = pDataOut;

  const int64_t inHW = inHeight * inWidth;
  const int64_t kernHW = kernHeight * kernWidth;
  const int64_t outHW = outHeight * outWidth;


  _ve_lvl(VLEN) ; // <----- VERY VERY VERY IMPORTANT to remember this init !!! 1.
  const __vr vzeros = _ve_vbrdu_vs_f32(0.0f) ; // lower 32-bits are zero bits, so same as _ve_pvbrd_vs_i64(0UL)
  const __vr vrseq = _ve_vseq_v();
  const int64_t sw_x_VLEN = strideWidth * VLEN;
  int64_t const vl_x_init = outWidth /*- x0=0*/ < VLEN ? outWidth /*- x0=0*/ : VLEN ;
  int64_t vl = vl_x_init;
  _ve_lvl(vl) ;
  __vr const vrj_init = _ve_vaddsl_vsv(-padWidth,  _ve_vmulsl_vsv(strideWidth, vrseq));

  //int64_t const kByMax = 1;
  //int64_t const zero = 0;

  for (int64_t n = 0; n < batch; n++) {
    for (int64_t g = 0; g < group; g++) {
      const int64_t outGroupOffset  = g * outChannelGroup * outHW;
      const int64_t inGroupOffset   = g * inChannelGroup * inHW;
      const int64_t kernGroupOffset = g * outChannelGroup * inChannelGroup * kernHW;
      const float *pIn_0 = pIn + inGroupOffset + (n * inChannel + 0) * inHW;
      for(int64_t k=0 ; k<outChannelGroup; ++k) {

        int64_t outIndex = outGroupOffset + (n * outChannel + k) * outHW;
        const float * restrict pKern_gk = pKernel + kernGroupOffset + (k * inChannelGroup + 0) * kernHW;
        //int64_t kIndex_0 = kernGroupOffset + (k * inChannelGroup + 0) * kernHW;

        for (int64_t y=0; y<outHeight; y++) {
          const int64_t i = y * strideHeight - padHeight;

          int64_t kh_end=0;
          const int64_t kh_tmp = dilationHeight-i-1;
          const int64_t kh_beg= (i>=0? 0: kh_tmp / dilationHeight);
          if (i < inHeight){
            kh_end = (inHeight + kh_tmp) / dilationHeight;
            if (kh_end >= kernHeight) kh_end = kernHeight;
          }

          int64_t vl = vl_x_init;
          _ve_lvl(vl) ;
          __vr vrj = vrj_init;
          for ( int64_t x0=0; x0<outWidth; x0+=VLEN )
          {
            const int64_t vl = outWidth - x0 < VLEN ? outWidth - x0 : VLEN ;
            _ve_lvl(vl) ;
            __vr vrsum = vzeros;
            // slower:
            //    any use ov _ve_lvs_svs_u64/f32
            //    any type of blocking 'c' loop (many ways tried)
            //    clang prefetch will not compile
            //    precalc offset expressions (cannnot distribute scalar calc better than clang)
            for (int64_t r = kh_beg; r < kh_end; ++r) {
              //const int64_t h = i + r * dilationHeight; // kh_beg,kh_end guarantee h in [0,outHeight)
              __vr vrw = vrj;
              for (int64_t s = 0; s < kernWidth; s++) {
                __vm256 vm2 = _ve_vfmkl_mcv(VECC_GE, vrw) ;        // condition(0 <= w)
                __vm256 vm3 = _ve_vfmkl_mcv(VECC_IG, _ve_vcmpsl_vsv(inWidth,vrw)) ;  // condition(w < inWidth)
                __vm256 vm23  = _ve_andm_mmm(vm2, vm3) ;
                for (int64_t c = 0; c < inChannelGroup; ++c)
                {
                  const float *pIn = pIn_0 + c*inHW + (i+r*dilationHeight)*inWidth + x0*strideWidth-padWidth + s*dilationWidth;

                  const float *pKerValue = pKern_gk + c*kernHW + r*kernWidth +s;
                  __vr vrin = _ve_vldu_vss(4*strideWidth,pIn) ;
                  vrin = _ve_vmrg_vvvm(vzeros, vrin, vm23) ;
                  vrsum = _ve_vfmads_vvsv(vrsum, *pKerValue, vrin) ;
                } // inChannel

                vrw = _ve_vaddsl_vsv(dilationWidth,  vrw) ; // <--- vector induced (not fully calc)
              } // s .. kernWidth
            } // r .. kernHeight
            //_ve_vstu_vss(vrsum, 4, pOut+outIndex) ;
            _ve_vstu_vss(vrsum, 4, pOut) ;
            vrj = _ve_vaddsl_vsv(sw_x_VLEN,vrj); // induce to avoid full recalc
            //outIndex += vl ; /* MUST always execute (before break) */
            pOut += vl; // visible speedup
          } // x
        } // y
      } //k..kMax..kBy (outChannelGroup)
    } // group
  } // batch

  return VEDNN_SUCCESS;
}
#endif
void test_cblock_macros(){
    Cunit pr("program");
    pr.v = 0;
    // overall structure
    pr["comments"]>>"// Cunit output from "<<__func__;
    pr["includes"]>>"#include <assert.h>";
    pr["macros"];
    auto& cfuncs = mk_extern_c(pr,"extern_C")["body"]; // many mk_FOO have a "body" section
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // now fill in a function
    pr.v = 10;
    auto& macs = mk_func(pr,"macs","int macs(int i)").after(cfuncs)["body"]
        <<"assert(i>=0);";
    macs["exit"]>>"return 75/i;";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_cblock_define(){
    Cunit pr("program");
    pr.v = 2;
    pr.root.define("PR_ROOT_0");
    (pr["body"]>>"// pr[\"body\"] HERE")
        .define("PR_BODY_DEF");
    (pr["foo"]>>"// pr[\"foo\"] HERE")
        .define("PR_FOO_DEF")
        .define("MULTILINE1", "do{ \\\n  //something in enclosing scope via 'define' \\\n} while(0)")
        ;
    CBLOCK_SCOPE(blk1,"",pr,pr.root);
    blk1.define("BLK1_DEF1");
    blk1>>"// blk1 HERE";
    (blk1["last"]>>"// blk1 LAST")
        .define("BLK1_LAST_DEF");
    auto& nextsub = (blk1["next"]>>"// blk1/next")["nextsub"];
    (nextsub>>"// blk1/next/nextsub...NEXTSUB_DEF?")
        .define("NEXTSUB_DEF")
        .define_here("LOCAL_HELP", "do{ \\\n  //something local via 'define_here' \\\n} while(0)")
        >>"LOCAL_HELP;"
        >>"LOCAL_HELP;"
        ;
    blk1["last"]>>"// blk1/last HERE";
    CBLOCK_SCOPE(subblock,"",pr,blk1);
    subblock.define("SUBBLOCK_DEF")>>"//subblock";
    CBLOCK_SCOPE(seqsubblock,"",pr,blk1);
    seqsubblock.define("SEQSUBBLOCK_DEF")>>"//seqsubblock";
    blk1.define("BLK1_DEF2");
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
/** a 1-liner sample kernel "type sum = a + b;" */
void kernel_define_sum(Cblock& cb, std::string type, std::string sum, std::string a, std::string b){
    cb>>type<<" "<<sum<<" = "<<a<<" + "<<b<<";";
}
/** a scope kernel "{ foo(); ++COUNTER; } */
Cblock& kernel_scope(Cblock& cb, std::string arg){
    CBLOCK_SCOPE(kernel_scope,"",cb.getRoot(),cb);
    kernel_scope>>"foo("<<arg<<");"
        >>"++COUNTER";
    return kernel_scope;
}
Cblock& kernel_sum_k(Cblock& cb, uint64_t n){    
    static int disambig=0;
    ++disambig;
    std::ostringstream oss;
    auto kName = OSSFMT("kernel_sum_k"<<disambig);
    auto& kern = mk_scope(cb.getRoot(),kName,OSSFMT("for(size_t a=0; a<"<<n<<"; ++a)"))
        .after(cb).at("body");
    kern>>"k+=a;";
    return kern;
}
void test_cblock_kernel(){
    Cunit pr("program");
    pr.v = 0;
    // overall structure
    pr["comments"]>>"// Cunit output from "<<__func__;
    pr["includes"]>>"#include <assert.h>";
    pr["macros"];
    auto& cfuncs = mk_extern_c(pr,"extern_C");
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // now fill in a function
    pr.v = 1;
    CBLOCK_SCOPE(fn,"int fn(int i)",pr,cfuncs);
    fn>>"assert(i>=0);";
    kernel_define_sum(fn,"int","j","i","i");

    auto& sub = kernel_scope(fn,"i");
    sub.define("COUNTER","j");

    kernel_define_sum(fn,"//int","k","i","j"); // oh. would go before sub, which introduced a [] subblock!
    kernel_define_sum(fn["1"],"int","k","i","j"); // I want it after sub.

    kernel_sum_k(fn["ksum3"],3);
    fn["2"]>>"// now use the kernel again";
    kernel_sum_k(fn["ksum5"],5);

    sub>>"// I can add a  comment to sub, after the fact";
    fn["last"]>>"return 75/k;";
    pr.v=0;
    cout<<string(80,'-')<< pr.str() <<string(80,'-')<<endl;
    cout<<string(80,'-')<< pr.tree() <<string(80,'-')<<endl;
}
int main(int,char**){
    test_cblock_basic();
    test_cblock_path();
    test_cblock_short();
    test_cblock_short2();
    test_cblock_dump();
    test_cblock_macros();
    test_cblock_define();
    test_cblock_kernel();
    string code = cjitConvolutionForward00(); // optional arg: verbosity=0
    cout<<string(80,'-')<< code <<string(80,'-')<<endl;
    assert(code.size()>0);
    cout<<"\nGoodbye"<<endl; cout.flush();
}
#endif // MAIN_CBLOCK
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
#include "asmblock.hpp"
#include "asmfmt.hpp"
#include "stringutil.hpp"

#ifdef MAIN_ASMBLOCK
using namespace asmprog;
using namespace std;

#define MUST_THROW(CODE) do{ \
    int threw = 0; \
    try{ \
        CODE; \
    }catch(...){ \
        threw = 1; \
    } \
    if( threw == 0 ){ \
        std::cout<<"Error: following code should have thrown:\n" \
        << #CODE << std::endl; \
        THROW("Stopping now"); \
    } \
}while(0)

/** This uses simple paths only, and demonstrates how output
 * order can be controlled.
 * - Simple Pre/Post-Indent "manipulator" demo.
 * - Notice that begin/middle/end constructs are awkward.
 */
void test_asmblock_basic(){
    Asmunit pr("asm");
    pr.v = 2; // 3 is actually hard to grok
    pr["comments"]>>"// Asmunit output from "<<__FILE__;

    // asm has its own snippet-formatting helper, "AsmFmtCols"
    AsmFmtCols f_root;
    AsmFmtCols f_init;
    AsmFmtCols f_calc;
    // set scope w/ register mappings for input vars
    f_root.scope(AsmScope{{"i","%s0"},{"j","%s1"}});
    // init registers
    f_init.ins("lea i,3; lea j,5");
    // add JIT calc, either add or subtract
    std::string calc="add";
    f_root.def("OP",(calc=="add"?"adx":"sbx"));  // jit add or subtract
    f_calc.ins("OP i,j");

    // arrange the AsmFmtCols into final program
    pr.dump(cout); cout.flush();

    // Very important to use 'auto&' instead of plain 'auto'
    auto& body = mk_scope(pr,"root").after("/")["body"];

    pr.dump(cout); cout.flush();
    cout<<" f_root is now <<<"<<f_root.str()<<">>>"<<endl;
    // f_root has defines, and pop_scopes has the undefs
    pr["/root/beg"]<<f_root.flush();
    pr["/root/end"]<<f_root.flush_all();
    // add init and calc assembly to 'body' location.
    body<<f_init.flush_all();
    body<<f_calc.flush_all();
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
#if 0
void test_asmblock_path(){
    Asmunit pr("program");
    pr.v = 3;
    Asmblock& root = pr.root;
    assert( root.find("") == nullptr );
    assert( root.find("asdfalsdkjfalsdkfj") == nullptr );
    assert( root.find("/") == &root );
    assert( root.find("/..") == &root );
    assert( root.find("/../") == &root );
    assert( root.find(".") == &root );
    assert( root.find("..") == &root );
    assert( root.find("./") == &root );
    assert( root.find("../") == &root );
    assert( root.find("./asdf") == nullptr );
    assert( root.find("../asdf") == nullptr );
    assert( root.find("*/asdf") == nullptr );
    assert( root.find("*/open") == nullptr );
    // creates "/includes", no var because never refered to later
    pr["includes"]<<"#include <stdio.h>";
    assert( root.find("includes") != nullptr );
    assert( root.find("includes")->getName() == "includes" );
    assert( root.find("includes") == &pr["includes"] );
    assert( root.find("/includes") != nullptr );
    assert( root.find("./includes") != nullptr );
    assert( root.find("../includes") != nullptr ); // because .. of root is root again
    assert( root.find("open") == nullptr );
    // Very important to use 'auto&' instead of plain 'auto'
    auto& macros = pr["macros"];
    auto& extern_c = pr["extern_C"];
    assert( extern_c.find("../open") == nullptr );
    assert( extern_c.find("./includes") == nullptr );
    assert( extern_c.find("../includes") != nullptr );
    assert( extern_c.find("/../includes") != nullptr );
    assert( extern_c.find("extern_C") != nullptr );
    extern_c["open"]<<
        "\n#ifdef __cplusplus\n"
        "extern \"C\" {\n"
        "#endif //C++\n";
    assert( extern_c.find("../open") == nullptr );
    assert( extern_c.find("./includes") == nullptr );
    assert( extern_c.find("../includes") != nullptr );
    assert( root.find("open") == nullptr );
    assert( extern_c.find("open") != nullptr );
    assert( extern_c.find("./open") != nullptr );
    assert( extern_c.find("./open//") != nullptr );
    assert( root.find("*/open") != nullptr );
    assert( root.find("**/open") != nullptr );
    assert( root.find("extern_C/open") != nullptr );
    pr["extern_C"]["close"] // or as multiple strings
        >>"#ifdef __cplusplus\n"
        <<"}//extern \"C\"\n"
        <<"#endif //C++\n\n";
    //auto& functions = (pr["functions"].after(extern_c["open"]));
    auto& functions = extern_c["open"]["functions"]; // simpler equiv
    // '\:' --> '\\:'
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    pr["includes"]<<"#include <stdio.h>";
    macros<<"#define MSG \"hello\"";
    auto& foo = functions["foo"];
    // Klunky beg/middle/end w/ manipulator to adjust write context
    foo["beg"]<<"int foo() {"<<PostIndent(+2);
    foo["mid"]<<"return 7;";
    foo["end"]<<"}"<<PreIndent(-2);
    functions["bar"]<<"int bar(){ return 43; }\n";

    // output order can be adjusted with after:
    functions["foo"].after(functions["bar"]);
    assert( root.find("*/foo") == nullptr );
    assert( root.find("**/foo") != nullptr );
    assert( root.find("/extern_C/open/functions/bar/foo/mid/") != nullptr );
    assert( root.find("extern_C/open/functions/bar/foo/mid/") != nullptr ); 
    assert( root.find("program/extern_C/open/functions/bar/foo/mid/") == nullptr ); 
    assert( functions.find("..*/open") != nullptr );
    cout<<"\n\n"<<endl; cout.flush();
    assert( foo.find("..*/bar/") != nullptr ); // find in recursive "parent/sibling tree"

    // Asmblock::operator[p] was extended.
    // ORIGINAL behaviour for non-path p [no /] is to create the component
    // if it is not an immediate subblock.
    // NEW behaviour allows p to be a path,
    // and throws if p.empty() or p is a nonexistent path.
    try{
        std::cout<<"\n\n Asmblock::at(p) tests"<<std::endl;
        assert( root.at(".").getName() == "program" );
        assert( root.at("..").getName() == "program" );
        assert( root.at("/macros").getName() == "macros" );
        assert( root.at("./macros").getName() == "macros" );
        assert( root.at("macros").getName() == "macros" );
        assert( root.at("*/open").getName() == "open" );
        assert( root.at("**/foo").getName() == "foo" );
        assert( root.at("*/../macros").getName() == "macros" );
    }catch(...){
        cout<<" Caught something\n";
        throw;
    }
    std::cout<<"\n\n Asmblock::at(p) THROW tests"<<std::endl;
    MUST_THROW(root["*"]); // Paranoia about bugs wrt wildcards
    MUST_THROW(root[".illegal"]);
    MUST_THROW(root[".illegal"]);
    MUST_THROW(root.at("*"));
    MUST_THROW(root.at("*illegal"));
    MUST_THROW(root.at(".illegal"));

    MUST_THROW(root.at("asdfqewrasdf"));
    MUST_THROW(root.at("macrossss"));
    MUST_THROW(root.at("*/foo"));
    MUST_THROW(root.at("**/asdlkfj"));
    MUST_THROW(root.at("/extern_c/open")); // should be capital C
    MUST_THROW(root.at("never_seen_path"));

    try{
        std::cout<<"\n\n Asmblock::operator[](p) tests"<<std::endl;
        assert( root["."].getName() == "program" );
        assert( root[".."].getName() == "program" );
        assert( root["/macros"].getName() == "macros" );
        assert( root["./macros"].getName() == "macros" );
        assert( root["macros"].getName() == "macros" );
        assert( root["*/../macros"].getName() == "macros" );
        assert( root["*/open"].getName() == "open" );
        assert( root["*/open"].fullpath() == "/extern_C/open" );
        assert( root["**/open"].getName() == "open" );
        // 1-component ==> create if never seen ...
        assert( root["never_seen_path"].getName() == "never_seen_path" );
    }catch(...){
        cout<<" Caught something\n";
        throw;
    }
    std::cout<<"\n\n Asmblock::operator[](p) THROW tests"<<std::endl;
    MUST_THROW(root["./newsub"]); // cf. root["newsub"] which never fails
    MUST_THROW(root["*/foo"]);
    MUST_THROW(root["**/asdlkfj"]);
    MUST_THROW(root["/extern_c/open"]); // should be capital C

    //main.after("extern_C/open");
    pr.v = 2;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_asmblock_short(){
    Asmunit pr("program");
    pr.v = 0;
    pr["comments"]>>"// Asmunit output from "<<__FILE__;
    // Very important to use 'auto&' instead of plain 'auto'
    pr["includes"]>>"#include <stdio.h>";
    pr["macros"]>>"#define MSG \"hello\"";
    //mk_extern_c(pr,"extern_C").after(pr["macros"]);
    //  new function: after can accept an absolute path
    mk_extern_c(pr,"extern_C").after("/macros");

    // creates "functions", appends foo/decl foo/body foo/end
    auto& foo_body = mk_func(pr,"foo","int foo()").after(pr["functions"])["body"];
    // for complex items, foo_body will itself get subdivided!

    // append(string) to _code is really only useful for simple stuff.
    // complex cases should name all sections/blocks ...
    foo_body["entry"]<<"int ret=-1;";   // foo/body/entry (anchored)

    // OK, this seems a reasonable idiom .. if00 --> path "/**/foo/body/if00/body"
    auto& if00 = mk_scope(pr,"if00","if(!defined(__cplusplus))").after(foo_body)["body"]; {
        if00<<"ret = 1;";
    }
    // with macros, a bit more readable, else00 --> Asmblock path "/**/foo/body/else00/body"
    CBLOCK_SCOPE(else00,"else",pr,foo_body) {
        else00<<"ret = 2;";
    }
    CBLOCK_SCOPE(for00,"for(int i=0;i<10;++i)",pr,foo_body) {
        for00<<"ret = (ret^magic); //just to demo"
            >>"ret += i*magic2;\t// how to 'randomize' ret a bit";
        // oh, I wanted a magic const to be hoisted up into "entry" code...
        foo_body["entry"]>>"int const magic=0x12345678;";
        // or do an 'upward search' for a previously created code block (or stub)
        //for00.up["entry"]>>"int const magic2=0x23456789;";
        for00["..*/entry"]>>"int const magic2=0x23456789;";
    }
    //foo_body["exit"]<<"printf(\"%s\\nGoodbye\",MSG);\nreturn ret;";
    foo_body["exit"]<<CSTR(printf("%s\nGoodbye",MSG);\nreturn ret;);

    // short functions can be ... very short
    //mk_func(pr,"bar","int bar()").after(pr["functions"])["body"]<<"return 7";
#if 1-1
    // can we do Pre(Indent(-2)) for _pre.push_front(...) ?
    // or Pre-Manip, Pre+Manip for _pre.push_front/back <----
#endif
    // output order can be adjusted with after:
    pr["functions"].after("/**/extern_C/body"); // The "/**" is just for show
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    //main.after("extern_C/open");
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}

void test_asmblock_short2(){
    Asmunit pr("program");
    pr.v = 0;
    // Very important to use 'auto&' instead of plain 'auto'
    pr["comments"]>>"// Asmunit output from "<<__FILE__;
    pr["includes"]>>"#include <iostream>";
    pr["macros"]>>"define MSG \"hello\"";
    mk_extern_c(pr,"extern_C").after("/macros");
    // a somewhat more complicated function...
    auto& foo_body = mk_func(pr,"foo","int randomizer()").after(pr["functions"])["body"];
    foo_body["entry"]<<"int ret=-1;";   // foo/body/entry (anchored)
    int opt_level = 0; // my JIT decision making procedure

    CBLOCK_SCOPE(if00,"if(__FILE__[0]=='b')",pr,foo_body) {
        if00<<"ret = 1;";
    }
    CBLOCK_SCOPE(else00,"else",pr,foo_body) {
        else00<<"ret = 2;";
    }
    foo_body["preloop"]<<"// I have selected JIT randomization method "<<asDec(opt_level);
    CBLOCK_SCOPE(for00,"for(int i=0; i<10; ++i)",pr,foo_body) {
        CBLOCK_SCOPE(for01,"for(int j=i;i<10;++j)",pr,for00) {
            // Scenario: I have many JIT possibilities, but I decide to
            // use the following code ....
            if(opt_level==0) { // Oh, maybe I want my original JIT version ...
                for01<<"ret = (ret^magic); //just to demo"
                    // original version ...
                    >>"ret += (i*23+j)*magic2;\t// how to 'randomize' ret a bit";

                // I JIT realize this optimization uses some
                // undefined const values into foo/body/entry
                // ... NO PROBLEM ... Let's add to that code snippet
                foo_body["entry"]>>"int const magic=0x12345678;";   // exact destn known
                for01["..*/entry"]>>"int const magic2=rand();";     // alt "up-search-near" method
                // oh, I JIT realize I need yet another C header
                pr["includes"]>>"#include <stdlib.h>";
            }else if(opt_level==1){
                for01<<"ret = ret + i + j"; // this JIT is faster (but maybe not so random)
            }else{
                // OTHER JIT impls of foo are not shown, but may need entirely different
                //                 sets of code and patches to upward blocks of pr
            }
        }//j-loop
    }//i-loop
    foo_body["exit"]<<CSTR(printf("%s\nGoodbye",MSG);\nreturn ret;);
    pr["functions"].after("/**/extern_C/body"); // allow generous search (it is not directly under root)
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_asmblock_dump(){
    Asmunit pr("program");
    pr.v = 0;
    // overall structure, also demo new ','-operator (auto-supplies an initial newline)
    pr["comments"]>>"// Asmunit output from "<<__func__;
    pr["includes"]>>"#include <assert.h>";
    pr["macros"];
    auto& cfuncs = mk_extern_c(pr,"extern_C")["body"]; // many mk_FOO have a "body" section
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // now fill in a function
    pr.v = 10;
    pr["/"].dump(cout);
    cout<<"\nHmmmm.  Let's look at dump to see how one instruction worked\n\n"<<endl;
    auto& macs = mk_func(pr,"macs","int macs(int i)")
        .after(cfuncs)["body"]
        <<"assert(i>=0);";
    pr["/"].dump(cout);
    macs>>"return 75/i;";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
void test_asmblock_macros(){
    Asmunit pr("program");
    pr.v = 0;
    // overall structure
    pr["comments"]>>"// Asmunit output from "<<__func__;
    pr["includes"]>>"#include <assert.h>";
    pr["macros"];
    auto& cfuncs = mk_extern_c(pr,"extern_C")["body"]; // many mk_FOO have a "body" section
    pr["end"]<<"// vim: ts=4 sw=4 et cindent cino=^=l0,\\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\\:,0#,!^F,o,O,e,0=break";
    // now fill in a function
    pr.v = 10;
    auto& macs = mk_func(pr,"macs","int macs(int i)").after(cfuncs)["body"]
        <<"assert(i>=0);";
    macs["exit"]>>"return 75/i;";
    pr.v = 0;
    cout<<string(80,'-')<<endl;
    pr.write(cout);
    cout<<string(80,'-')<<endl;
}
#endif
int main(int,char**){
    test_asmblock_basic();
#if 0 // most test were removed!
    test_asmblock_path();
    test_asmblock_short();
    test_asmblock_short2();
    test_asmblock_dump();
    test_asmblock_macros();
#endif
    cout<<"\nGoodbye"<<endl; cout.flush();
}
#endif // MAIN_ASMBLOCK
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
#include "dllbuild.hpp"
//#include "cblock.hpp"    // prefix_lines (debug output)
#include "throw.hpp"
#include "jitpage.h"    // low level 'C' utilities
#include <fstream>
#include <cstring>
#include <assert.h>
#include <unistd.h>     // getcwd, sysconf, pathconf, access
#include <sys/stat.h>   // stat (possibly faster than 'access') and I check size

#define PSTREAMS 0
#if PSTREAMS
#include "pstreams-1.0.1/pstream.h"
#endif

/** need a better way to [easily] disable unrolled compiles */
#define UNROLLS 1

using namespace std;

/** 0 ~ we are linked with bin.mk object file,
 *  1 ~ read bin.mk (from current dir, fragile?). */
#define BIN_MK_FROM_FILE 0
#if ! BIN_MK_FROM_FILE
extern "C" {
#if 0
// using objcopy to create a .rodata section works ONLY if you make a static lib    
extern unsigned char _binary_bin_mk_start;
extern unsigned char _binary_bin_mk_end;
extern unsigned char _binary_bin_mk_size;
#else
// it's always ok to convert to C_string and "compile" bin.mk file into a string
// see ftostring.cpp
extern char const bin_mk[];
extern int bin_mk_size;
#endif
}//extern "C"

static std::string bin_mk_file_to_string(){
    //system("ls -l bin.mk");
    //cout<<" binary_bin_mk_start @ "<<(void*)&_binary_bin_mk_start<<endl;
    //cout<<" binary_bin_mk_end   @ "<<(void*)&_binary_bin_mk_end<<endl;
    //cout<<" binary_bin_mk_size    "<<(size_t)&_binary_bin_mk_size<<endl;
    //return std::string((char*)&_binary_bin_mk_start, (size_t)&_binary_bin_mk_size);
    cout<<" bin_mk @ "<<(void*)&bin_mk[0]<<endl;
    cout<<" bin_mk_size "<<bin_mk_size<<endl;
    cout.flush();
    return std::string(&bin_mk[0], (size_t)bin_mk_size);
}
#else
static std::string bin_mk_file_to_string(){
    std::ostringstream oss;
    try{
        if(access("bin.mk",R_OK))
            THROW("No read access to template file bin.mk");
        ifstream ifs("bin.mk");
        if(ifs){
            oss << ifs.rdbuf();
            ifs.close();
        }
    }catch(...){
        cout<<" Trouble appending bin.mk template to makefile string"<<endl;
        throw;
    }
    return oss.str();
}
#endif

static std::string getPath();

class FileLocn {
    std::string subdir;
    std::string basename;
    std::string suffix;
    // calculated:
    std::string abspath;
    std::string fullpath;
};
SubDir::SubDir(std::string subdir)
: subdir(subdir), abspath(subdir)
{
    if(createDirectoryAnyDepth(subdir.c_str())){
        THROW("Write access denied to "+subdir);
    }
    if(subdir[0] != '/'){
        abspath = getPath() + '/' + subdir;
    }
}
std::string DllFile::short_descr() const {
    std::ostringstream oss;
    oss <<basename<<"."<<suffix
        <<" "<<code.size()<<" code bytes, "
        <<syms.size()<<" symbols";
    return oss.str();
}
/** Unfortunately, multiple compilations rely on bin.mk file rule details,
 * so now we return a vector of objects. */
std::vector<std::string> DllFile::obj(std::string fname){
    std::vector<std::string> ret;
    size_t p, pp=0;
    std::vector<char const*> alts;
    cout<<" Dllfile::obj(\""<<fname<<"\")..."<<endl; cout.flush();
    if((p=fname.rfind('-'))!= std::string::npos){
        if(0){ ;
        }else if((p=fname.rfind("-vi.c"))==fname.size()-5){
            pp=p;
            // need a better way to disable unrolled compiles XXX
#if UNROLLS
            alts.push_back("_unroll-ve.o");
#endif
        }else if((p=fname.rfind("-vi.cpp"))==fname.size()-7){ pp=p;
        }else if((p=fname.rfind("-ncc.c"))==fname.size()-6){ pp=p;
        }else if((p=fname.rfind("-ncc.cpp"))==fname.size()-8){ pp=p;
        }else if((p=fname.rfind("-clang.c"))==fname.size()-8){ pp=p;
        }else if((p=fname.rfind("-clang.cpp"))==fname.size()-10){ pp=p;
        }
        if(pp){ // all make fname[0:pp)+"-ve.o", and perhaps some alts
            ret.push_back(fname.substr(0,pp).append("-ve.o"));
            for(auto const& suffix: alts){
                ret.push_back(fname.substr(0,pp).append(suffix));
            }
        }
    }
    if(ret.empty()){
        auto last_dot = fname.find_last_of('.');
        if(last_dot != std::string::npos){
            std::string ftype = fname.substr(last_dot+1);
            if( ftype == "c" || ftype == "cpp" ){
                ret.push_back(fname.substr(0,last_dot) + "-ve.o");
            }else if( ftype == "s" || ftype == "S" ){
                ret.push_back(fname.substr(0,last_dot) + ".bin");
            }
        }
    }
    if(ret.empty()) THROW("DllFile::obj("<<fname
            <<") must match %[-vi|-ncc|-clang].{c|cpp} or %.{s|S} (see bin.mk rules)");
    return ret;
}
/** \b new: if file exists and "same", don't rewrite it */
std::string DllFile::write(SubDir const& subdir){
    int const v = 1;
    string myfile;
    {
        std::ostringstream oss;
        oss <<"//Dllfile: basename = "<<basename
            <<"\n//Dllfile: suffix   = "<<suffix
            <<"\n//Dllfile: abspath  = "<<abspath;
        if(v>1){cout<<" generating comment: "<<comment<<endl; cout.flush();}
        oss <<"\n"<<comment;
        if(v>1){cout<<" copying code: "<<code<<endl; cout.flush();}
        oss <<"\n"<<code
            <<endl;
        myfile = oss.str();
    }

    this->abspath = subdir.abspath + "/" + this->basename + this->suffix;

    // check file existence, and whether we can skip the rewrite
    bool writeit = true;
    {
        struct stat st;
        if(stat(abspath.c_str(), &st)){
            cout<<" my size "<<myfile.size();
            if((size_t)st.st_size == myfile.size()){ // file size matches => "same" (hack)
                writeit = false;
                if(v>1)
                    cout<<" matches existing file, so NOT overwriting";
            }else{
                if(v>1) cout<<" differs from existing file size "<<st.st_size;
            }
        }else{
            if(v>1) cout<<" and target file does not exist";
        }
    }

    if(writeit){
        try{
            std::ofstream ofs(abspath);
            if(v>1){cout<<" ofstream ofs("<<abspath<<") CREATED"<<endl; cout.flush();}
            ofs<<myfile;
            if(v>1){cout<<" and an extra ofs.flush() !!!"<<endl; cout.flush();}
            ofs.flush();
            ofs.close();
        }catch(...){
            cout<<" Trouble writing file "<<abspath<<endl;
            throw;
        }
        if(v>0){cout<<" Wrote file "<<abspath<<endl;}
    }
    return this->abspath;
}



std::string getPath() {
    long const sz = pathconf(".",_PC_PATH_MAX); // assume we are interested cwd
    if(sz<=0) THROW("Invalid max path length?");
    char* const temp=(char*)malloc((size_t)sz);
    if(temp==nullptr) THROW("Out of memory");
    if ( getcwd(temp, sz) != 0) 
        return std::string(temp);
    int error = errno;
    switch ( error ) {
        // sz>0 alreay checked (no EINVAL)
        // PATH_MAX includes the terminating nul (no ERANGE)
      case EACCES: THROW("Access denied");
      case ENOMEM: THROW("Insufficient storage"); // is this possible?
      default: THROW("Unrecognised errno="<<error);
    }
}
    
#if 0
/** create a tmp file in some [plain] subdirectory */
FileLocn writeFile(std::string const& code, std::string const& basename,
        std::string suffix, std::string subdir){
    // other inputs: this->basename, this->outDir, suffix
    // output:       this->ccode_tmpfile
    std::string base = basename;
    std::string suffix(".c");

    if( code.empty() )
        THROW(" Error: mkTmpfile with no 'C' code string? ");
    if( !ccode_tmpfile.empty() ){
        std::cerr<<" Did you forget to 'run' the DllPipe on temporary file "<<ccode_tmpfile<<" ?"<<std::endl;
    }
    // Write, then set this->ccode_tmpfile
    {
        //std::string tmpfile(std::tmpnam(nullptr));
        // 
        // warning: the use of `tempnam' is dangerous, better use `mkstemp'
        //  ... but not sure about portability of mkstemp ...
        //
        std::string tmpfile(tempnam(outDir.c_str(),"tmp")+std::string("_")+base+suffix);
        std::cout<<" DllPipe writing code to "<<tmpfile<<" ..."<<std::endl;
        try{
            std::ofstream ofs(tmpfile);
            ofs<<code<<std::endl;
            ofs.close();
        }catch(...){
            THROW("Problem creating "<<tmpfile<<" 'C'-code file)");
        }
        this->ccode_tmpfile = tmpfile;
    }
}
#endif

std::string const & DllBuild::getLibName() const {
    if(!prepped) THROW("getLibName requires DllBuild::prep(basename,dir)");
    return this->libname;
}

/** Generating the Makefile
 *
 * - adds a prefix to canned rules of \e bin.mk Makefile template
 * - notably, \e all: target is a shared library
 * - bin.mk now can produce multiple clang versions.
 * - also creates basename.OBJECTS so Makefile can circumvent command line limits
 *
 * \c skip added so existing Makefile or source files would not get
 * rewritten.
 */
void DllBuild::prep(string basename, string subdir/*="."*/){
    if(empty()){
        cout<<" Nothing to do for dll "<<basename<<endl;
        return;
    }
    this->dir      = SubDir(subdir);
    this->basename = basename;
    this->libname  = "lib"+this->basename+".so";
    string archive = "lib"+this->basename+".a";  // NEW
    this->mkfname  = this->basename+".mk";
    this->fullpath = dir.abspath+"/"+libname;

    ostringstream mkfile;
    // at_file is so mkfile can use @FILE way to avoid command line length limits
    string at_filename(this->basename+".OBJECTS");
    ostringstream at_file;
    
    at_file<<"\n";
    mkfile<<"# Auto-generated Makefile for "<<libname;
    mkfile<<"\nLIBNAME:="<<libname
        <<"\nARCHIVE:="<<archive
        //<<"\nLDFLAGS:=$(LDFLAGS) -shared -fPIC -Wl,-rpath="<<dir.abspath<<" -L"<<dir.abspath
        <<"\nLDFLAGS:=-shared -fPIC -Wl,-rpath="<<dir.abspath<<" -L"<<dir.abspath<<" $(LDFLAGS)";
    mkfile<<"\n.PHONY: hello goodbye all\n"
        <<"all: hello $(ARCHIVE) $(LIBNAME) goodbye\n";
    // Let's be even more careful about duplicates (multiply-defined-symbols if identical code)
    for(size_t i=0U; i<size(); ++i){
        auto& df_i = (*this)[i];
        if( df_i.basename.empty() ){
            cout<<" DllFile "<<i<<" had no basename (removing)"<<endl;
            continue;
        }
        for(size_t j=0U; j<i; ++j){
            auto& df_j = (*this)[j];
            if( df_i.basename == df_j.basename ){
                if( df_i.suffix == df_j.suffix){
                    if( df_i.code == df_j.code && df_i.syms.size() == df_j.syms.size() ){
                        cout<<" Duplicate DllFile "<<i<<" matches "<<j<<", IGNORED "<<i
                            <<"\n    prev: "<<df_j.short_descr()
                            <<"\n    skip: "<<df_i.short_descr()
                            <<endl;
                    }else{
                        cout<<" Duplicate DllFile "<<i<<" vs "<<j<<"! code/syms do not match "
                                <<"\n    prev: "<<df_j.short_descr()
                                <<"\n    skip: "<<df_i.short_descr();
                        THROW(" Duplicate DllFile "<<i<<" vs "<<j<<"! code/syms do not match "
                                <<"\n    prev: "<<df_j.short_descr()
                                <<"\n    skip: "<<df_i.short_descr());
                    }
                }else{
                    cout<<" Duplicate DllFile "<<i<<" w/ different suffix from "<<j<<", IGNORED "<<i
                        <<"\n    prev: "<<df_j.short_descr()
                        <<"\n    skip: "<<df_i.short_descr()
                        <<endl;
                }
#define DLLBUILD_ERASE_SUSPICIOUS 1
#if DLLBUILD_ERASE_SUSPICIOUS
                df_i.basename.clear(); // mark for full erasure from build
                break;
#else // keep it around, but disable its syms and library inclusion (for debug?)
                // UNTESTED CODE
                std::ostringstream oss;
                oss<<df_i.suffix<<".dup_"<<i<<'_'<<j;
                df_i.suffix = oss.str(); // remove by change suffix and clearing syms
                cout<<"    changed DllFile "<<i<<" suffix to "<<df_i.suffix<<endl;

                df_i.comment = "REMOVED "+df_i.comment;
                df_i.syms.clear();
                cout<<"    and clearing its symbols"<<endl;
                // keep the tag? or punt it to the old one?  (not sure)

                if(0){ // with changed suffix and empty syms, we can still write a file
                    // in case it helps debug...
                    oss.str("");
                    oss<<"#if 0 /* Test file "<<i<<" removed, similar to prev "<<j
                        <<"\n    prev: "<<(*this)[ j ].short_descr()
                        <<"\n    skip: "<<(*this)[ i ].short_descr()
                        <<df_i.code
                        <<"\n#endif /* test removed! */";
                    df_i.code = newcode.str();
                }
#endif
                break; // important!
            }
        }
    }
    if(DLLBUILD_ERASE_SUSPICIOUS) { // fully remove the DllFile?
        for(auto it=begin(); it!=end(); ){
            if( it->basename.empty() ){
                it = erase(it);
            }else{
                cout<<" Keeping: "<<it->basename<<"."<<it->suffix<<endl;
                ++it;
            }
        }
    }
    {
        ostringstream sources; sources<<"\nSOURCES:=";
        ostringstream objects; objects<<"\nOBJECTS_FILE:="<<at_filename<<"\nOBJECTS:=";
        ostringstream deps;    deps   <<"\n";
        ostringstream hello;   hello  <<"\n";
        ostringstream goodbye; goodbye<<"\ngoodbye:\n"
            <<"\t@echo 'Goodbye, "<<mkfname<<" ending'\n";
#define DLLBUILD_SIMPLE_RENAMES 0
#if DLLBUILD_SIMPLE_RENAMES
        //
        // To think about...
        //
        // By creating rename files for every possible target, we will always generate
        // an alternate unroll_FUNC call for every FUNC in FUNC-vi.c.
        // Downside:
        //   1. you only want some unroll_FUNCs
        //   2. FUNC names are not obtained from the sourcefile stem
        //
        // current method allows client-specified symbols to be renamed, but can
        // still run into problems with multiply defined symbols for the *other* FUNCs
        //
        // XXX Eventually, will want also to objcopy -N <name>  to --strip-symbol
        // the alternate-compile symbols that we want to remove
        //
        hello<<
            "\n$(patsubst %-vi.c,%_unroll-ve.o.rename,$(SOURCES)): %_unroll-ve.o.rename:: %-vi.c"
            "\n\t@# assume stem exactly matches the function name!"
            "\n\techo '$* unroll_$*' > $@"
            "\nhello: | $(patsubst %-vi.c,%_unroll-ve.o.rename,$(SOURCES))"
            "\n\techo 'Hello, cjitConv.mk begins'"
#endif
        for(size_t i=0U; i<size(); ++i){
            DllFile& df = (*this)[i];
            if(1){ // handle absent fields in DllFile
                if(df.basename.empty()){
                    ostringstream oss;
                    oss<<"lib"<<basename<<"_file"<<i;
                    df.basename=oss.str();
                    cout<<" Warning: auto-suppying source file name "<<oss.str()<<endl;
                }
                if(df.suffix.empty()){
                    df.suffix = "-ncc.c";
                    cout<<" Warning: auto-suppying source suffix "<<df.suffix
                        <<" for basename "<<df.basename<<endl;
                }
            }

            string dfSourceFile = df.basename+df.suffix; // no "." because suffix could be "-vi.c"
            sources<<" \\\n\t"<<dfSourceFile;
            df.objects = DllFile::obj(dfSourceFile); // checks name correctness
            // A source file might produce several objects by different compile options
            // The symbols should be renamed to coexist in a single dll
            //
            // objcopy with a rename file seems best way to rename
            // compile-option-differentiated symbols.
            //
            vector<SymbolDecl> altsyms;
            for(auto const& object: df.objects){
                objects<<" \\\n\t"<<object; // add to makefile OBJECTS:=
                at_file<<object<<"\n";      // also add to @FILE to circumvent command line limits
                deps<<"\n"<<object<<": "<<dfSourceFile;
                // What object file types do we recognize?
                if(object.rfind("_unroll-ve.o")==object.size()-12){
                    ostringstream rename;
                    for(auto const& sd: df.syms){ // SymbolDecl
                        string altname = "unroll_"+sd.symbol;
                        string altfwd = sd.fwddecl;
                        size_t fnLoc = altfwd.find(sd.symbol);
                        if(fnLoc != string::npos)
                            altfwd.replace(fnLoc, sd.symbol.length(), altname);
                        altsyms.emplace_back(altname,"unrolled version",altfwd);
                        rename<<"\techo '"<<sd.symbol<<" "<<altname<<"' >> $@\n";
                    }
                    string renames = rename.str();
                    //std::cout<<" XXX renames = <"<<renames<<">\n";
                    if(!renames.empty()){
                        string renameFile(object);
                        renameFile.append(".rename");
                        mkfile<<"\n"<<renameFile<<":"
                            <<"\n\t@rm -f "<<renameFile<<"\n"
                            <<renames;
                        hello<<"\nhello: |"<<renameFile; // create this FIRST (only if not present)
                    }
                }
            }
            // append all altsyms, from any alternate object files
            if(!altsyms.empty()){
                df.syms.reserve(df.syms.size() + altsyms.size());
                for(auto const &s: altsyms)
                    df.syms.push_back(s);
            }

            df.abspath = dir.abspath+'/'+dfSourceFile;
            df.write(this->dir);            // source file input (throw if err)
        }
        mkfile<<"\n#sources\n"<<sources.str()<<endl;
        mkfile<<"\n#deps   \n"<<deps   .str()<<endl;
        mkfile<<"\n#objects\n"<<objects.str()<<endl;
        mkfile<<hello.str();
        mkfile<<"\nhello:\n\techo 'Hello, "<<mkfname<<" begins'\n";
        mkfile<<"\n"<<goodbye.str()<<endl;
        mkfile<<endl;
    }
    mkfile<<"\n# end of customized prologue.  Follow by standard build recipes from bin.mk\n";
    mkfile << bin_mk_file_to_string() << "\n#";
    { // write mkfile to <dir.abspath>/<mkfname>
        std::string absmkfile;
        try{
            absmkfile = dir.abspath+"/"+mkfname;
            ofstream ofs(absmkfile);
            if(ofs){
                //ofs << mkfile.rdbuf();
                ofs << mkfile.str();
                ofs.flush();
                ofs.close();
            }else{
                THROW(" Trouble constructing ofs("<<absmkfile<<")");
            }
        }catch(...){
            cout<<" Trouble writing file "<<absmkfile<<endl;
            throw;
        }
        cout<<" makefile written: "<<absmkfile<<endl;
    }

    // NOTE alternate is to write the @FILE as a series of 'echo' commands, right
    // into the makefile itself.
    { // write at_file.str() to <dir.abspath>/<at_filename>
        std::string absatfile;
        try{
            absatfile = dir.abspath+"/"+at_filename;
            ofstream ofs(absatfile);
            if(ofs){
                //ofs << mkfile.rdbuf();
                ofs << at_file.str();
                ofs.flush();
                ofs.close();
            }else{
                THROW(" Trouble constructing ofs("<<absatfile<<")");
            }
        }catch(...){
            cout<<" Trouble writing file "<<absatfile<<endl;
            throw;
        }
        cout<<" @FILE list of object files written: "<<absatfile<<endl;
    }
    // sometimes the 'make' does nothing ??? check that files are really there.
    {
        auto ls = "ls -l "+dir.abspath+" *.mk lib*";
        if(system(ls.c_str())!=0) cout<<"Issues with command `"<<ls<<"`"<<endl;
    }
    prepped = true;
}
void DllBuild::skip_prep(string basename, string subdir/*="."*/){
    if(empty()){
        cout<<" Nothing to do for dll "<<basename<<endl;
        return;
    }
    this->dir      = SubDir(subdir);
    this->basename = basename;
    this->libname  = "lib"+this->basename+".so";
    string archive = "lib"+this->basename+".a";  // NEW
    this->mkfname  = this->basename+".mk";
    this->fullpath = dir.abspath+"/"+libname;
    std::string absmkfile = dir.abspath+"/"+mkfname;
    if(access(absmkfile.c_str(),R_OK)){
        cout<<" Oh-oh. Cannot skip generating "<<mkfname;
        this->prep(basename,subdir);
    }else{
        cout<<" Re-using "<<absmkfile<<endl;
        prepped = true;
    }
}
static int try_make( std::string mk, std::string mklog, int const v/*verbose*/ ){
    string mk_cmd = mk;
#if 1
    auto ret = system(mk_cmd.c_str());
    if(ret){
        //THROW(" Build error: "+mk);
        cout<<" Build error: "<<mk_cmd<<endl;
        cout<<" Build ret  : "<<ret<<endl;
    }
    return ret;
#else // pstreams to capture stdout, stderr into log files etc.
    if(!mklog.empty())
        mk_cmd.append(" >& ").append(mklog);
    cout<<" Build command: "<<mk_cmd<<endl;

    using namespace redi;
    redi::pstream mkstream(mk_cmd,
            pstreams::pstdin | pstreams::pstdout | pstreams::pstderr);
    mkstream << peof;
    string err;
    string out;
    int status;
    int error;
    {
        mkstream.err();
        std::stringstream ss_err;
        ss_err << mkstream.rdbuf();
        err = ss_err.str();   // stderr --> std::string
    }
    {
        mkstream.out();
        std::stringstream ss_out;
        ss_out << mkstream.rdbuf();
        out = ss_out.str();   // stdout --> std::string
    }
    mkstream.close();                 // retrieve exit status and errno
    status = mkstream.rdbuf()->status();
    error  = mkstream.rdbuf()->error();
    if(error || status){
        cout<<" Please check build log in "<<mklog<<endl;
    }
    if(0){ //Is following correct?
        // even in quiet mode mode: write 'make' output into a file:
        std::ofstream ofs(mklog, ios_base::app);
        ofs<<string(40,'-')<<" stdout:"<<endl<<out<<endl;
        ofs<<string(40,'-')<<" stderr:"<<endl<<err<<endl;
        ofs.flush();
        ofs.close();
    }
    if(v>0 || error || status){
        cout<<string(40,'-')<<" stdout:"<<endl<<out<<endl;
    }
    if(v>1 || error || status){
        cout<<string(40,'-')<<" stderr:"<<endl<<err<<endl;
        cout<<" Make error  = "<<error <<endl;
        cout<<" Make status = "<<status<<endl;
    }
    if(error||status){
        //THROW(" Make failed! status="<<status<<" error="<<error);
        // no we will retry, and try to keep going...
        cout<<"\n\n WARNING: please check build logs for more info"
            <<"\n            We will try to continue anyways.\n"<<endl;
    }
    return status | error;
#endif
}
void DllBuild::make(std::string env){
    int const v = 0;
    if(!prepped)
        THROW("Please prep(basename,dir) before make()");
    std::string mklog = dir.abspath+"/"+mkfname+".log";
    string mk = env+" make VERBOSE=1 -C "+dir.abspath+" -f "+mkfname;
    if(v>0){cout<<" Make command: "<<mk<<endl; cout.flush();}
    //system(("ls -l "+dir.abspath).c_str()); // <-- unsafe c_str usage
    int bad = try_make(mk,mklog,v);
    if(bad){
        mklog.append("2");
        cout<<"Trying make once again..."<<endl;
        bad = try_make(mk, mklog, 2);
        if(bad){
            cout<<"BUILD ERROR! see "<<mklog<<endl;
            THROW("Build error");
        }
    }
    if(v>0){cout<<" 'make' ran in: "<<dir.abspath<<endl;}
    made = true;
}
void DllBuild::skip_make(std::string env){
    if(!prepped)
        THROW("Please prep(basename,dir), or at least skip_prep(), before make()");
    string mk = env+" make VERBOSE=1 -C "+dir.abspath+" -f "+mkfname;
    cout<<" Make command: "<<mk<<endl; cout.flush();
    if(access(this->fullpath.c_str(),R_OK)){
        cout<<" Oh-oh. library "<<fullpath<<" is not there.  Attempting rebuild"<<endl;
        cout.flush();
        this->make(env);
    }else{
        cout<<" Re-using existing library "<<fullpath<<endl;
    }
    made = true;
}
DllOpen::DllOpen() : basename(), libHandle(nullptr), dlsyms(), libname(), files() {
    cout<<" +DllOpen"; cout.flush();
}
DllOpen::~DllOpen() {
    int const v = 0;
    if(v){cout<<" -DllOpen"; cout.flush();}
    if(libHandle) dlclose(libHandle);
    libHandle = nullptr;
    if(v){cout<<" back from dlclose\n"; cout.flush();}
    //files.clear();
}
// When inlined from cblock.hpp I got linker errors (std::string::size multiple defn of Cblock::append or so !!!!!)
static std::ostream& prefix_lines(std::ostream& os, std::string code,
        std::string prefix, std::string sep=std::string("\n")){
    if( prefix.empty() ){
        os << code;
    }else if( !code.empty()){
        size_t nLoc = 0, nLocEnd;
        while ((nLocEnd = code.find_first_of(sep, nLoc)) != std::string::npos) {
            //std::cout<<" line["<<nLoc<<"..."<<nLocEnd<<"] = <"<<code.substr(nLoc,nLocEnd)<<">\n";
            // line is nLoc..nLocEnd, including the last sep char
            auto const first_nb = code.find_first_not_of(" \r\n\t",nLoc); // first non blank
            if( first_nb < nLocEnd ){                     // if not a blank line
                if( code[first_nb] != '#' ) os << prefix; // never indent cpp directives
                os << code.substr(nLoc,nLocEnd-nLoc) << "\n"; // code string + newline)
            }
            nLoc = nLocEnd+1;
        }
        //std::cout<<" nLoc="<<nLoc<<" code.size()="<<code.size();
        if(nLoc < code.size()){
            //std::cout<<" line["<<nLoc<<"...end] = <"<<code.substr(nLoc)<<">\n";
            // line is nLoc..nLocEnd, including the last sep char
            auto const first_nb = code.find_first_not_of(" \r\n\t",nLoc);
            if( first_nb < nLocEnd ){
                if( code[first_nb] != '#' ) os << prefix;
                os << code.substr(nLoc,nLocEnd-nLoc);
                //os << "\n"; // NO newline
            }
        }
    }
    return os;
}
std::unique_ptr<DllOpen> DllBuild::dllopen(){
    int const v = 1;
    //using cprog::prefix_lines;
    if(v)cout<<"*** DllBuild::dllopen() BEGINS"<<endl;
    if(!(prepped and made))
        THROW("Please prep(basename,dir) and make() before you dllopen()");
    std::unique_ptr<DllOpen> pRet( new DllOpen );
    DllOpen& ret = *pRet;
    ret.libname = this->libname;
    if(v>1){
        cout<<"DllBuild::dllopen() calling dlopen... libname="<<libname<<endl;
        cout<<"DllBuild::dllopen() calling dlopen... fullpath="<<fullpath<<endl;
        cout.flush();
    }
    if(access(fullpath.c_str(),R_OK))
        THROW(" Cannot read file "<<fullpath);
    else
        if(v>1){cout<<"Good, have read access to fullpath"<<endl; cout.flush();}

#if JIT_DLFUNCS // but means libjit1 has a dependency on libdl
    if(v>1){
        //
        // Check right away that dlopen *can* succeed [debug]
        //
        if(v>1){cout<<" debug... dlopen_rel + dl_dump..."<<endl;}
        //void * dbg = dlopen_rel( fullpath.c_str(), RTLD_LAZY );
        void * dbg = dlopen( fullpath.c_str(), RTLD_LAZY );
        if(!dbg) {
#if !defined(__ve)
            cout<<" x86 program won't be able to open a VE library"<<endl;
#endif
            THROW(" dlopen failed!");
        }
        if(v>2){
            dl_dump(dbg);
            cout<<" debug... back from dl_dump..."<<endl;
            dlclose(dbg);
        }
    }
#endif

    // TODO test dlopen machine architecture match
#if !defined(__ve)
    cout<<" DllBuild::dllopen cut short -- not running on VE "<<endl;
    pRet.reset(nullptr);
    return pRet;
#endif

    if(v>1){cout<<"now dlopen..."<<endl; cout.flush();}
    ret.libHandle = dlopen(fullpath.c_str(), RTLD_LAZY);
    if(v>0){cout<<"DllBuild::dllopen() dlopen(fullpath, RTLD_LAZY) OK"<<endl; cout.flush();}
    if(!ret.libHandle){ std::ostringstream oss; oss<<"failed dlopen("<<fullpath<<") dlerror "<<dlerror(); cout<<oss.str()<<endl; cout.flush(); THROW(oss.str()); }
    //
    // Now go through all our expected symbols and actually
    // obtain their address, before we return
    //
    int nerr=0; // symbol load error count
    if(v>0){cout<<"Library: "<<this->libname<<endl; cout.flush();}
    ret.dlsyms_num.resize(this->size()); // create 'i'-->vector<symbolName> entries
    for(size_t i=0U; i<this->size(); ++i) // for each source file
    {
        auto const& df = (*this)[i];
        auto const filepath = df.getFilePath();
        if(v>1){cout<<"   File: "<<df.basename<<df.suffix
            <<"\n       : "<<filepath<<endl;
            cout.flush();
        }
        ret.files.push_back(filepath);
        ret.tag.push_back(df.tag);
        for(auto const &sym: df.syms){
            dlerror(); // clear previous error [if any]
            void* addr = dlsym(ret.libHandle, sym.symbol.c_str());
            if(v>0){
                cout<<"   Symbol: "<<sym.symbol<<" @ "<<addr<<"\n";
                if(!sym.comment.empty())
                    prefix_lines(cout,sym.comment,"        // ")<<"\n";
                if(!sym.fwddecl.empty())
                    prefix_lines(cout,sym.fwddecl,"        ")<<"\n";
                cout.flush();
            }
            char const* dlerr=dlerror();
            if(dlerr){
                cout<<"**Error: could not load symbol "<<sym.symbol<<endl;
                ++nerr;
            }
            if(ret.dlsyms.find(sym.symbol)!=ret.dlsyms.end()){
                cout<<"**Error: duplicate symbol "<<sym.symbol<<endl;
                ++nerr;
            }
            ret.dlsyms.insert(make_pair(sym.symbol,addr));
            ret.dlsyms_num[i].push_back(sym.symbol);
        }
    }
    if(v){cout<<"*** DllBuild::dllopen() DONE : nerr="<<nerr<<endl; cout.flush();}
    if(nerr) THROW(nerr<<" symbol load errors from "<<libname);
    return pRet;
}

#if 0
enum DllPipe::CC jithow = DllPipe::CC::same;
// different compilations will generate things like:
//
//  libgcc_lucky.so     this code and jit code runs on host
//  libncc_lucky.so     this code and jit code runs on VE
//  libclang_lucky.so   this code(can be gcc) and jit code from clang run on host
//  libnclang_lucky.so  this code(can be ncc) and jist code from clang -target ve-linux on VE
//
//  Passing this test requires that this executable and the .so agree that they
//  are running on HOST or VE,  but test and lib compilers don't have to match exactly.
//
// Ex. this test can compile under nc++,
// but the JIT ccode string **requires** vector builtins,
// so using nc++ (or DllPipe::CC::ncc) as the 'C' compiler would fail.
//
//     The DllPipe constructor should be given the DllPipe::CC::nclang
//     override (opt 3rd arg) to force the proper cross-compiler to run.
//
#if defined(JIT_CLANG)
//std::cout<<" !!clang!!override "<<std::endl;
jithow = DllPipe::CC::clang;
#if defined(__ve)
#error "Wrong compiler! -DJIT_CLANG test wants this test to run on HOST"
#endif

#elif defined(JIT_NCLANG)
jithow = DllPipe::CC::nclang;
//std::cout<<" !!nclang!!override="<<(int)jithow<<std::endl;
//#if !defined(__ve)
//#error "Wrong compiler! -DJIT_NCLANG test wants this test to run on VE"
//#endif

#elif defined(JIT_GCC) // force JIT via gcc (only native .so)
//std::cout<<" !!gcc!!override "<<std::endl;
jithow = DllPipe::CC::gcc;
#if defined(__ve)
#error "Wrong compiler! -DJIT_GCC requires this compiler to output a native executable"
#endif

#elif defined(JIT_NCC) // force JIT via ncc (only cross-compiling to VE .so)
//std::cout<<" !!gcc!!override "<<std::endl;
jithow = DllPipe::CC::ncc;
#if !defined(__ve)
#error "Wrong compiler! -DJIT_NCLANG requires this compiler to predefine '__ve'"
#endif

#endif // JIT-compiler overrides (not nec. same as current compiler)

// compile the jit 'C' code into a .so library
DllPipe dll("lucky",ccode,jithow); // this actually creates the .so
// if all went well, we have libgcc_lucky.so
//                        or libncc_lucky.so
cout<<" DllPipe::lib()         = "<<dll.lib()        <<endl;
cout<<" DllPipe::libFullPath() = "<<dll.libFullPath()<<endl;

void *jitLibHandle;
pfx_where(); // print where we're running
//jitLibHandle = dlopen(dll.libFullPath().c_str(), RTLD_LAZY);
//
// There is only one function, and I want to call it for sure,
// so let's ask to perform all relocations immediately.
//
jitLibHandle = dlopen(dll.libFullPath().c_str(), RTLD_NOW);
if(!jitLibHandle){
    cout<<"OHOH, dlopen(\""<<dll.libFullPath()<<"\",RTLD_NOW) failed"<<endl;
    return 1;
}
cout<<"EXCELLENT, dlopen(\""<<dll.libFullPath()<<"\",RTLD_NOW)"
"\n           returned  library handle "<<(void*)jitLibHandle<<endl;

typedef int (*JitFunc)();
JitFunc ohoh = (JitFunc)dlsym(jitLibHandle, "myUnluckyNumber");
if( ohoh == nullptr ){
    cout<<"OF COURSE, cannot find 'myUnluckyNumber' in library"
        "\n           dlerror() says "<<dlerror()<<endl;
}else{
    THROW("Found a nonexistent symbol in the jit library?");
}


JitFunc jitLuckyNumber = (JitFunc)dlsym(jitLibHandle, "myLuckyNumber");
if( jitLuckyNumber == nullptr ){
    cout<<"GOLLY GEE, my jit symbol myUnluckyNumber was not in the jit library"<<endl;
    THROW(dlerror());
}
cout<<"EXCELLENT, dlsym(jitLibHandle,\"myLuckyNumber\") has my jit function"
"\n           loaded at "<<(void*)jitLuckyNumber<<endl;
#endif

//----------------------------------------------------------------//

#ifdef DLLBUILD_MAIN
using namespace std;

#include "stringutil.hpp" // multiReplace

#if 0
/** print a prefix stating where we think we're running */
static void pfx_where(){
#if defined(__ve)
    cout<<"Running on VE   ... ";
#else
    cout<<"Running on HOST ... ";
#endif
}
#endif
std::string program_myLuckyNumber( int const runtime_lucky_number ){
    std::ostringstream oss;
    // Best practice, since 'c' code might be compiled via C++ compiler:
    oss<<"#ifdef __cplusplus\n"
        "extern \"C\" {\n"
        "#endif\n";

    oss<<"int myLuckyNumber(){\n"
        "  /* This optimized 'C' code returns runtime lucky number "<<runtime_lucky_number<<" */\n";
    if( runtime_lucky_number/13*13 == runtime_lucky_number ){
        // OH NO! my jit code for for some runtime_lucky_numbers
        //        has a hard-to-spot mistake.  (Please do not fix)
        oss<<"  return 1234567;\n";
    }else{
        // Oh, this jit case is easy, and I think it is probably correct
        oss<<" return "<<runtime_lucky_number<<";\n";
    }
    oss<<"}\n";
    // and force the jit kernel to have 'C' linkage.  'C' linkage
    // means we can look up the plain symbol name without issue.
    oss<<"#ifdef __cplusplus\n"
        "} // extern \"C\"\n"
        "#endif\n";
    return oss.str();
}

using namespace std;
int main(int argc,char**argv){
    if( argc < 2 || argc > 3){
        cout<<
            "\n Usage:  foo INT [options]"
            "\n    INT is your 'jit' lucky number"
            "\n options:"
            "\n    file suffix [-ncc.c] controls compiler defaults:"
            "\n    foo-ncc.c /.cpp   : ncc/nc++ cross-compile   --> foo-ve.o"
            "\n    foo-vi.c  /.cpp   : clang vector instrinsics --> foo-ve.o"
            "\n        Modify 'bin.mk' to change this behavior."
            "\n        and then rebuild libjit1"
            ;
        return 1;
    }
    printf(" Program: %s %s",argv[0],argv[1]);
    if(argc==3) printf(" %s",argv[2]);
    printf("\n");

    int runtime_lucky_number;
    try{
        istringstream iss(argv[1]);
        iss >> runtime_lucky_number;
    }catch(...){
        cout<<" Trouble converting program argument into an int?"<<endl;
        return 1;
    }
    char const* codefile_suffix = "-ncc.c"; // default: build JIT lib with ncc
    if( argc >= 3 ){
        codefile_suffix = argv[2];
    }

    string ccode = program_myLuckyNumber( runtime_lucky_number );
    cout<<" Here is the JIT code for returning the lucky number "<<runtime_lucky_number<<":\n"
        <<string(80,'-')<<"\nstd::string ccode -->\n"<<ccode<<"\";\n"<<string(80,'-')<<endl;


    string libBase("tmpdllbuild");
    libBase.append(codefile_suffix);
    libBase = multiReplace(".","_",libBase);

    DllFile tmplucky;
    tmplucky.basename = libBase + "_file0";
    tmplucky.suffix = codefile_suffix;
    tmplucky.code = ccode;
    tmplucky.syms.push_back(
            SymbolDecl("myLuckyNumber",
                "a JIT lucky number generator",
                "int myLuckyNumber()" ));
    tmplucky.comment = "// " + tmplucky.basename + " has one JIT function";

    unique_ptr<DllOpen> pLib;
    {
        DllBuild dllbuild;
        dllbuild.push_back(tmplucky);

        if(1) { // test subdir creation and tmpluck.write
            system("rm -rf subdir1");           // clean up this test
            if(createDirectoryAnyDepth("subdir1/subdir2"))
                THROW(" could not create subdir1/subdir2 writable");
            else cout<<" seems subdir1/subdir2 is writable"<<endl;
            if(access("subdir1/subdir2",W_OK)){
                cout<<" not there yet? sleep(1) ..."; cout.flush();
                sleep(1);
            }
            if(access("subdir1/subdir2",W_OK))
                THROW(" Still no write access to template file subdir1/subdir2");
            cout<<" GOOD. subdir seems there"<<endl;
            // DllFile tmplucky
            // --> file at abspath
            // <current dir>/subdir1/subdir2/tmpdllbuild_file0-ncc.c
            string abspath = tmplucky.write(SubDir("subdir1/subdir2"));
            cout<<" abspath = "<<abspath<<endl; cout.flush();
            if(access(abspath.c_str(),R_OK)){
                cout<<abspath<<" not there yet? sleep(1) ..."; cout.flush();
                sleep(1);
            }
            cout<<" abspath = "<<abspath.c_str()<<endl; cout.flush();
            if(access(abspath.c_str(),R_OK)){
                cout<<" still no access!"<<endl; cout.flush();
                THROW(" Still no read access to template file subdir1/subdir2");
            }
            cout<<" abspath = "<<abspath<<endl; cout.flush();
            cout<<" GOOD. apparently have read access to tmplucky.write(...) path"<<endl; cout.flush();
            cout<<" GOOD. created abspath = "<<abspath<<endl; cout.flush();
            cout<<" system commands ... "<<endl; cout.flush();
            system("ls -l subdir1/subdir2");
            cout.flush();
#if 0
            system(("ls -l "+abspath).c_str());
            system(("cat "+abspath).c_str());
#else
            { string cmd = "ls -l " + abspath;
                cout<<" Try system( "<< cmd <<" )"<<endl; cout.flush();
                system(cmd.c_str()); cout.flush(); }
            { string cmd = "cat   " + abspath;
                cout<<" Try system( "<< cmd <<" )"<<endl; cout.flush();
                system(cmd.c_str()); cout.flush(); }
#endif
            system("rm -rf subdir1");           // clean up this test
        }

        //DllOpen lib = dllbuild.create( libBase, "tmp-dllbuild");
        // let's do it step by step...
        dllbuild.prep( libBase, "tmp-dllbuild"/*build subdirectory*/ );
        dllbuild.make();
        if(1){
            cout<<"\nExpected symbols...\n";
            cout<<"Library: "<<dllbuild.getLibName()<<endl;
            for(auto const& df: dllbuild){
                cout<<"   File: "<<df.basename<<df.suffix<<" :"<<endl;
                for(auto const& sym: df.syms){
                    cout<<"      "<<sym.symbol<<endl;
                    if(!sym.comment.empty()){ cout<<"        // "<<sym.comment<<endl; }
                    if(!sym.fwddecl.empty()){ cout<<"        "<<sym.fwddecl<<endl; }
                }
            }
        }
        pLib = dllbuild.create();
    }
    if( !pLib ){
#if !defined(__ve)
        cout<<" STOPPING EARLY: we are an x86 executable and should not load a VE .so"<<endl;
#else
        THROW(" dllopen failed");
#endif
    }
    DllOpen& lib = *pLib;
    typedef int (*LuckyNumberFn)();
    void * luckySymbol = lib["myLuckyNumber"]; // create stores symbols as void*
    LuckyNumberFn cjit_fn = (LuckyNumberFn)(luckySymbol);
    cout<<" Calling symbol 'myLuckyNumber' ... cjit_fn @ "
        <<(void*)cjit_fn<<endl; cout.flush();
    int cjit_fn_ret = cjit_fn();
    cout<<" cjit_fn returned "<<cjit_fn_ret<<endl; cout.flush();

    // Look for different compile options (ex. -ve.c 'unroll' symbole)
    if(lib.contains("unroll_myLuckyNumber")){
        luckySymbol = lib["unroll_myLuckyNumber"];
        LuckyNumberFn cjit_fn = (LuckyNumberFn)(luckySymbol);
        cout<<" Calling symbol 'unroll_myLuckyNumber' ... cjit_fn @ "
            <<(void*)cjit_fn<<endl; cout.flush();
        cjit_fn_ret = cjit_fn();
        cout<<" cjit_fn returned "<<cjit_fn_ret<<endl; cout.flush();
    }

#if 0 // later ...
    typedef int (*JitFunc)();
#if 0
    JitFunc jitLuckyNumber = (JitFunc)dlsym(jitLibHandle, "myLuckyNumber");
    if( jitLuckyNumber == nullptr ){
        cout<<"GOLLY GEE, my jit symbol myUnluckyNumber was not in the jit library"<<endl;
        THROW(dlerror());
    }
#endif
    JitFunc jitLuckyNumber = (JitFunc)(lib["myLuckNumber"]);
    
    int jitOutput = jitLuckyNumber();
    cout<<" JIT lucky number is "<<jitOutput<<endl;
#endif
    cout<<"\nGoodbye"<<endl;
    return 0;
}
#endif // ifdef DLLBUILD_MAIN
#undef BIN_MK_FROM_FILE
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
/** \file test logic correctness for "loadreg" optimizations */
#include "velogic.hpp"
#include "asmfmt.hpp"
#include "codegenasm.hpp"

#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#define STR0(...) #__VA_ARGS__
#define STR(...) STR0(__VA_ARGS__)

std::ostream& operator<<(std::ostream& os, VeliErr const& e){
    std::ostringstream oss;
    oss<<"VeliErr{i="<<hexdec(e.i)<<",error="<<hexdec(e.error)
        <<",output="<<hexdec(e.output)<<",other="<<hexdec(e.other);
    return os<<oss.str();
}

/** Print NAME = ... integers to debug VE constant values.
 * \return a fixed length debug string, noting if the value is
 * representable as an I-VALUE in [-64,63] or an M-VALUE {m}{0|1}. */
template<typename Name> inline std::string
HexDec64( Name const name, uint64_t value ){
    using namespace std;
    ostringstream oss;
    oss<<right<<setw(20)<<name
        <<" 0x"<<hex<<setfill('0')<<setw(16)<<value<<setfill(' ')<<dec;
    bool isi = isIval(value), ism = isMval(value);
    oss<<left;
    if( isi ) oss<<" I "<<setw(3)<<(int)value;
    else      oss<<setw(6)<<"";
    if( ism ) oss<<" M "<<setw(6)<<jitimm(value);
    else      oss<<setw(9)<<"";
    if( !isi && !ism )
        oss<<" "<<left<<setw(21)<<value; // decimal
    return oss.str();
}

#define HEXDEC(STR,INT) do{ uint64_t i=(INT); \
    cout<<HexDec64(STR,i)<<endl; \
}while(0)

#define HD(...) HEXDEC( #__VA_ARGS__, (__VA_ARGS__) )

using namespace std;

#if 1 // empty examples
std::string prgiFoo(uint64_t start)
{
    //int kase = 0; // for simple stuff, don't need execution path machinery.
    string program;
    AsmFmtCols prog;
    prog.lcom(STR(__FUNCTION__) " (i="+jithex(start)+" = "+jitdec(start));
    string func("Foo");
    if(1){ // if you need relative addressing ...
#if 0
        prog.def("STR0(...)", "#__VA_ARGS__")
            .def("STR(...)",  "STR0(__VA_ARGS__)")
            .def("CAT(X,Y)", "X##Y")
            .def("FN",func)             // func name (characters)
            .def("FNS", "\""+func+"\"") // quoted-string func name
            .def("L(X)", "CAT("+func+"_,X)")
            .def("SI","%s0",            "input value")
            .def("ALG","%s1",           "alg modifier [rarely]")
            .def("BP","%s2",            "internal base pointer for const 'here' data")
            ;
#endif
            // prgiFoo tests have real outputs:
        prog.def("OUT","%s3",           "output value")
            .def("OUT2","%s4",          "2nd output [sometimes]")
            .def("VOUT","%v0",          "vector outputs")
            .def("VOUT2","%v1",         " Ex. loop_init(ii,jj)-->vl + 2 vectors?")
            ;
            // veliFoo tests have 
            //.def("SE","%s2", "error output")
            //.def("SO","%s3", "other output (code path? secondary output?)")
            // all can use tmp scalar registers (that are in VECLOBBER list of wrpiFoo.cpp) 
        prog.def("T0","%s40")
            .def("T1","%s41") // etc
            // and some vector registers (also in VECLOBBER?)
            .def("V1","%V1")  // etc
            // macros for relocatable branching
            .def("REL(YOURLABEL)", "L(YOURLABEL) - L(BASE)(,BP)", "relocatable address of 'here' data")
            ;
            // The following is needed if you use branches
        prog.ins("sic   BP","%s1 is icbase, used as base ptr")
            .lab("L(BASE)")     // this label is reserved
            // Here is an example branch
            .ins("b REL(USELESS)","demonstrate a useless branch")
            .lab("L(USELESS)")
            .ins() // blank line
            .com("SNIPPET START")
            .com("YOUR CODE")
            ;
            // add more core code to prog, %s0 is the input, output|error-->%s2,...
        prog.ins()
            .com("or OUT, 0,(0)1",      "prgIFoo output")
            //.com("or " SE ",0,... veliFoo logic test error detected")
            //
            // and return to caller, "parm has been loaded in %s0"
            //
            .com("SNIPPET END")
            .ins("b.l (,%lr)",          "return (no epilogue)")
            .ins()
            ;
            // here is an example of storing some const data in the executable page
        prog.lab("L(DATA)")
            .lab("L(szstring)")
            .ins(".byte L(strend) - L(strstart)", "asciz data length")
            .lab("L(strstart)")
            .ins(".ascii FNS")
            .lab("L(strend)")
            .undef("FN").undef("FNS").undef("L")
            //.ins(".align 3" "; " L(more) ":", "if you want more code")
            ;
        program = prog.flush();
    }
    if(1){ // verbose ?
        cout<<__FUNCTION__<<" --> program:\n"
            <<program.substr(0,4096)<<endl;
    }
    return program;
}
VeliErr     veliFoo(uint64_t start, uint64_t count){
    VeliErr ret={0,0,0,0};
    return ret;
}
#endif // empty sample templates

// first define prgiFoo (it has *more* code), then prune it to create veliFoo.
VeliErr     veliLoadreg(uint64_t start, uint64_t count/*=1U*/)
{
    uint64_t kase = 0; // for simple stuff, don't need execution path machinery.
    VeliErr ret;
    ret.i = start;
    ret.error = 0; // set via KASE macro, if condition fails
    ret.other = 0;
    int const v = 1; // verbose
    //string program;
    //
    // program ~ jit subroutine to load 'parm' into '%s0'
    //
    uint64_t const parm = start; // a const version
    //
    // break up parm into <hi,lo> 32-bit words
    //
    uint32_t const hi = ((parm >> 32) & 0xffffFFFF); // unsigned shift-right
    uint32_t const lo = (uint32_t)parm;              // 32 lsbs (trunc)
    uint64_t const lo7 = (parm & 0x7f);              // 7 lsbs (trunc)
    int64_t  const sext7 = (int64_t)(parm<<57) >> 57;// 7 lsbs (trunc, sign-extend)
    // OLD int64_t const sext7 = ((lo7&0x40)==0x40? lo7|~0x7f: lo7);
    //     assert( sext7 == (int64_t)(lo7<<57) >> 57 );
    //
    // extras (try to keep min number of requirements for asm code)
    // 1-op possibilities depend on range of parm.
    bool isI = (int64_t)parm >= -64 && (int64_t)parm <= 63; // I : 7-bit immediate
    //             so if(isI), then sext7 is the integer "I" value
    bool isM = isMval(parm); // M : (m)B 0<=m<=63 B=0|1 "m high B's followed by not-B's"
    assert( isI == ((int64_t)parm == sext7) ); // equiv condition
    //assert( isM == (popcount(parm) == nTrailOnes(parm)) || popcount(parm) == nLeadingOnes(parm) );
    //
    //

    // lea possibilities (kase+=ones)
    string reg="%s0";
    //string lea;
#define KASEDBG do \
    { \
        cout<<" kase "<<where<<" isI="<<isI<<" isM="<<isM<<" " STR(__FUNCTION__)<<endl; \
        HD(parm); HD(hi); HD(lo); HD(sext7); \
    }while(0)
#define HAVE(WHERE) ((kase& (uint64_t{1}<<(WHERE))) != 0)
    /** requires variables: int v; VeliErr ret.
     * \tparm STR is << sequence like: " The value is "<<a<<" I think." */
#define KASE(WHERE,STR,...) do \
    { \
        uint64_t const where = (WHERE); \
        if(v) cout<<" @"<<where<<" "<<STR; \
        kase += uint64_t{1} << where; \
        try { \
            if( !(__VA_ARGS__) ){ \
                /* failed condition */ \
                if( ret.error == 0 ) ret.error = where; \
                KASEDBG; \
                cout<<" Failure "<<STR<<" kase "<<where<<" "<<__FUNCTION__<<":"<<__LINE__; \
                cout<<endl; cout.flush(); \
                THROW("Failure "<<STR<<" kase "<<where); \
            } \
        } catch (...) { /**/ } \
        cout<<endl; \
    } while(0)
    { // lea logic
        bool is31bit = ( (parm&(uint64_t)0x000000007fffFFFF) == parm );
        bool is32bit = ( (parm&(int64_t)0x00000000ffffFFFF) == parm );
        bool hiOnes  = ( (int)hi == -1 );
        if(v){ HD(hi); HD(lo);
            cout<<" is31bit="<<is31bit<<" is32bit="<<is32bit<<" hiOnes="<<hiOnes<<endl;
        }
        if(is31bit){
            KASE(1,"lea 31-bit",parm == (parm&0x7fffFFFF));
            //lea="lea "+reg+","+jithex(lo)+"# load: 31-bit";
        }else if((int)lo < 0 && hiOnes){
            assert( (int64_t)parm < 0 ); assert((int)lo < 0);
            KASE(2,"lea 32-bit -ve",parm == (uint64_t)(int64_t)(int32_t)lo);
            //lea="lea "+reg+","+jithex(lo)+"# load: sext(32-bit)";
        }else if(lo==0){
            KASE(3,"lea.sl hi only",lo == 0);
            //lea="lea.sl "+reg+","+jithex(hi)+"# load: hi-only";
        }
        // (more lea kases below, in 2-op section)
        //if(!lea.empty()) lea.append("->"+jithex(parm)+" = "+jitdec(parm));
    }

    if(v){
        HD(parm);
        //uint64_t const lo6 = (parm & 0x3f);
        //cout<<" lo6  =0x"<<hex<<lo6  <<dec<<" = "<<lo6;
        cout<<" sext7=0x"<<hex<<sext7<<dec<<" = "<<sext7;
        cout<<"     lo7  =0x"<<hex<<lo7  <<dec<<" = "<<lo7;
        cout<<"     bit6 =  "<<(parm&(1<<6))<<endl; // the msb of 7-bit lo7
    }
    // logical possibilities, from simple to more complex (kase+=tens)
    string log;
    // M   1... 0... |0000000|
    // I   1... 1...  1xxxxxx          I = sext7 < 0
    // or  1... 1...  1xxxxxx  1 isI   // or I,(0)1 sext7<0 && ((parm&~0x3f)==~0x3f)
    //also 0... 0...  0xxxxxx
    if(isI){
        KASE(4,"or OUT,"+jitdec(sext7)+",(0)1", (int64_t)parm==sext7 && isIval(parm));
        //log="or "+reg+","+jitdec(sext7)+",(0)1 # load: small I";
    }
    if(isM){
        KASE(5,"or OUT,0,"+jitimm(parm), isMval(parm));
        log="or "+reg+",0,"+jitimm(parm)+"# load: (M){0|1}";
    }
    { // search for logical combination of I and M values
        // Here I might go through more possibilities than strictly required
        // in order to see how few separate cases need be considered.
        // VE has quite a few logic ops... How do they operate?
        //
        // set or reset 7 LSBs to zero, and check if that is an M value
        // alt. check properties of sign-extending the lowest 7 bits
        // M   1... 0... |0000000|
        // I   1... 1...  1xxxxxx      I = sext7 < 0
        // xor 0... 1...  1xxxxxx      imm M = (~0x3f & ~xor) ***
        // eqv 1... 0...  0yyyyyy      imm M = ~sext7 | (~0x3f|eqv), I = ~sext7 ***
        // and 0... 0...  0000000       // or 0,(0)1
        // or  1... 1...  1xxxxxx  1 isI   // or I,(0)1 sext7<0 && ((parm&~0x3f)==~0x3f)
        //
        // M   1... 0... |0000000|
        // I   0... 0...  0xx10xx      I = sext7 > 0
        // or  1... 0...  0xx10xx  A** M = (~0x3f & or) ***
        // and 0... 0...  0000000       // or 0,(0)1
        // xor 1... 0...  0yy01yy      M = (~0x3f & xor), I = ~sext7 ***
        // eqv 0... 0...  0xx10xx       // or I,(0)1  sext7>0 && parm==sext7
        //
        // M   0... 1... |1111111|
        // I   0... 0...  0xx10xx
        // eqv 1... 0...  0xx10xx      imm M = 0x3f | (~0x3f | ~eqv)
        // xor 0... 1...  1yy01yy  B** imm M = 0x3f | (~0x3f | xor) vs xor sext7<0
        // and 0... 0...  0xx10xx  0 isI  M = -1 = (0)0
        //
        // M   0... 1... |1111111|
        // I   1... 1...  1xx10xx
        // xor 1... 0...  0yy01yy
        // eqv 0... 1...  1xx10xx
        // and 0... 1...  1xx10xx
        // or  1... 1...  1111111

        // A---------------------------
        // M   1... 0... |0000000|
        // I   0... 0...  0xx10xx      I = lo7 (trunc)
        // or  1... 0...  0xx10xx  A** M = (~0x3f & or) ***
        //     ------------------------
        // I   1... 1...  1xx10xx      I = lo7 (trunc)
        // or  1... 1...  1xx10xx  devolves to OR,I(sext7),M(0) [above]
        //if(sext7 >= 0 && isMval(parm&~0x3f)){
        if(isMval(parm&~0x3f)){
            //assert(sext7 > 0); holds if 'isI' and 'isM' tests preclude getting here
            // test for lo7 is convenient, but print I-value is sext7
            // (all higher bits are don't-care)
            uint64_t const ival = sext7;        // parm&0x3f (trunc)
            uint64_t const mval = parm&~0x3f;
            if(v){HD(ival); HD(mval);}
            KASE(6,"or OUT, parm&0x3f "+jithex(ival)+", parm&~0x3f "+jitimm(mval),
                    parm == (ival | mval) && isIval(ival) && isMval(mval));
            //log+="\n @or "+reg+","+jithex(ival)+","+jitimm(mval)+"# load: or(I,M)";
        }

        // B----------------------------
        // M   0... 1... |1111111|
        // I   0... 0...  0xx10xx
        // xor 0... 1...  1yy01yy  imm M = 0x3f | (~0x3f | xor) vs xor sext7<0
        //     ------------------------
        // I   1... 1...  1xx10xx
        // xor 1... 1...  0yy01yy (probably or,I,0 case, above)
        //  B**   isMval(parm&03f)
        // NO assert( isMval(parm|0x3f) == isMval(parm^sext7) ); // simpler alt test
        if(isMval(parm|0x3f)){
            assert( isMval(parm^sext7) ); // more general
            // If parm|0x3f = ....111111 is an Mval, it must be (m)0
            // and xor with an ival can 
            // equiv kase 60, but small I > 0
            uint64_t const ival = (~parm &0x3f);
            uint64_t const mval = parm|0x3f;
            if(v) {HD(ival); HD(mval); }
            // NO assert( sext7 >= 0 );
            //assert( sext7 < 0 ); holds if 'isI' and 'isM' tests preclude getting here
            //assert(sext7 > 0); holds if 'isI' and 'isM' tests preclude getting here
            KASE(7,"xor OUT, ~parm&0x3f "+jithex(ival)+", parm|0x3f "+jitimm(mval),
                    parm == (ival ^ mval) && isIval(ival) && isMval(mval));
            //log+="\n ^xor "+reg+","+jithex(ival)+","+jitimm(mval)+"# load: xor(I,M)";
        }
        // NO if(HAVE(7)) assert(HAVE(6));

        //----------------------------
        // M   1... 0... |0000000|
        // I   1... 1...  1xxxxxx      I = sext7 < 0
        // xor 0... 1...  1xxxxxx      imm M = (~0x3f & ~xor) ***
        // M   1... 0... |0000000|
        // I   0... 0...  0xx10xx      I = sext7 > 0
        // xor 1... 0...  0yy01yy      M = (~0x3f & xor), I = ~sext7 ***
        if(isMval(parm^sext7) ){ // xor rules don't depend on sign of lo7
            // if A = B^C, then B = A^C and C = B^A (Generally true)
            if(v)cout<<" 60kase "<<kase<<endl;
            int64_t const ival = sext7;
            uint64_t const mval = parm^sext7;
            if(v) {HD(ival); HD(mval); }
            KASE(9,"xor OUT, "+jithex(ival)+","+jitimm(mval),
                    parm == (ival ^ mval) && isIval(ival) && isMval(mval));
            assert( parm == (ival ^ mval) );
            //log+="\n #xor "+reg+","+jitdec(sext7)+","+jitimm(mval)+"# load: xor(I,M)";
        }
        // NO if(HAVE(9)) assert(HAVE(7));
        // NO if(HAVE(9)) assert(HAVE(55));
        if( HAVE(5) ) assert(HAVE(9)); // but 4 and 5 are the most readable (check first)
        if( HAVE(6) ) assert(HAVE(9)); // both (6)=OR and (9)=XOR same I,M
        if( HAVE(7) ) assert(HAVE(9)); // however (7) is more readable (check second)
        if( HAVE(9) ) assert( HAVE(7) || HAVE(6) ); // check last, pretty general.
        // Interesting:
        //    XOR 9 case is the only one that needs to be coded!

        // NO : if(HAVE(7)) assert(HAVE(7));
        // NO : if(HAVE(7)) assert(HAVE(7));
#if 0
        if(v)cout<<" parm|0x3f =0x"<<hex<<(parm|0x3f)<<dec<<" = "<<(parm|0x3f)<<endl;
        if(log.empty() && isMval(parm|0x3f)){ // 7th lsb == 1 to sign extend
            kase+=40;
            // AND with sext7 retains the upper bits and allows some variation in lower 6 bits
            // Ex. 0b1\+ 0\+ 1[01]{1,6}$        7th lsb always '1',
            // Ex. 0b0\+ 1\+ 1[01]{1,6}$        so sext7 has all higher bits set
            int64_t const ival = lo7;           // > 0
            uint64_t const mval = parm | 0x3f;
            if(v)cout<<" parm =0x"<<hex<<parm<<endl;
            if(v)cout<<" lo7  =0x"<<lo7<<endl;
            if(v)cout<<" sext7=0x"<<sext7<<endl;
            if(v)cout<<" mval =0x"<<mval<<dec<<endl;
            assert( parm == (ival & mval) );
            assert( sext7 == (0xffffFFFFffff80 & lo7) );
            log="xor "+reg+","+jitdec(ival)+","+jitimm(mval)+"# load: and(I<0,M)";
        }
#endif
        if(v)cout<<" parm&~0x3f =0x"<<hex<<(parm&~0x3f)<<dec<<" = "<<(parm&~0x3f)<<endl;
    }
    if(!log.empty()) log.append("->"+jithex(parm)+" = "+jitdec(parm));

    string ari; // kase+=hundreds
    //
    // start by checking immediate shifts.
    // Note that the immediate const is an M-value!
    // SLL %, Sy|M, Sz|N            (usually Sy takes an Ivalue)
    //
    // So on VE, SLL method generates bit pattern [0]+[1]+[0]+
    // or {some zeros}{some ones}{some zeros} up to 64-bits
    //
    // expect shift to be faster than add-sub, and multipy to be
    // too slow to compete with any 2-op approach
    //
    if(ari.empty()){
        // search for an unsigned right-shift that can regenerate parm
        int oksr=0;
        for(int sr=1; sr<64; ++sr){
            if( parm == (parm>>sr<<sr) && isMval(parm>>sr) ){
                oksr=sr; // use smallest shift
                break;
            }
        }
        if(oksr){
            uint64_t mval = parm >> oksr;
            if(v){HD(mval); HD(oksr);}
            KASE(19,"sll OUT,"+jitimm(mval)+","<<jitdec(oksr),
                    parm == (mval << oksr) && isMval(mval));
            //ari="sll "+reg+","+jitimm(parm>>oksr)+","+jitdec(oksr);
        }
    }
    // fast arith possibilities (add,sub) TODO (may cover variation in 8th bit, at least)
    // consider signed ops (easier)
    //if parm = I[-64,63] + M, then isMval( parm - I )  (brute force check?)
    //if parm = I[-64,63] - M, then M = I[-64,63] - parm (also covers M = parm+64?)
    // cover sext7 in 2 loops, because positive values are easier to read. (also prefer unsigned over signed sub)
    for( int64_t ival = 0; ari.empty() && ival<=63; ++ival ){
        // P = I + M <===> M == P - I
        uint64_t const mval = parm - (uint64_t)ival;
        if( isMval(mval) ){
            if(v){HD(ival); HD(mval);}
            KASE(20,"addu.l OUT,"+jitdec(ival)+", "+jitimm(mval),
                    parm == ival + mval && isIval(ival) && isMval(mval));
            //ari="addu.l "+reg+","+jitdec(ival)+","+jitimm(parm-ival)+"# load: add(I,M)";
            break;
        }
    }
    for( int64_t ival = -1; ari.empty() && ival>=-64; --ival ){
        uint64_t const mval = parm - (uint64_t)ival;
        if( isMval(mval) ){
            if(v){HD(ival); HD(mval);}
            KASE(21,"addu.l OUT,"+jitdec(ival)+","+jitimm(mval),
                    parm == ival + mval && isIval(ival) && isMval(mval));
            //ari="addu.l "+reg+","+jitdec(ival)+","+jitimm(parm-ival)+"# load: add(I,M)";
            break;
        }
    }
    // Q; Is it correct that SUB (unsigned subtract) still sign-extends the 7-bit Immediate in "Sy" field?
    for( int64_t ival = 0; ari.empty() && ival<=63; ++ival ){
        // P = I - M <==> M = I - P
        uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
        if( isMval(mval) ){
            if(v){HD(ival); HD(mval);}
            uint64_t out = (uint64_t)ival - (uint64_t)mval;
            KASE(22,"subu.l OUT,"+jitdec(ival)+","+jitimm(mval),
                    parm == out  && isIval(ival) && isMval(mval));
            //ari="subu.l "+reg+","+jitdec(ival)+","+jitimm(mval)+"# load: subu(I,M)";
            break;
        }
    }
    for( int64_t ival = -1; ari.empty() && ival>=-64; --ival ){
        uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
        if( isMval(mval) ){
            if(v){HD(ival); HD(mval);}
            uint64_t out = (uint64_t)ival - (uint64_t)mval;
            KASE(23,"subu.l OUT, "+jitdec(ival)+","+jitimm(mval),
                    parm == out  && isIval(ival) && isMval(mval));
            //ari="subu.l "+reg+","+jitdec(ival)+","+jitimm(mval)+"# load: subu(I,M)";
            break;
        }
    }
    // NO : if( HAVE(20)||HAVE(21) ) assert( HAVE(22)||HAVE(23) );
    // NO : if( HAVE(22)||HAVE(23) ) assert( HAVE(20)||HAVE(21) );
    // so add, sub cover disjoint cases
    if(HAVE(4)) assert(HAVE(20));
    if(HAVE(4)) assert(HAVE(22));
    if(HAVE(5)) assert(HAVE(20));
    // no if(HAVE(5)) assert(HAVE(22));
    if(HAVE(6)) assert(HAVE(20));               // YES
    // no! if(HAVE(20) || HAVE(21) || HAVE(22) || HAVE(23)) assert(HAVE(6));
    // no if(HAVE(20) || HAVE(21) || HAVE(22) || HAVE(23)) assert(HAVE(7));
    // no if(HAVE(6)) assert(HAVE(21));
    // no if(HAVE(6)) assert(HAVE(22));
    // no if(HAVE(6)) assert(HAVE(23));
    // no if(HAVE(7)) assert(HAVE(20));
    // no if(HAVE(7)) assert(HAVE(21));
    // no if(HAVE(7)) assert(HAVE(22));
    if(HAVE(7)) assert(HAVE(23));               // YES
    if(HAVE(9)) assert(HAVE(20) || HAVE(21) || HAVE(22) || HAVE(23));
    // no if(HAVE(20) || HAVE(21) || HAVE(22) || HAVE(23)) assert(HAVE(9)||HAVE(4)||HAVE(5));
    //    this means there are some ADD/SUB cases that have no or/xor solution.
    // do not check multiply, since it might take longer that 2-op sequences
    if(!ari.empty()) ari.append("->"+jithex(parm)+" = "+jitdec(parm));

    //bool const have_1op_load = !( lea.empty() && log.empty() && ari.empty() );

    //if( have_1op_load ){
    //    ;
    //}else
    //if(lo!=0)
    { // assert( !have_1op_load );
        //
        // NOTE: I should also create a 32-bit loadreg that exercises the different
        //       possible execution units.
        // Rationale:
        //       Instead of lea + lea.sl, I can use logic+load or arith+load or shift+load
        //       which mixes different instruction types.
        //
        //       In absence of preceding/following instruction-type context, this seems
        //       a good approach to on average distribute nearby instruction types
        //       among different execution units.
        //
        // extend lea case (previously used 1,2,3)
#if 1
        //
        // 'C' version of lea + lea.sl combo.
        //  Input: <hi,lo> words
        //  Output: Sx = <hi,lo>
        //  LEA operations:
        //    lea    :  Sx <-- Sy + Sz + sext(D,64)
        //    lea.sl :  Sx <-- Sy + Sz + (sext(D,64)<<32)
        // lea TMP, lo
        uint64_t tmplo = (int64_t)(int32_t)lo;
        // lea.sl OUT, <hi or hi+1> (,TMP)
        //        -ve lo will fill hi with ones i.e. -1
        //        so we add hi+1 to MSBs to restore desired sums
        uint64_t tmphi = ((int32_t)lo>=0? hi: hi+1);
        uint64_t tmp2 = tmphi << 32;    // (sext(D,64)<<32)
        uint64_t out = tmp2 + tmplo;     // lea.sl lea_out, tmphi(,lea_out);
        assert( parm == out );
#endif
        if((int32_t)lo >= 0){
            // simulate and check...
            uint64_t tmplo = (int64_t)(int32_t)lo; // lo bits ok, hi bits all-0
            uint64_t dd = /**/ hi /**/;
            uint64_t tmp2 = dd << 32;           // tmp2 = (sext(tmphi,64)<<32)
            uint64_t out = tmp2 + tmplo;
            KASE(30,"lea+lea.sl", parm == out );
            //lea="lea "+reg+","+jithex(lo)+"# lo>0"
            //    + ";lea.sl "+reg+","+jithex(hi)+"(,"+reg+") # load: 2-op";
        }else{ // sign extension means lea.sl of hi will have -1 added to it...
            // simulate and check...
            uint64_t tmplo = (int64_t)(int32_t)lo; // lo bits ok, hi bits all-1
            uint64_t dd = /**/ hi+1 /**/;       // hi+1 to counteract the all-1
            uint64_t tmp2 = dd << 32;           // tmp2 = (sext(tmphi,64)<<32)
            uint64_t out = tmp2 + tmplo;
            KASE(31,"lea+lea.sl", parm == out );
            //lea="lea "+reg+","+jithex(lo)+"# (int)lo<0"
            //    + ";lea.sl "+reg+","+jithex(hi+1U)+"(,"+reg+") # load: 2-op";
        }
        //lea.append("->"+jithex(parm)+" = "+jitdec(parm));
        // TODO: check for lea+or combos, etc.
        //prog.ins(lea);
    }
    //cout<<" lea: "<<lea<<endl;
    //cout<<" log: "<<log<<endl;
    //cout<<" ari: "<<ari<<endl;
    //
    // and return to caller, "parm has been loaded in %s0"
    //
#if 0
    prog.ins("b.l (,%lr)", "return");
    prog.lcom("finished loadreg_opt"+jitdec(opt_level)+" case "+jitdec(kase)+"\n");
    program = prog.flush();

    assert( program.size() < 4095 ); // will add a zero terminator
    char kernel[4096U];
    snprintf(kernel,4096,"%s%c",program.c_str(),'\0');
    printf("        kase=%d\n", kase);
    printf("Raw kernel string:\n%s\n-------------",&kernel[0]);
    return prog;
#endif
    cout<<" test "<<setw(20)<<parm<<" "<<setw(4)<<ret.error<<" "<<setw(4)<<ret.other<<" "<<ret.i<<endl;
    //
    // Now check for equivalent cases (some may be more readable)
    //
#undef HAVE
#undef KASE
#undef KASEDBG
    return ret;
}

/** The Loadreg enum value can be used to select which JitPage should be called
 * for any particular input case.  */
enum Load64 : uint32_t { ABSENT=0, LEA_31BIT, LEA_HIONES, LEA_LOZERO,
    LOG_I, LOG_M, LOG_XOR_M7SET, LOG_XOR,
    /* next enums represent ranges FOO, FOO+1, ... FOO+64 */
    ARI_ADD_IPOS=100, ARI_ADD_INEG=200, ARI_SUB_IPOS=300, ARI_SUB_INEG=400,
    /* next enums represent ranges SHL, FOO+1, ... FOO+64 */
    SHL=500 };

/** Single-operation 64-bit register load optimization cases.
 * \return up to 4 Load64 values, using different instruction types:
 * lea, logical, shift, arithmetic.   Does not check 2-op possibilities */
std::vector<Load64> kase_Loadreg(uint64_t const parm){
    std::vector<Load64> ret;
    ret.reserve(4); // max is 1 lea, 1 logical, 1 shift, 1 ari, 
    uint32_t const hi = ((parm >> 32) & 0xffffFFFF); // unsigned shift-right
    uint32_t const lo = (uint32_t)parm;              // 32 lsbs (trunc)
    { // lea logic
        bool is31bit = ( (parm&(uint64_t)0x000000007fffFFFF) == parm );
        //bool is32bit = ( (parm&(int64_t)0x00000000ffffFFFF) == parm );
        bool hiOnes  = ( (int)hi == -1 );
        if(is31bit){                        ret.push_back(LEA_31BIT);
        }else if((int)lo < 0 && hiOnes){    ret.push_back(LEA_HIONES);
        }else if(lo==0){                    ret.push_back(LEA_LOZERO);
        }
    }
    { // bit ops logic
        bool const isI = (int64_t)parm >= -64 && (int64_t)parm <= 63; // I : 7-bit immediate
        bool const isM = isMval(parm); // M : (m)B 0<=m<=63 B=0|1 "m high B's followed by not-B's"
        int64_t const sext7 = (int64_t)(parm<<57) >> 57; // 7 lsbs (trunc, sign-extend)
        if(isI){                            ret.push_back(LOG_I);
        }else if(isM){                      ret.push_back(LOG_M);
        }else if(isMval(parm|0x3f)){        ret.push_back(LOG_XOR_M7SET);
        }else if(isMval(parm^sext7) ){      ret.push_back(LOG_XOR);
        }
    }
    // return base+ival, throwing if ival is not in [0,64]
    auto asEnum = [](Load64 const base, int64_t const ival) {
        if( ival < 0 || ival > 64 ) THROW("Load64 conversion base="<<base<<" ival="<<ival<<" not in range [0,64]");
        return static_cast<Load64>( static_cast<uint32_t>(base + (uint32_t)ival) );
    };

    { // shift: search for an unsigned right-shift that can regenerate parm
        int oksr=0;
        for(int sr=1; sr<64; ++sr){
            if( parm == (parm>>sr<<sr) && isMval(parm>>sr) ){
                oksr=sr; // use smallest shift
                break;
            }
        }
        if(oksr)                            ret.push_back(asEnum(SHL,oksr));
    }
    { // arithmetic ops (+,-)
        int ari=0;
        for( int64_t ival = 0; !ari && ival<=63; ++ival ){
            // P = I + M <===> M == P - I
            uint64_t const mval = parm - (uint64_t)ival;
            if( isMval(mval) ){             ret.push_back(asEnum(ARI_ADD_IPOS, ival));
                ari=1; break; }
        }
        for( int64_t ival = 0; !ari && ival<=63; ++ival ){
            // P = I - M <==> M = I - P
            uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
            if( isMval(mval) ){             ret.push_back(asEnum(ARI_SUB_IPOS, ival));
                ari=1; break; }
        }
        for( int64_t ival = -1; !ari && ival>=-64; --ival ){
            uint64_t const mval = parm - (uint64_t)ival;
            if( isMval(mval) ){             ret.push_back(asEnum(ARI_ADD_INEG, -ival));
                ari=1; break; } }
        for( int64_t ival = -1; !ari && ival>=-64; --ival ){
            uint64_t const mval = (uint64_t)ival - (uint64_t)parm;
            if( isMval(mval) ){             ret.push_back(asEnum(ARI_SUB_INEG, -ival));
                ari=1; break; }
        }
    }
    return ret;
}

std::string prgiLoadreg(uint64_t start)
{
    std::string func("LoadS"); // basename for labels, etc.
    uint64_t const parm = start;
    //int kase = 0; // for simple stuff, don't need execution path machinery.
    string program;
    AsmFmtCols prog;
    prog.lcom(func+"( i = "+jithex(start)+" = "+jitdec(start)+" )");

    string chosen; // which impl?

    OpLoadregStrings ops = opLoadregStrings(parm);
    cout<<" Options:\n";
    if(!ops.lea.empty())    cout<<"\tloadreg lea  "<<ops.lea<<endl;
    if(!ops.log.empty())    cout<<"\tloadreg log  "<<ops.log<<endl;
    if(!ops.shl.empty())    cout<<"\tloadreg shl  "<<ops.shl<<endl;
    if(!ops.ari.empty())    cout<<"\tloadreg ari  "<<ops.ari<<endl;
    if(!ops.lea2.empty()){
        cout<<"\tloadreg lea2 "<<ops.lea2<<endl;
    }
    chosen = (
            !ops.lea.empty()?   ops.lea
            : !ops.log.empty()? ops.log
            : !ops.shl.empty()? ops.shl
            : !ops.ari.empty()? ops.ari
            : ops.lea2 );

    if(1){
        prog
#if 0
            .def("STR0(...)", "#__VA_ARGS__")
            .def("STR(...)",  "STR0(__VA_ARGS__)")
            .def("CAT(X,Y)", "X##Y")
            .def("FN",func)             // func name (characters)
            .def("FNS", "\""+func+"\"") // quoted-string func name
            .def("L(X)", "CAT("+func+"_,X)")
            .def("SI","%s0",            "input value")
            .def("ALG","%s1",           "alg modifier [rarely]")
            .def("BP","%s2",            "internal base pointer for const 'here' data")
            // prgiFoo tests have real outputs:
#endif
            .def("OUT","%s3",           "output value")
#if 0
            .def("OUT2","%s4",          "2nd output [sometimes]")
            .def("VOUT","%v0",          "vector outputs")
            .def("VOUT2","%v1",         " Ex. loop_init(ii,jj)-->vl + 2 vectors?")
            // veliFoo tests have 
            //.def("SE","%s2", "error output")
            //.def("SO","%s3", "other output (code path? secondary output?)")
            // all can use tmp scalar registers (that are in VECLOBBER list of wrpiFoo.cpp) 
#endif
            //if(chosen.find("T0")!=string::npos) // actually, only lea2 case uses a tmp register
            //.def("T0","%s40") // change: maybe not required?
#if 0
            .def("T1","%s41") // etc
            // and some vector registers (also in VECLOBBER?)
            .def("V0","%V0")  // etc
            // macros for relocatable branching
            .def("REL(YOURLABEL)", "L(YOURLABEL)    -L(BASE)(,BP)", "relocatable address")
#endif
            .com("SNIPPET START");
        prog.ins(chosen);
            // add more core code to prog, %s0 is the input, output|error-->%s2,...
        prog.com("SNIPPET END")
            .ins("b.l (,%lr)",          "return (no epilogue)")
            //.undef("FN").undef("FNS").undef("L")
            ;
        program = prog.flush();
    }
    if(1){ // verbose ?
        cout<<func<<" --> program:\n"
            <<program.substr(0,4096)<<endl;
    }
    return program;
}
#undef HD
#undef HEXDEC
#undef STR
#undef STR0
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
/* Copyright (c) 2019 by NEC Corporation
 * This file is part of ve-jit */
/** \file wrappers to call VE jit pages with test logic */
#if !defined(__ve)
//#warning "Empty, since requires ncc to compile VE inline asm"
#else

#include "velogic.hpp"
#include "throw.hpp"
#include <cassert>

#if defined(__ve) && !defined(__GNUG__)
#warning "nc++ might need -std=gnu++11 to enable extended asm"
#endif

/** wrpiFoo calls will claim to clobber %s0--7, %s40--49 */
#define VECLOBBER "%s12", \
    "%s0","%s1","%s2", \
"%s3", \
"%s4", \
"%s5", \
"%s6", \
"%s7", \
"%s40", \
"%s41", \
"%s42", \
"%s43", \
"%s44", \
"%s45", \
"%s46", \
"%s47", \
"%s48", \
"%s49"
        
#include <iostream>
using namespace std;

VeliErr     wrpiLoadreg(JitPage *page)
{
    if( page==nullptr ) THROW("page is null, definitely bad to call that location");
    VeliErr e={0,0,0,0};
    // prgiLoadreg returns JitPage code that has:
    // - INP : no args
    // - OUT : sets %s3 (and no other regs)
    // - MAYBE clobbers tmp T0 = %s40 
    asm( //"\tlea %s0,0x666\n"   /*help find this place in asm*/
            "\tlea %s12, (,%[page])\n"
            "\tbsic %lr,(,%s12)\n"
            "\tor %[out], 0,%s3\n"   /* return optional extra info */
            :[out]"=r"(e.output)
            :[page]"r"(page->mem)
            :"%s3","%s40", "%s12"
       );
    return e;
}

/** for ```veli_loadreg -R``` testing, whose JitPage uses a computed goto to
 * switch between the (about 19 thousand) predefined test cases.
 * \return \c VeliErr with i, error and output for test case i==testnum. */
VeliErr     wrpiLoadregBig(JitPage *page, uint64_t const testnum)
{
    if( page==nullptr ) THROW("page is null, definitely bad to call that location");
    VeliErr e={0,0,0,0};
    e.i = testnum;
    // tmp_veli_loadreg_big code has:
    // - IN[%s0]    test number
    // - BP[%s1]    clobbered base address register
    // - ERR[%s2]   error output
    // - OUT[%s3]   test output
    // - OTHER[%s4] [opt] the absolute address of the test that was run.
    // - T0[%s40]   clobbered tmp register
    // It is implemented as a computed goto into a table of fixed-size
    // code chunks, each of which sets OUT and returns here.
    // ERR is set if testnum is out-of-range.
    assert( page->mem != 0 );
    cout<<" wrpiLoadregBig("<<(void*)(page->mem)<<","<<testnum<<")"<<endl;
    asm( //"\tlea %s0,0x666\n"   /*help find this place in asm*/
            "\tlea %s0,  (,%[arg])\n"
            "\tlea %s12, (,%[page])\n"
            "\tbsic %lr,(,%s12)\n"
            "\tor %[err], 0,%s2\n"
            "\tor %[out], 0,%s3\n"
            "\tor %[out2], 0,%s4\n"
            :[err]"=r"(e.error), [out]"=r"(e.output), [out2]"=r"(e.other)
            :[arg]"r"(testnum), [page]"r"(page->mem)
            :"%s0", "%s1", "%s2", "%s3", "%s40", "%s12"
       );
    // we do not interpretation of e.error or e.output here
    return e;
}

// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
#endif // __ve only code
#include "ve-msk.hpp"
#include <iostream>

using namespace std;

ostream& operator<<(ostream&os, Msk256 const& m256){
    for(int i=0; i<256; ++i){
        int s=i/64, r=63-i%64;
        os<<(s>0 && r==63?" ":"")
            <<((m256.m[s] & (uint64_t{1}<<r))? '1':'0'); }
    return os;
}

ostream& operator<<(ostream&os, Msk512 const& m512){
#if 1
    os<<"\na="<<std::hex;
    for(int i=0;i<4;++i) os<<(i==0?'{':',')<<"0x"<<m512.a.m[i];
    os<<"}\nb=";
    for(int i=0;i<4;++i) os<<(i==0?'{':',')<<"0x"<<m512.b.m[i];
    os<<'}'<<std::dec;
    os<<"\na: "<<m512.a;
    os<<"\nb: "<<m512.b;
    for(int x=0; x<512; ++x){
        if(x%64==0) os<<"\n "<<x/64<<":";
        os<<(m512.get(x)? '1':'0');
    }
#else
    for(int x=0; x<256; ++x){
        int s=x/64, r=x%64;
        os<<((m512.a.m[s] & (uint64_t{1}<<r))? '1':'0')
            <<((m512.b.m[s] & (uint64_t{1}<<r))? '1':'0');
    }
#endif
    return os;
}
/* vim: set sw=4 ts=4 et: */
#include "fuseloop.hpp"
#include "vechash.hpp"    // VecHash2 (hash trace of reference loop execution for ref_vloop2)
#include "stringutil.hpp" // vecprt, lcm[from intutil.hpp]
#include <iomanip>

#ifndef MVL
#define MVL 256
#endif

namespace loop {

using namespace std;

static char const* unrollSuggestNames[] = {
    "UNR_UNSET",
    "UNR_NLOOP1",
    "UNR_VLMODJJ",
    "UNR_JJMODVL_NORESET",
    "UNR_JJMODVL_RESET",
    "UNR_JJPOW2_NLOOP",
    "UNR_JJPOW2_CYC",
    "UNR_JJPOW2_BIG",
    "UNR_NLOOP",
    "UNR_CYC",
    "UNR_DIVMOD" };
static int const nNames = sizeof(unrollSuggestNames) / sizeof(char const*);
static char const* unrollSuggestDescr[] = {
    "uninitialized",
    "no loop [precalc, never unroll]",
    "trivial vl%jj==0 update [no precalc, any small unroll]",
    "trivial jj%vl==0 update [no precalc, any small unroll]",
    "trivial jj%vl==0 update w/ reset [no precalc, any small unroll] XXX check for bcyc_regs or nloop XXX",
    "jj=2^N [precalc, full unroll by nloop]",
    "jj=2^N [precalc, [partial?] cyclic unroll]",
    "jj=2^N large period [easy updated, no precalc, any small unroll)",
    "full precalc [induce via mov+mov] full unroll",
    "precalc b[] [and a?], [partial?] cyclic unroll [induce by mov+add]",
    "no precalc, any small unroll [induce via divmod (slowest)]" };
static_assert( sizeof(unrollSuggestDescr) == sizeof(unrollSuggestNames), "mismatched array sizes");

char const* name( enum Unroll const unr ){
    assert( (int)unr >= 0 && (int)unr < nNames );
    return unrollSuggestNames[unr];
}
char const* desc( enum Unroll const unr ){
    assert( (int)unr >= 0 && (int)unr < nNames );
    return unrollSuggestDescr[unr];
}
std::ostream& operator<<(std::ostream& os, enum Unroll unr){
    return os<<name(unr)
        //<<"("<<(int)unr<<")"
        <<"{"<<desc(unr)<<"}";
}
int64_t ve_vlen_suggest_equ(int64_t const nitems){
    int const v=0; // verbose
    int64_t ret=MVL;
    //bool x0_check_vl = true;
    if( nitems <= MVL ){
        ret = nitems; // trivial: only once through the loop
    }else{
        int64_t const nFull = nitems/MVL;
        int64_t const nLoops = (nitems+MVL-1)/MVL;
        int64_t const rem   = nitems%MVL;
        if(v>0)cout<<" nFull="<<nFull<<" rem="<<rem<<" nLoops="<<nLoops<<endl;
        //if(rem+32 >= MVL){ // rem also large, latency already roughly equal.
        //    ret = MVL; } else
        if( nitems%nLoops == 0 ){
            // this is "good enough" for vector latency, but more importantly
            // avoids some special handling for last-time-through-loop.
            ret = nitems/nLoops;
            if(v>0)cout<<"loop 0.."<<nitems<<" vlen perfect division as "<<ret<<"*"<<nitems/ret<<endl;
            //x0_check_vl = false;
        }else{ // redistribute...
            // we need some remainder, set up a "nice" main vector length
            // DO NOT use rem as loop entry value, only as last-time-through value.
            // [ vector inductions REQUIRE last-loop vlen <= main vlen ]
            int64_t vleq = (nitems+nLoops-1) / nLoops;
            //
            // Note: above ensures that remainder (vector length for last pass)
            // is always less than vleq.
            // For example, N=257, MVL=256 should not use 128+129.
            // Instead, we propose 160+97
            //
            // Why? you will usually set up vector loop induction for the initial
            // vector length, which may then be inalid if vector length ever
            // increases (but stays OK if you shorten vector length).
            //
            // I.e. you can choose between
            // A. ignoring correct unused values, and
            // B. using incorrect [uncalculated?] extra values
            // during the last loop pass.  (A.) is much better.
            //
            if(v>0)cout<<" vleq="<<vleq<<" = "<<nitems<<"/"<<nLoops<<" = nitems/nLoops"<<endl;
            assert( vleq <= MVL );
            if( nitems%vleq != 0 ){
                //vleq = (vleq+31)/32*32;
                //if(v>0)cout<<"vleq rounded up to "<<vleq<<endl;

                ret = vleq;
                if(v>0)cout<<"loop 0.."<<nitems<<" vlen redistributed from "<<MVL<<"*"<<nFull<<"+"<<rem
                    <<" to "<<vleq<<"*"<<nitems/vleq<<"+"<<nitems%vleq<<endl;
                // Paranoia: if we somehow increased loop count, this logic has a bug
                assert( (nitems+vleq-1)/vleq == nLoops );
            }
        }
    }
    return ret;
}

int64_t ve_vlen_suggest(int64_t const nitems){
    int const v=0; // verbose
    int64_t ret=MVL;
    //bool x0_check_vl = true;
    if( nitems <= MVL ){
        ret = nitems; // trivial: only once through the loop
    }else{
        int64_t const nFull = nitems/MVL;
        int64_t const nLoops = (nitems+MVL-1)/MVL;
        int64_t const rem   = nitems%MVL;
        if(v>0)cout<<" nFull="<<nFull<<" rem="<<rem<<" nLoops="<<nLoops<<endl;
        if(rem+32 >= MVL){ // rem also large, latency already roughly equal.
            ret = MVL;
        }else if( nitems%nLoops == 0 ){
            // this is "good enough" for vector latency, but more importantly
            // avoids some special handling for last-time-through-loop.
            ret = nitems/nLoops;
            if(v>0)cout<<"loop 0.."<<nitems<<" vlen perfect division as "<<ret<<"*"<<nitems/ret<<endl;
            //x0_check_vl = false;
        }else{ // redistribute...
            // we need some remainder, set up a "nice" main vector length
            // DO NOT use rem as loop entry value, only as last-time-through value.
            // [ vector inductions REQUIRE last-loop vlen <= main vlen ]
            int64_t vleq = (nitems+nLoops-1) / nLoops;
            //
            // Note: above ensures that remainder (vector length for last pass)
            // is always less than vleq.
            // For example, N=257, MVL=256 should not use 128+129.
            // Instead, we propose 160+97
            //
            // Why? you will usually set up vector loop induction for the initial
            // vector length, which may then be inalid if vector length ever
            // increases (but stays OK if you shorten vector length).
            //
            // I.e. you can choose between
            // A. ignoring correct unused values, and
            // B. using incorrect [uncalculated?] extra values
            // during the last loop pass.  (A.) is much better.
            //
            if(v>0)cout<<" vleq="<<vleq<<" = "<<nitems<<"/"<<nLoops<<" = nitems/nLoops"<<endl;
            assert( vleq <= MVL );
            if( nitems%vleq == 0 ){
            }else{
                // guess latency increments for VE as vector length passes multiples of 32
                // so round "main" vector up to a multiple of 32 (take whatever remains as remainder)
                vleq = (vleq+31)/32*32;
                if(v>0)cout<<"vleq rounded up to "<<vleq<<endl;

                ret = vleq;
                if(v>0)cout<<"loop 0.."<<nitems<<" vlen redistributed from "<<MVL<<"*"<<nFull<<"+"<<rem
                    <<" to "<<vleq<<"*"<<nitems/vleq<<"+"<<nitems%vleq<<endl;
                // Paranoia: if we somehow increased loop count, this logic has a bug
                assert( (nitems+vleq-1)/vleq == nLoops );
            }
        }
    }
    return ret;
}

std::string str(UnrollSuggest const& u, std::string const& pfx /*=""*/){
    std::ostringstream oss;
    if(!pfx.empty()) oss<<" "<<pfx<<" ";
    int64_t const iijj = u.ii * u.jj;
    int vl = u.vl;              // but we might suggest a lower vector length:
    if( u.vll != 0 ){
        assert( u.vll > 0 );
        assert( u.vll <= vl );
        // vl = u.vll; NO -- this makes later assertions fail.
    }

    //uint64_t vlen_equ = ve_vlen_suggest(iijj);
    //oss<<" // ve_vlen_suggest(iijj)="<<vlen_equ<<" (no jj effect, just equitable loop load)"<<endl;
    oss<<"vl,ii,jj,maxun="<<u.vl<<","<<u.ii<<","<<u.jj<<","
        <<u.b_period_max<<" "<<u.suggested;
    if(u.vl>0 && u.ii>0 && u.jj>0 && u.suggested!=UNR_UNSET){
        if(u.unroll>0) oss<<" unroll="<<u.unroll;
        if(u.cycle>0) oss<<" cycle="<<u.cycle;
        int const nloop = (iijj+vl-1) / vl;    // div_round_up(iijj,vl)
        int const lcm_vljj = lcm(vl,u.jj);
        int const b_period = lcm_vljj / vl;
        int const bcyc_regs = (nloop<b_period? nloop: b_period);
        if(1){ // debug
            cout<<" vl,ii,jj,maxun="<<u.vl<<"["<<u.vll<<"],"<<u.ii<<","<<u.jj
                <<","<<u.b_period_max;
            cout<<" iijj="<<iijj;
            cout<<" nloop="<<u.nloop;
            cout<<" b_period="<<b_period;
            cout<<" bcyc_regs="<<bcyc_regs
                <<" unroll="<<u.unroll
                <<" cycle="<<u.cycle
                <<endl;
            cout.flush();
        }
        oss<<" nloop="<<u.nloop;
        if(nloop>1) oss<<" b_period="<<b_period;
        int const unroll_any = min(nloop,abs(u.b_period_max));
        int unroll_cyc = bcyc_regs; // or some small multiple
        if(bcyc_regs>0) unroll_cyc = unroll_any/bcyc_regs*bcyc_regs;
        // if specific unroll factors are needed, print them.
        switch(u.suggested){
          case(UNR_UNSET): break;
          case(UNR_NLOOP1): oss<<" no loop"; break;
          case(UNR_VLMODJJ): oss<<" unroll("<<unroll_any<<")"; break;
                             // jj%vl == 0
          case(UNR_JJMODVL_NORESET): oss<<" unroll("<<unroll_any<<")"; break;
          case(UNR_JJMODVL_RESET): oss<<" unroll("<<unroll_any<<")"; break;
                                   // isPositivePow2(jj)
          case(UNR_JJPOW2_NLOOP): oss<<" unroll("<<nloop<<")";
                                  assert(u.unroll==nloop);
          break;
          case(UNR_JJPOW2_CYC): oss<<" unroll("<<unroll_cyc<<")"
                                <<" bcyc_regs="<<bcyc_regs
                                <<" u.unroll="<<u.unroll;
                                assert(u.unroll%bcyc_regs==0);
          break;
          case(UNR_JJPOW2_BIG): oss<<" unroll("<<unroll_any<<")"; break;
          case(UNR_NLOOP): oss<<" unroll by "<<nloop;
                           assert(u.unroll==nloop);
          break;
          case(UNR_CYC): oss<<" unroll("<<unroll_cyc<<")";
                         assert(u.unroll%bcyc_regs==0);
          break;
                         // generic div-mod
          case(UNR_DIVMOD): oss<<" unroll("<<unroll_any<<")"; break;
        }
    }
    if(u.vll) oss<<" [Alt vll="<<u.vll<<"]";
    uint64_t vlen_equ = ve_vlen_suggest(iijj);
    uint64_t vlen_equ_min = ve_vlen_suggest_equ(iijj);
    oss<<"[Equ "<<vlen_equ<<" "<<vlen_equ_min<<"]";
    //oss<<"\n";
    return oss.str();
}
std::ostream& operator<<(std::ostream& os, UnrollSuggest const& u){
    return os<<str(u);
}
/** \c b_period_max and unroll limits are similar.
 * -ve implies NEVER unroll (maxun=0 or 1).
 * The limit can gaurd against precalculating to many registers.
 *
 * - ret.b_period_max is +/-, and related to ret.cycle and ret.unroll.
 * - ret.unroll is always calculated, but b_period_max -ve means you should ignore it.
 * - ret.cycle influences how much can be precalculated.
 */
UnrollSuggest unroll_suggest( int const vl, int const ii, int const jj, int b_period_max,
        int const v/*verbose=0*/ ){
    int64_t const iijj = ii * jj;
    int const nloop = (iijj+vl-1) / vl;    // div_round_up(iijj,vl)
    enum Unroll strategy = UNR_DIVMOD;
    UnrollSuggest ret(vl,ii,jj,b_period_max);

    int const maxun = (b_period_max>0? b_period_max: 0);
    if(b_period_max<0) b_period_max = -b_period_max;

    if(v>1)cout<<"\nUNROLL_SUGGEST\n";
    bool const jj_pow2 = positivePow2(jj);
    int const jj_shift = positivePow2Shift((uint32_t)jj);
    // Note: I began with a simple cyclic case, jj%vl==0.
    //   In general, the period for b[] vectors is lcm(vl,jj)/vl
    //   Ex. vl=6, jj=8 --> lcm(6,8)/6=24/6 = 4 b[0] cycle={0,6,4,2}
    //   Ex. vl=6, jj=9 --> lcm(6,9)/6=18/6 = 3 b[0] cycle={0,6,3}
    //   Ex. vl=9, jj=6 --> lcm(6,9)/9=18/9 = 2 b[0] cycle={0,3}
    int const lcm_vljj = lcm(vl,jj);
    int const b_period = lcm_vljj / vl;
    char const * b_period_pow2 = (b_period > 1 && positivePow2(b_period)? " 2^k": "");
    // opt: if nloop is low, can also precalc (whether or not it is periodic)
    int const bcyc_regs = (nloop<b_period? nloop: b_period);
    bool const have_b_period = true //jj>1 /*&& jj>=b_period*/
        && bcyc_regs > 1 && bcyc_regs < b_period_max
        && !(nloop>1 && vl%jj==0)
        //&& !have_jjMODvl
        && !(nloop>1 && vl%jj!=0 && jj%vl!=0) // ???
        && !(b_period>1 && !(nloop>1 && jj%vl==0) && jj_pow2 && bcyc_regs<b_period_max)
        ;
    // Adjust default values:
    //ret.vll [0]
    //ret.nloop
    //ret.unroll [0]
    //ret.cycle [0]
    //
    // We cannot nicely do a generic loop cycling over S registers, because Aurora
    // has no load instructions like Sx = S[Sw], where Sw is a cyclic register index.
    //
    // Aurora has register-indirect addressing M[V[Sw]] only for some vector ops,
    // [scatter/gather]
    // and even there it is not loading register values, but memory values.
    //
    // if have_jjMODvl, this is an easy generic-loop case (treated here)
    // else if have_b_period and nloop > bcyc_regs, this is a "Partial Unroll"
    //     (using a set of predefined bcyc_regs vector registers)
    // else if nloop < b_period_max, this is a "full unroll" that can re-use precalc a[] & b[]
    // else if nloop < b_period, a full unroll would use too many regs to precalc a[] & b[]
    //
    // The following logic **suggests** that unrolling has 3 case:
    //    1. full precalc unroll                        (nicest case)
    //    2. partial precalc unroll (still looped)      (fairly nice)
    //    3. full unroll (no precalc)                   (always possible)
    // 1. and 2. are worth considering when:
    //    - ii,jj loops are both enclosed in outer loops
    //    - OR partial precalc reduces full unroll code size greatly.
    // Any unroll can be chosen for trivial updates:
    //    - have vl%jj==0
    //    - have jj%vl==0
    // Precalc for a jj_pow2 case may or may not be good.
    if( nloop == 1 ){
        ret.suggested = strategy = UNR_NLOOP1;
        ret.vl = iijj;
        if(v>0)cout<<" A.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
            <<strategy<<"\n\t"
            <<", b_period="<<b_period<<b_period_pow2<<" no loop [precalc, no unroll]"<<endl;
    }else if( vl%jj == 0 ){
        ret.suggested = strategy = UNR_VLMODJJ;
        if(v>0)cout<<" B.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
            <<strategy<<"\n\t"
            <<", b_period="<<b_period
            <<" has a trivial vl%jj==0 update [no precalc, any small unroll]"
            <<endl;
        //assert( !have_b_period );
    }else if( jj%vl == 0 ){
        uint32_t const period = jj/vl;
        // fuse2.cpp shows 4 different update impls, one being trivial
        // debug -- NORESET is definitely attainable
        //bool const have_jjMODvl_reset = (vl0%jj!=0 && jj%vl0==0 && nloop >jj/vl0); // case 'g'
        //bool const have_jjMODvl       = (vl0%jj!=0 && jj%vl0==0 && nloop>=jj/vl0);
        //assert( have_jjMODvl );
        if((uint32_t)nloop > period){ // have_jjMODvl_reset
            //assert(have_jjMODvl_reset);
            ret.suggested = strategy = UNR_JJMODVL_RESET;
            // depending on period==2, other power-of-two, or anything else,
            // have 3 different simple updates.
            if(v>0)cout<<" C.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
                <<strategy<<"\n\t"
                    <<", b_period="<<b_period<<b_period_pow2
                    <<" has a simple jj%vl==0 update [no precalc, any small unroll]"
                    <<endl;
            if(period <= (uint32_t)b_period_max){
                ret.unroll = (uint32_t)b_period_max/period*period;
                ret.cycle  = period;
            }else{
                ret.unroll = b_period_max;
                ret.cycle = 0;
            }
        }else{
            // update is trivial FOR(i,vl) b[i] = b[i] + vl;
            ret.suggested = strategy = UNR_JJMODVL_NORESET;
            if(v>0)cout<<" c.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
                <<strategy<<"\n\t"
                    <<", b_period="<<b_period<<b_period_pow2
                    <<" has a trivial jj%vl==0 update [no precalc, any small unroll]"
                    <<endl;
            ret.unroll = min(b_period_max,nloop);
            ret.cycle = 0;
        }
        //assert( !have_b_period );
        //assert("Never got case B"==nullptr);
    }else if( jj_pow2 ){
        if(nloop < b_period_max){
            ret.suggested = strategy = UNR_JJPOW2_NLOOP;
            if(v>0)cout<<" D.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
                <<strategy<<"\n\t"
                <<", b_period="<<b_period<<b_period_pow2<<", bcyc_regs="<<bcyc_regs
                <<" has jj=2^"<<jj_shift<<" with precalc unroll(nloop="<<nloop<<")"
                <<endl;
            ret.unroll = nloop;
            ret.cycle = ret.unroll;
        }else if(bcyc_regs < b_period_max){
            ret.suggested = strategy = UNR_JJPOW2_CYC;
            if(v>0)cout<<" E.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
                <<strategy<<"\n\t"
                <<", b_period="<<b_period<<b_period_pow2<<", bcyc_regs="<<bcyc_regs
                <<" has jj=2^"<<jj_shift<<" with precalc unroll(bcyc_regs="<<bcyc_regs<<")"
                <<endl;
            //assert( have_b_period );
            ret.unroll = b_period_max/bcyc_regs*bcyc_regs;
            ret.cycle = bcyc_regs;
        }else{
            ret.suggested = strategy = UNR_JJPOW2_BIG;
            if(v>0)cout<<" F.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
                <<strategy<<"\n\t"
                <<", b_period="<<b_period<<b_period_pow2<<", bcyc_regs="<<bcyc_regs
                <<" has jj=2^"<<jj_shift<<" easy update, but large period [no precalc, any small unroll]"
                <<endl;
            ret.unroll = min(b_period_max,nloop);
        }
    }else if( nloop < b_period_max ){ // small nloop, any b_period
        ret.suggested = strategy = UNR_NLOOP;
        if(v>0)cout<<" G.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
            <<strategy<<"\n\t"
            <<", b_period="<<b_period<<b_period_pow2
            <<" suggest full precalc unroll(nloop="<<nloop<<")\n"
            <<"     Then a[]-b[] induction is 2 ops total, mov/mov from precalc regs to working"
            <<endl;
        ret.unroll = nloop;
        // no. also ok for non-cyclic and low nloop ... assert( have_b_period );
    }else if( bcyc_regs < b_period_max ){ // small b_period, high nloop
        ret.suggested = strategy = UNR_CYC;
        if(v>0)cout<<" H.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
            <<strategy<<"\n\t"
            <<", b_period="<<b_period<<b_period_pow2
            <<" suggest partial precalc unroll(b_period="<<b_period<<")\n"
            <<"   b[] and a[]-INCREMENT cycle through precalc values\n"
            <<"     Then a[]-b[] induction is 2 ops total, mov/add from precalc regs to working"
            <<endl;
        // no...assert( have_b_period );
        //assert(" never get to H"==nullptr);
        //ret.unroll = b_period; // XXX or maybe b_period * N < b_period_max ??? XXX
        ret.unroll = b_period_max/b_period*b_period;
        ret.cycle = b_period;
    }else{ // nloop and b_period both high OR this is a simpler case
        ret.suggested = strategy = UNR_DIVMOD;
        if(v>0)cout<<" I.vl,ii,jj="<<vl<<","<<ii<<","<<jj<<" nloop="<<nloop<<" "
            <<strategy<<"\n\t"
            <<", b_period="<<b_period<<b_period_pow2<<" both high:"
            <<" full unroll(nloop="<<nloop<<") [no precalc] still possible"
            <<endl;
        assert( !have_b_period );
        ret.unroll = min(b_period_max,nloop);
    }
#if 0
    // example code for precalc-unroll
    // bcyc and acyc may be precalculated registers (or possibly loaded from .rodata)
    VVlpi bcyc[bcyc_regs][vl], aDcyc[bcyc_regs][vl];
    if( have_b_period ){
        // precalculate either acyc ~      a[...][vl] and bcyc ~ b[...][vl]
        //           or        acyc ~ aDelta[...][vl] and bcyc ~ b[...][vl] (nloop <= b_period)
        assert( jj > 1 );
        assert( b_period > 1 );
        assert( !jj_pow2 );
        for(int cyc=0; cyc < bcyc_regs && cnt < iijj; cnt+=vl, ++cyc )
        {
            VVlpi a0[vl];
            int const bogus=666;
            if(cyc==0){
                if(jj>=vl) FOR(i,vl) { a[i]=0; b[i]=i; }
                else FOR(i,vl) { a[i] = jj_M*sq[i] >> C; b[i] = sq[i] - a[i]*jj;
                    ++cnt_sq; ++cnt_jj_M;
                    assert( have_sq ); assert( have_jj_M );
                }
                FOR(i,vl) acyc[0/*cyc*/][i] = a[i]; // final value, if nloop<b_period
            }else{
                assert( nloop > 1 );
                assert( !(vl%jj==0) );
                if( vl%jj==0 ) assert( !(jj%vl==0) );
                FOR(i,vl) bA[i] = vl + b[i];            // add_vsv
                FOR(i,vl) bD[i] = ((jj_M*bA[i]) >> C);  // fastdiv_uB   : mul_vvs, shr_vs
                FOR(i,vl) b [i] = bA[i] - bD[i]*jj;     // long-hand    : mul_vvs, sub_vvv
                FOR(i,vl) a [i] = a[i] + bD[i];         // add_vvv
                if( nloop < b_period ){
                    FOR(i,vl) acyc[cyc][i] = a[i];
                }else{
                    FOR(i,vl) acyc[cyc][i] = bD[i];
                    if( cyc == b_period ){ // change acyc[0] to a delta value too...
                        FOR(i,vl) acyc[0][i] = acyc[0][i] - a[i];
                    }
                }
                ++cnt_bA_bD; ++cnt_jj_M;
                assert( have_bA_bD ); assert( have_jj_M );
            }
        }
    }
#endif
    //cout<<" dbg: "<<strategy<<"  sugg "<<ret.suggested<<" unroll "<<ret.unroll<<endl;
    if(maxun>0 && ret.unroll==0){
        cout<<"TODO: set u.unroll to something nice [maxun="<<maxun<<"]"<<endl;
    }
    assert(ret.suggested != UNR_UNSET);
    return ret;
}
/** u modified to set u.vll \em and return corresponding UnrollSuggest for the alt vl. */
UnrollSuggest unroll_suggest( UnrollSuggest& u, int vl_min/*=0*/, int const v/*=0,verbosity*/ ){
    if( u.suggested != UNR_UNSET ){
        cout<<" Looking for an alt strategy..."<<endl;
    }
    double const f=(224./256.); //0.90
    int const vl = u.vl;
    uint64_t const iijj = u.ii * u.jj;
    uint64_t const nloop0 = (iijj+u.vl-1) / u.vl;    // div_round_up(iijj,vl)
    int const vl_equ_min = ve_vlen_suggest_equ(u.ii*u.jj); // "same" nloops, balanced vlen
    int const vl_max = max(1,(u.suggested==UNR_UNSET? vl: vl-1));

    // if vl_min is unspecified [out-of-range] set it via some HEURISTIC
    if( vl_min < 1 || vl_min > vl ){ // vl_min default (or out-of-range)?
        if(vl==MVL){
            // equitable work limit, tailored for VE:
            //vl_min = vl_equ_min;
            // if ii*jj is large, above range is too small, if we consider that
            // unroll Alt saving is accrued each time through loop.
            // So let's allow up to 5% more loops.
            // Later we'll use a better model to weed out duds [OpSave estimator]
            uint64_t const nloop = (105*nloop0+99)/100;
            uint64_t const vleq = (iijj+nloop-1) / nloop;
            vl_min = vleq; // with only "just a little more" loops allowed

        }else{ // original "fraction" behaviour
            //for general testing purposes (arbitrary vl)
            vl_min = max( 1, (int)(f*vl) );
            // above could be different -- Ex. vl_min implying same # nloops
        }
    }

    // u.b_period_max -ve prevents all loop unrolling, so ignore u.unroll
    int const unroll = (u.b_period_max>0? u.unroll: 0);
    //
    //  OpSave estimator
    //
    // Compare {N,I,K} nloops, induction-ops, kernel-ops
    // with {N',I',K'} uAlt suggestion.
    //
    // OpSaving = Ops' - Ops
    //          = N'*I'-N'*K - N*I+N*K
    //          = N'*I' - N*I  -  (N'-N)*K
    // Typical uAlt saving is I~4 to I'~1
    // and suppose kernel K is 10 ops...
    int const Kops=10;      // Suppose kernel is 10 ops XXX
    //... hmm Iops actually depends on precalc/unroll support too
    //    Ex. precalc outside of outer loops can have ret/nloop ~ zero. 
    auto Iops = [](enum Unroll const sugg){
        int ret = (sugg==UNR_DIVMOD? 4
            :sugg==UNR_JJPOW2_NLOOP || sugg==UNR_JJPOW2_NLOOP || sugg==UNR_JJPOW2_BIG? 2
            :sugg==UNR_JJMODVL_NORESET || sugg==UNR_JJMODVL_RESET? 1
            :sugg==UNR_VLMODJJ? 1
            :sugg==UNR_NLOOP1? 2
            :sugg==UNR_UNSET? 999999 // <-- always-worst
            :2);
        return ret;
    };

    //auto OpEst = [&Kops,&Iops,&iijj,&unroll](enum Unroll const sugg, int const vl)
    auto OpEst = [&Iops,&iijj,&unroll](enum Unroll const sugg, int const vl)
    {
        int const iops = Iops(sugg);            // induction ops
        int const nl = (iijj+vl-1)/vl;          // num loops
        double ops = nl*iops + nl*Kops;         // induction + kernel ops
        bool const vl_changes = iijj%vl;        // 1 unroll might have extra
        if(vl_changes) ops += nl*(unroll<=1? 3.0: 3.0/unroll); // ~ 3 scalar ops
        // XXX when unroll>1, OpEst should also favor nPart==0 (a tiny bit)
        ops = (int)(ops*100.0)*0.01;
        return ops;
    };

    //double const opsOrig = nloop0 * Iops(u.suggested) + nloop0*Kops;
    double const opsOrig = OpEst(u.suggested,vl);
    auto OpSave = [&OpEst,&opsOrig](enum Unroll const sugg, int const vll){
        double ops = OpEst(sugg, vll);
        double const ret = opsOrig - ops; // +ve is GOOD, vll saves operations
        return ret;
    };

    if(v>0)cout<<" checking [ "<<vl_max<<" to "<<vl_min<<" ] ... "
        <<" nloops orig "<<(iijj+vl-1)/vl<<", @vl_max:"<<(iijj+vl_max-1)/vl_max
        <<", @vl_min:"<<(iijj+vl_min-1)/vl_min
        <<" OpSave kernel ops="<<Kops<<" unroll="<<unroll<<endl;

    //
    auto const sugg = u.suggested; // induction strategy
    bool const jj_pow2 = positivePow2(u.jj);
    if( sugg != UNR_NLOOP1 && sugg!=UNR_VLMODJJ && sugg!=UNR_JJMODVL_NORESET
            && sugg!=UNR_JJMODVL_RESET && !jj_pow2 ){
        // quick check for very easy cases (just print msg)
        // PURELY INFORMATIVE: always print, even for a vll < vl_min
        int const jj = u.jj;
        if( jj < vl ){
            int const vll = vl/jj*jj;
            if(v>0)cout<<"   Note: vl/jj*jj = "<<vll<<" is an exact multiple of jj"
                " (vl reduced by "<<(vl-vll)<<" or "<<int((vl-vll)*1000.0/vl)*0.1<<"%)"
                <<"\n         with nloops' = "<<(u.ii*u.jj+vll-1)/vll
                <<endl;
        }else if( jj > vl && jj%vl!=0){
            // can we make jj an exact mult of vll?
            int const nup = (jj+vl-1)/vl;
            if( jj%nup == 0 ){
                int const vll = jj/nup;
                if(v>0)cout<<"   Note: vl = "<<jj/nup<<" would make jj an exact mult of vl"
                    " (vl reduced by "<<(vl-vll)<<" or "<<int((vl-vll)*1000.0/vl)*0.1<<"%)"
                    <<"\n         with nloops' = "<<(u.ii*u.jj+vll-1)/vll
                    <<endl;
            }
        }
    }
    // "Efficient" list:
    //          UNR_NLOOP1              UNR_VLMODJJ
    //          UNR_JJMODVL_NORESET     UNR_JJMODVL_RESET
    //          UNR_JJPOW2_{NLOOP,CYC,BIG}
    //          UNR_CYC         (and maybe UNR_NLOOP)
    // leaving "inefficient" as:
    //          UNR_DIVMOD      (and maybe UNR_NLOOP)
    //
    // If u.vl is already "efficient", still try for a decent low-vl alternate
    UnrollSuggest ret = UnrollSuggest(); // If no good alt, ret is 'empty'
    u.vll = 0;                           //             and u.vll is zero
#if 0
    if( u.suggested == UNR_JJMODVL_NORESET )
        cout<<"  ---> UNR_DIVMOD_NORESET trivial, no better alt"<<endl;
    else if( u.suggested == UNR_NLOOP1 )
        cout<<"  ---> NLOOP1 has no better alt"<<endl;
    else if( u.suggested == UNR_VLMODJJ )
        cout<<"  ---> UNR_VLMODJJ trivial, no better alt"<<endl;
    else
#else
    if(1){
#endif
        if(v>0)cout<<"Checking vll ... orig alg "<<name(u.suggested)<<" nloops "<<(iijj+vl-1)/vl
            <<" orig ops~"<<opsOrig<<endl;
        int best_vll=0;
        int best_opsave=0;
        UnrollSuggest best_u;
        for( int vll = vl_max; vll >= vl_min; --vll){
            if(v>0){cout<<" "<<vll; cout.flush();}
            UnrollSuggest us = unroll_suggest(vll, u.ii, u.jj, u.b_period_max, 0/*verbose*/);
            int opsave = OpSave(us.suggested, vll);
            if(v>0)cout<<" ("<<int(vll*1000./vl)*0.1<<"%) ---> alg "<<name(us.suggested)
                <<" nloops "<<(iijj+vll-1)/vll<<" [save "<<opsave<<"] ";
            if( us.suggested==UNR_DIVMOD && u.suggested!=UNR_UNSET && u.suggested!=UNR_DIVMOD ){
                // this is the worst, so it cannot be an improvement (and might even have nloop higher)
                //cout<<" skipped: UNR_DIVMOD "<<endl;
                //continue;
                // BUT [new] it might lower vlen without nloop increase?
                if(v>0)cout<<" bad-orig";
            }
            if( u.suggested == UNR_JJMODVL_NORESET
                    || u.suggested == UNR_NLOOP1
                    || u.suggested == UNR_VLMODJJ){
                    //cout<<"  ---> trivial orig "<<name(u.suggested)<<", no better alt"<<endl;
                    //continue;
                    if(v>0)cout<<" trivial-orig";
            }
            if(1){
                // Is this alt any different?
                //if(us.suggested == u.suggested && us.unroll>=u.unroll){ // it can't be much better
                //    // Sometimes this can pick up iijj%vl==0 case! so NOT a good guess
                //    cout<<"  ---> skipped because it's too similar to original"
                //        <<" [save "<<opsave<<"]"<<endl;
                //    continue;
                //}
                if(us.suggested == u.suggested && opsave>=0 && iijj%vll==0){
                    if(v>0)cout<<" ACCEPTED! iijj%vll==0"<<endl;
                    if(opsave >= best_opsave){ best_opsave = opsave; best_vll = vll; best_u=us; }
                    continue;
                }
                if(u.suggested==UNR_JJMODVL_RESET /*other JJMODVL trivial, never here*/
                        && (us.suggested==UNR_JJPOW2_NLOOP || us.suggested==UNR_JJPOW2_BIG)){
                    if(v>0)cout<<"  ---> JJPOW2 without precalc (4 vec ops) never beats JJMODVL"
                        <<" [save "<<opsave<<"]"<<endl;
                    continue;
                }
                //
                // If unrolling for real, with precalculated constants,
                // UNR_NLOOP should always "equalize' the VLs using 'nice_vector_length(iijj)'.
                //
                // If NOT unrolling the loop, then the recalculation is quite a bit faster
                // for UNR_VLMODJJ.
                //
                // Here we adopt UNR_VLMODJJ even if it adds more loops, because the loop update is trivial
                //
                if(us.suggested == UNR_JJPOW2_BIG
                        || u.suggested== UNR_DIVMOD
                        || (us.suggested==UNR_VLMODJJ /*&& u.nloop == us.nloop*/) // trivial induction!
                        || (us.suggested==UNR_JJMODVL_NORESET /*&& u.nloop == us.nloop*/) // trivial!
                        ){
                    if(v>0)cout<<" alg "<<name(us.suggested)<<" nicer";
                    //ret = us;    // return the nice alt
                    //u.vll = vll; // also record existence-of-alt into u
                    //break;
                    if(opsave<=0) {
                        if(v>0)cout<<" but higher ops."<<endl;
                        continue;
                    }
                }

                // NEW: base acceptance on opsave (which assumes no unrolling/precalc)
                if(opsave>=0){
                    if(v>0)cout<<" ACCEPTED! (might save ops)"<<endl;
                    //ret = us;    // return the nice alt
                    //u.vll = vll; // also record existence-of-alt into u
                    //break;
                    if(opsave >= best_opsave){ best_opsave = opsave; best_vll = vll; best_u=us; }
                    continue;
                }
                if(v>0)cout<<endl;
            }
        }
        if(best_vll > 0){
            u.vll = best_vll;
            ret = best_u;
            if(v>0)cout<<"Best [/lowest equiv] vl "<<u.vl<<" --> "<<u.vll<<" [saved "<<best_opsave<<"]";
            //UnrollSuggest us = unroll_suggest(u.vll, u.ii, u.jj, u.b_period_max, 0/*verbose*/);
        }
    }
    // if u.vll is still unset, set it to min-VL-for-same-nloops ("equitable" vl_equ)
    if(vl==MVL && u.vll==0 && vl_equ_min<=vl_max){
        // opsave==0 picks up many of these cases via best_vll,
        // but we still might catch some 'auto-skipped' cases, I think.
        int const vl_equ = ve_vlen_suggest(u.ii*u.jj);
        if(vl_equ<=vl_max)          u.vll = vl_equ;      // VE latency-adjusted work balance
        else if(vl_equ_min<=vl_max) u.vll = vl_equ_min;  // else work balance only (not mult of 32)
        if(u.vll != 0){
            if(v>0)cout<<" vl="<<u.vll<<" ACCEPTED! (for load balance, not unroll)";
            // This is something like vl_equ round up to mult of 32
            UnrollSuggest us = unroll_suggest(u.vll, u.ii, u.jj, u.b_period_max, 0/*verbose*/);
            ret = us;      // similar alg, but slightly better load balance (~vector latencies)
            // this might actually be bad, if you want very low latency last time through!
        }
    }
    if(v>0)cout<<endl;
    return ret;
}

/** Generate reference vectors of vectorized 2-loop indices */
std::vector<Vab> ref_vloop2(Lpi const vlen, Lpi const ii, Lpi const jj,
        int const verbose/*=1*/ )
{
    std::vector<Vab> vabs; // fully unrolled set of reference pairs of a,b vector register
    VecHash2 vhash(vlen);

    VVlpi a(vlen), b(vlen);
    int v=0; // 0..vlen counter
    for(int64_t i=0; i<(int64_t)ii; ++i){
        for(int64_t j=0; j<(int64_t)jj; ++j){
            //cout<<"."; cout.flush();
            a[v] = i; b[v] = j;
            if( ++v >= vlen ){
                vabs.emplace_back( a, b, v );
                vhash.hash_combine( a.data(), b.data(), vlen );
                vabs.back().hash =  vhash.u64();
                v = 0;
            } 
        }
    }
    cout<<vabs.size()<<" full loops of "<<vlen<<" with "<<v<<" left over"<<endl;
    if( v > 0 ){ // partial final vector
        for(int i=v; i<vlen; ++i) { a[i] = b[i] = 0; }
        vabs.emplace_back( a, b, v );
        vhash.hash_combine( a.data(), b.data(), v );
        vabs.back().hash =  vhash.u64();
    }

    if(verbose>0){ // print ref result
        // pretty-printing via vecprt
        int const n=8; // output up-to-n [ ... [up-to-n]] ints
        int const bignum = std::max( ii, jj );
        int const wide = 1 + (bignum<10? 1: bignum <100? 2: bignum<1000? 3: 4);

        for(size_t l=0; l<vabs.size(); ++l){
            auto const& a = vabs[l].a;
            auto const& b = vabs[l].b;
            auto const& vl = vabs[l].vl;
            cout<<"__"<<l<<endl;
            cout<<"a_"<<l<<"["<<vl<<"]="<<vecprt(n,wide,a,vl)<<endl;
            cout<<"b_"<<l<<"["<<vl<<"]="<<vecprt(n,wide,b,vl)<<" hash"<<vabs[l].hash<<endl;
        }
    }
    return vabs;
}
/** \fn unroll_suggest
 *
 * What about vector barrel rotate (Aurora VMV instruction)...
 *
 * Idea:
 *
 *      for some jj, esp if vl+jj<256
 *      the bM,bD divmod operation might be OPTIMIZED to rot
 *      if you are willing to modify vlen or have extended-length
 *      rotation.  NB: this is rotation across vector indices.
 *      Here I consider register-only implementations.
 *
 * Conclusion:
 *
 *    - Works nicely if we have a double-vector rotate (we don't)
 *      or a rotate mod other values than MVL=256.
 *      Aurora doesn't, and the useful rotation cases
 *      already have a low op-count update.
 *
 *    - A fast long-vector rotation can be simulating by calculating a
 *      cyclic start index and doing a single \b memory load.
 *    - This depends on existence of non-trivial cases... we show one below
 *      -  i' = i+shift; if(i'>period) i'-=period   // add, conditional subtract
 *      -  b' = read vector from data[i']           // memory load
 *      -  and then modulo (mul,sub) and a' (add)
 *    - which is \em likely about the \em same speed as the divmod_uB
 *      -  cf. worst case 'i' with 6 ops, no conditionals, no mem access
 *
 *
 * Analysis: What is the complexity of simulating the rotation? 
 *
 * Ex. ```./fuse2 -t 256 1000 25; ./fuse2 -t 256,200,50;```
 * suggests
 * ```
 *  I.vl,ii,jj=256,1000,25 nloop=98, b_period=25 both high: full unroll(nloop=98) [no precalc] still possible
 *  I.vl,ii,jj=256,200,50 nloop=40, b_period=25 both high: full unroll(nloop=40) [no precalc] still possible
 * ```
 * but we could unroll by any small amount as follows:
 *
 * - store b[256+25] as (Vz[25],Vy[256]), so current b[vl] is stored in Vy register.
 * - b[] may update like [0 1 2...]     // a cyclic sequence, mod jj
 *                   --> [6 7 8...]
 *                   --> [12 13 14...]
 * - this is like a long-rotate-right by 6 vector indices, of a 256+25-long (Vz,Vy) "vector" register
 * - Aurora vector rotate is "Vector Move", VMV
 *   - Vx[i=0..vl] = Vz(mod((unsigned)(Sy+1),MVL)))
 *   - no rotate across two vector registers
 * - Could simulate long-register VMV:
 *   - rsh = 19                                 // const index shift
 *   - SyL = 6 = b_period - Sy                  // const up-shift for b'[i] = b[i-SyL]
 *   - VsqR = [ ?..? 0,1,2,...b_period-1 ]      // const vector
 *   - // 
 *   - Sy = rsh [19]                            // initial Sy
 *   - SyR = MVL - b_period + Sy                // initial shift for VsqR --> b'[0] = VsqR[SyR]
 *   - VMy = VM [ 1,1,..1 (19x) 0..0 ]
 *   - VM~y = VM [ 0..0 (19x) 1..1 ]
 *   - b[i] = fastmod(vsq[], b_period)          // initial b[i]
 *   - // Induction inputs: SyR, b[vl]
 *   - b  = [ b0 b1 ... b_vl ]                  // input; precond vl > Sy
 *   - // Induction:
 *   - Sy=Sy+SyL                                // Sy subsequent updates
 *   - VMV b', b, Sy, vl-b_period+rsh            // b' = [ ?bogus? (19x) b0 b1 ... b_{vl-Sy} ]
 *   - SyR += SyL; if( SyR > MVL ) SyR -= b_period; // SyR subsequent updates
 *   - VMV first, SyL, Sy                       // shift in correct values for ?bogus? region
 *   - VMRG b, b', first, VMy                   // next value of b[]
 * - But this is already has more instruction count than the full recalc
 *
 * - if jj is not a multiple of vl (or other way), then we do not have equally
 *   sampled values 0..jj in the b[] vector, so no single-vector Aurora VMV suffices.
 * - You can \b only do rotate method easily if \f$Vcyc = (vl/b_period)*b_period + b_period\f$
 *   can EXACTLY equal 256 in a SINGLE Aurora VMV, though.
*   - but this happens for vl > jj only for jj already a power of two [already fast]
*   - and implies jj is a power of two,
    *     - so we already have a fast update : vl%jj==0 or otherwise
    *
    * Conclusion: Aurora does not allow a fast vlen ~ MVL rotation method
    *
    */


}//loop::
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break

#include "ve_divmod.hpp"
#include "cblock.hpp"
#include "stringutil.hpp"

namespace cprog {

using namespace std;

int mk_FASTDIV(Cblock& cb, uint32_t const jj, uint32_t const vIn_hi/*=0*/,
        int const v/*=0,verbose*/){
    bool const verify=true; // false after code burn-in
    bool const macro_constants = false;
    bool const define_FASTDIV_SHR = false;  // #define?
    bool const const_fastdiv_SHR = false;   // uint64_t const?  [else inline the shift constant]
    int ret=0;
    ostringstream oss;
    // go up to some well-defined scope position and use a named-block to
    // record that this macro exists (try not to duplicate the definition)
    // where Cblock::define will place definitions (may need tweaking?)
    auto& scope=(cb.getName()=="body"? cb: cb["..*/body/.."]);
    string tag = OSSFMT("fastdiv_"<<jj); // "we were here before" tag
    if(v>1) cout<<"mk_FASTDIV_"<<jj<<" range "<<vIn_hi<<" to scope "<<scope.fullpath()
        //<<" <"<<scope.str()<<">"
        <<endl;;
    if(scope.find(tag)){
        if(v>1) cout<<"FASTDIV_"<<jj<<" macro already there"<<endl;
    }else{
        scope[tag].setType("TAG");
        if(v>0) cout<<"FASTDIV_"<<jj<<" new macro, input range "<<vIn_hi<<endl;
        struct fastdiv jj_fastdiv;
        uint32_t fastdiv_ops = 0U;
        {
            fastdiv_make( &jj_fastdiv, (uint32_t)jj );
            if(v>2)cout<<" mul,add,shr="<<(void*)(intptr_t)jj_fastdiv.mul
                <<","<<jj_fastdiv.add<<","<<jj_fastdiv.shift;
            if(jj_fastdiv.mul != 1) ++fastdiv_ops;
            if(jj_fastdiv.add != 0) ++fastdiv_ops;
            if(1) /*shift*/ ++fastdiv_ops;
            if(v>0) cout<<" struct fastdiv (mul,add,shr) in "<<fastdiv_ops<<" ops"<<endl;
        }
        string fastdiv_macro;
        // Accept fastdiv_ops<=2 because 1) bigger range; 2) sometimes smaller const mult
        // Otherwise, if jj_hi is given and small enough, we use the 2-op mul-shift method.
        if(fastdiv_ops==3 && (vIn_hi>0 && vIn_hi <= FASTDIV_SAFEMAX)){
            // fastdiv_ops==3 means we don't have a power-of-two easy case, so if
            // the input vector u32's are "small", we can have a 2-op mul-shift.
            uint64_t const jj_M = computeM_uB(jj); // 42-bit fastdiv_uB multiplier
            string mac;

            string mul;
            if(macro_constants||isIval(jj_M)){
                mul = OSSFMT("FASTDIV_"<<jj<<"_MUL");
                scope.define(mul,OSSFMT("((uint64_t)"<<jithex(jj_M)<<")"));
            }else{
                mul = OSSFMT("fastdiv_"<<jj<<"_MUL");
                cb["..*/first"]>>OSSFMT("uint64_t const "<<mul<<" = "<<jithex(jj_M)<<";");
            }
            mac = OSSFMT("_ve_vmulul_vsv("<<mul<<",V)");

            string shr;
            if(define_FASTDIV_SHR){
                shr = OSSFMT("FASTDIV_"<<jj<<"_SHR");
                scope.define(shr,jitdec(FASTDIV_C));
            }else if(const_fastdiv_SHR){
                shr = OSSFMT("fastdiv_"<<jj<<"_SHR");
                cb>>OSSFMT("uint64_t const "<<mul<<" = "<<FASTDIV_C<<";");
            }else{
                shr = jitdec(FASTDIV_C);
            }
            //mac = OSSFMT("_ve_vsrl_vvs("<<mac<<","<<shr<<")/*OK over [0,"<<vIn_hi<<")*/");
            mac = OSSFMT("_ve_vsrl_vvs("<<mac<<","<<shr<<")/*OK over [0,2^"<<FASTDIV_C/2<<")*/");

            fastdiv_macro = mac;
            ret = 2;
            if(v>0) cout<<"mk_FASTDIV "<<ret<<" ops, macro="<<fastdiv_macro<<endl;
            if(verify){ // quick correctness verification
                uint32_t hi = vIn_hi;
                if(hi==0){ hi = 257*min(jj,16384U); }
                for(uint64_t i=0; i<=hi; ++i){ // NB: 64-bit i
                    assert( ((i*jj_M)>>FASTDIV_C) == i/jj );
                }
            }

        }else{ // use 'struct fastdiv' approach (3-op max, 1-op min)
            string mac;
            if(jj_fastdiv.mul != 1){
                string mul;
                if(macro_constants||isIval(jj_fastdiv.mul)){
                    mul = OSSFMT("FASTDIV_"<<jj<<"_MUL");
                    scope.define(mul,jithex(jj_fastdiv.mul));
                }else{
                    mul = OSSFMT("fastdiv_"<<jj<<"_MUL");
                    cb["..*/first"]>>"uint64_t const "<<mul<<" = "<<jithex(jj_fastdiv.mul)<<";";
                }
                mac=OSSFMT("_ve_vmulul_vsv("<<mul<<",V)");
            }else{
                mac="V";
            }
            if(jj_fastdiv.add != 0){
                string add;
                if(macro_constants||isIval(jj_fastdiv.add)){
                    add = OSSFMT("FASTDIV_"<<jj<<"_ADD");
                    scope.define(add,jitdec(jj_fastdiv.add));
                }else{
                    add = OSSFMT("fastdiv_"<<jj<<"_ADD");
                    cb>>OSSFMT("uint64_t const "<<add<<" = "<<jitdec(jj_fastdiv.add)<<";");
                }
                mac=OSSFMT("_ve_vaddul_vsv("<<add<<","<<mac<<")");
            }
            if(jj_fastdiv.shift != 0){
                string shr;
                if(define_FASTDIV_SHR){
                    shr = OSSFMT("FASTDIV_"<<jj<<"_SHR");
                    scope.define(shr,jitdec(jj_fastdiv.shift));
                }else if(const_fastdiv_SHR){
                    shr = OSSFMT("fastdiv_"<<jj<<"_SHR");
                    cb>>OSSFMT("uint64_t const "<<shr<<" = "<<jj_fastdiv.shift<<";");
                }else{
                    shr = jitdec(jj_fastdiv.shift);
                }
                mac=OSSFMT("_ve_vsrl_vvs("<<mac<<","<<shr<<")");
            }
            fastdiv_macro = mac;
            ret = fastdiv_ops;
            if(v>0) cout<<"mk_FASTDIV "<<ret<<" ops, macro="<<fastdiv_macro<<endl;
            if(verify){ // quick correctness verification
                uint32_t hi = vIn_hi;
                if(hi==0){ hi = 257*min(jj,16384U); }
                for(uint64_t i=0; i<=hi; ++i){ // NB: 64-bit i
                    assert( (((uint64_t)i*jj_fastdiv.mul+jj_fastdiv.add)>>jj_fastdiv.shift) == i/jj );
                }
            }

        }
        scope.define(OSSFMT("FASTDIV_"<<jj<<"(V)"),fastdiv_macro);
    }
    return ret;
}

int mk_DIVMOD(Cblock& cb, uint32_t const jj, uint32_t const vIn_hi/*=0*/,
        int const v/*=0,verbose*/){
    ostringstream oss;
    // go up to some well-defined scope position and use a named-block to
    // record that this macro exists (try not to duplicate the definition)
    auto& scope=(cb.getName()=="body"? cb: cb["..*/body/.."]); // where Cblock::define will place definitions
    if(v>1) cout<<"mk_DIVMOD_"<<jj<<" range "<<vIn_hi<<" to scope "<<scope.fullpath()
        //<<" <"<<scope.str()<<">"
        <<endl;
    int nops=0;
    string tag = OSSFMT("divmod_"<<jj);
    if(scope.find(tag)){
        if(v>1) cout<<"DIVMOD_"<<jj<<" macro already there"<<endl;
    }else{
        scope[tag].setType("TAG"); // create the tag block "we were here before"
        if(v>0) cout<<"DIVMOD_"<<jj<<" new macro"<<endl;
        int nops = mk_FASTDIV(cb,jj,vIn_hi,v);
        string mac = OSSFMT(" \\\n          VDIV = FASTDIV_"<<jj<<"(V); \\\n");
        if(nops==1){
            assert(positivePow2(jj));
            if(v>1) cout<<("MASK WITH jj-1 for modulus");
            mac = OSSFMT(mac<<"          VMOD = _ve_vand_vsv("<<jithex(jj-1)<<",V)");
            ++nops;
        }else{
            // VE does not have FMA ops for any integer type.
            //     so for 12/24-bit floats could consdier exact-floating calcs,
            //     but conversion ops probably kill this idea (not tried).
            if(v>1) cout<<("MUL-SUB modulus");
            mac = OSSFMT(mac<<"          VMOD = _ve_vsubul_vvv(V,_ve_vmulul_vsv("<<jj<<",VDIV))");
            if(!isIval(jj)) mac.append(" /*is non-Ival in register?*/");
            nops+=2;
        }
        scope.define(OSSFMT("DIVMOD_"<<jj<<"(V,VDIV,VMOD)"),mac);
    }
    return nops;
}

}//cprog::
// vim: ts=4 sw=4 et cindent cino=^=l0,\:.5s,=-.5s,N-s,g.5s,b1 cinkeys=0{,0},0),\:,0#,!^F,o,O,e,0=break
